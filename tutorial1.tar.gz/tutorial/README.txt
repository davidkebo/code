CUDD Tutorial
Using cudd-2.4.1

How to compile the program?
------------------
Enter the directory tutorial
Use the 'make' command


How to run the program?
------------------
usage: ./tutorial


Documentation
-----------------
The program creates a BDD node and dumps the resulting BDD in a dot format.
The .dot file is stored in the bdd directory.
To open and visualize the .dot files representing the ADDs, download and install Graphviz Graph Visualization Software available at http://www.graphviz.org/

  
Contact
--------
David Kebo Houngninou
dhoungninou@smu.edu


