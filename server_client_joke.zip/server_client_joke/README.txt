Client Side
- Make connection to server socket 
- Read the Joke from the socket 
- Close the socket connection 

Server Side
- Listen for connections
- Generate random joke 
- Write joke to socket
- Close socket