/* File:maze.cpp
   C++ code that generates and displays a rectangular maze of R rows and C columns,
   and finds and diplays the path from start to end.
   ----------------------------------------------------------------
   Class: CS 375			 Instructor: Dr. Morse
   Assignment: Case Study 2.5		 Date assigned: September 04, 2008 
   Programmer: David Houngninou		 Date completed: September 15, 2008 */

#include <GL/glut.h>
#include <iostream>
#include <fstream>
#include <stdio.h>
using namespace std;

const int rows = 100 , columns = 150;
int northWall [rows][columns], eastWall [rows][columns], cell [rows][columns];
bool mazeSolved = false;
int direction = 0;

// Structure that holds a point with integer coordinates
struct GLintPoint{
  GLint x,y;
};

int random (int m)// random function
{ return rand() %m; }

void myInit() // Initialize various values in the graphics pipeline
{
  glClearColor(0.0, 0.0, 0.0, 0.0);      // choose background color (Black)
  glColor3f(1.0,1.0,1.0);        // set the drawing color (White)
  glPointSize(2.0);                   // set point size
  glMatrixMode(GL_PROJECTION);        // load matrix mode
  glLoadIdentity();                   // load identity matrix
  gluOrtho2D(0.0, 800.0, 0.0, 600.0); // defines a 2D orthographic projection
  glViewport (0,0,1050, 800);
}

void clear_cells() // Initialize cells to zero (cells not visited) 
{ for (int i = 0; i<= rows; i++)
    for (int j = 0; j<= columns; j++)
      cell [i][j] = 0; }

void generateMaze () // Generate a random maze with walls as 0's ar 1's
{ 
  for (int i = 0; i<= rows; i++)
    for (int j = 0; j<= columns; j++)
      {
	northWall [i][j] = random(2);
	
	if (northWall [i][j] == 1)
	  eastWall [i][j] = 0;
	
	else if (northWall [i][j] == 0)
	  eastWall [i][j] = 1;
      }
}

void drawDot( GLint x, GLint y) // Draws a dot on the screen 
{	
  glColor3f(1.0,0.0,0.0); // Drawing color (Red)  
  glPointSize(3.0);      // set point size
  glBegin(GL_POINTS);
  glVertex2i(x,y); // Draw the point
  glEnd();
}

void createGrid () // Create grid with horizontal and vertical lines
{
 int i, scaledRows, scaledColumns;
 scaledRows = rows * 5;
 scaledColumns = columns * 5;
 
 glClear(GL_COLOR_BUFFER_BIT);    // clear the screen
 glBegin(GL_LINES);
 
 for (i=0; i<=scaledRows; i= i+5) // Horizontal lines. 
   {glVertex2f(0, i);
     glVertex2f(scaledColumns, i);}
 
 for (i=0; i<=scaledColumns; i=i+5) // Vertical lines. 
   {glVertex2f(i, 0);
     glVertex2f(i, scaledRows);}
}

void run_maze(int i, int j) // Run through the maze
{
  while (mazeSolved == false)
    {
      direction = random(2); // Pick a random direction up or left
      
      if ((northWall [i][j] == 1) && (eastWall [i][j] == 1)) // Checks for dead ends
	{
	  clear_cells(); // Start over by clearing all the cells
	  j ++;
        }
      
      if ((direction == 0) && (northWall [i][j] == 0)) // Up direction
	i++;
      else if ((direction == 1) && (eastWall [i][j] == 0)) // Left direction
	j++;
      
      cell [i][j] = 1; // Mark the cell as visited
      
      if ((i== rows) || (j==columns))  // Check if an end of the maze has been reached
	mazeSolved = true; 
    } 
}

void display_maze() // Maze display function
{
  myInit(); // GL initialization routine
  generateMaze (); // Generate the maze
  clear_cells(); // Initialize all the cells as unvisited
  createGrid (); // Create grid with horizontal and vertical lines
  
  glColor3f(0.0, 0.0, 0.0); // Drawing color (Black)
  for (int i = 0; i< rows-1; i++)
    for (int j = 0; j< columns-1; j++)
      {
	if (northWall [i][j] == 0)
	  {
	    glVertex2f(5*j, 5*(i+1));
	    glVertex2f(5*(j+1), 5*(i+1));
	  } 
	
	if (eastWall [i][j] == 0)
	  {
	    glVertex2f(5*(j+1), 5*(i+1));
	    glVertex2f(5*(j+1), 5*i);
	  }
      }
  
  run_maze(0,0); // Starts running the maze from the lower left corner.
  
  if (mazeSolved == true)
    {
      printf("\n The maze has been solved \n");
      for (int i = 0; i<= rows; i++) // Draw the path
	for (int j = 0; j<= columns; j++)
	  if (cell [i][j] == 1) 
	    drawDot((j*5)+2.5, (i*5)+2.5);	
    }
  
  glEnd(); 
  glFlush();  
}

void myMouse( int button, int state, int x, int y ) // Mouse click action
{
  if ( button == GLUT_LEFT_BUTTON && state == GLUT_DOWN )
    display_maze();      // redraw a new maze
}

void myKeyboard ( unsigned char key, int mouseX, int mouseY ) // Keyboard action
{
  switch( key ) // Switch on the user's input
    {
    case 'r':
      display_maze();      // redraw a new maze
      break;
    case 'c':
      exit ( -1 ); // Close the window
    default :
      break;
    }  
}

int main(int argc, char ** argv) // Main 
{
  // Windowing (GLUT) setup
  glutInit(&argc, argv);
  glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB); // Set Display mode
  glutInitWindowSize(1000,1000); // Set the window size
  glutInitWindowPosition(100,150); // Set the window position
  glutCreateWindow("The maze Window"); // Open the screen
  
  glutMouseFunc( myMouse ); // Register the mouse action 
  glutKeyboardFunc( myKeyboard ); // Register the keyboard action 
  glutDisplayFunc(display_maze); // Register callback functions
  
  myInit(); // GL initialization routine
  glutMainLoop();// Display Picture and wait and handle callbacks 
  return 0; // should never get here
} 

