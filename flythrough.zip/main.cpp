/* File:main.cpp
   Draw 3D scenes described by SDL
   ----------------------------------------------------------------
   Class: CS 355			 Instructor: Dr. Morse
   Assignment: Case Study 7.1 		 Date assigned: October 28, 2008
   Programmer: David Houngninou		 Date completed: December 09, 2008*/

#include <iostream.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include "sdl.h"
#include "scene.h"
#include "camera.h"

Camera cam; // Camera object
Scene scn; // construct the scene object 
char filename [80]; // Name of the input file

void displaySDL(void);

// Helper functions used in the fly through
//Contains iterations to move the camera
void looping(int iter, int mode)
{
  for (int i =0; i < iter; i++)
    { 
      switch(mode) // Switch on the user's input
	{
	case 0:
	  cam.slide(0,0,-0.4); // In "w"
	  break;
        case 1:
	  cam.slide(0,0,0.4); // Out "z"
	  break;
	case 2:
	  cam.pitch(-7.0);  // Up
	  break;
	case 3:
	  cam.pitch(7.0); // Down
	  break;
	case 4:
	  cam.yaw(-7.0); // Right
	  break;
	case 5:
	  cam.yaw(7.0); // Left
	  break;
        case 6:
	  cam.roll(4.0); // roll clockwise 'a'
	  break;
	case 7:
	  cam.roll(-4.0); // roll clockwise 's'
	  break;
	}  
      sleep (.95); displaySDL(); glFlush();
    } // End for
}// End Looping

//<<<<<<<<<<<<<<<<<<<<<<<< Fly through >>>>>>>>>>>>>>>>>>>>>>
void flyThrough()
{
  cam.set(6, 1.3, 6,     0, 0.25, 0,     0,3,0); displaySDL(); glFlush();
  sleep(1);
  looping(12, 0);
  looping(2, 2);
  looping(3, 0);
  looping(2, 3);
  sleep (6);
  looping(46, 1);
  sleep (5);
  looping(2, 2); 
  looping(30, 0); 
  looping(2, 3);
  sleep (6); 
  looping(30, 1);
  sleep (4);
  looping(7, 7);
  looping(4, 4);
  looping(30, 0);
  looping(2, 2);
  looping(14, 0);  
  looping(7, 6);
  sleep (1);
  looping(10, 5);
  sleep (5);
  looping(10, 0);
  sleep (5);
  looping(10, 1);
  looping(10, 2);
  looping(10, 0);
  looping(10, 3);
  sleep (5);
  looping(10, 5);
  looping(10, 0);
  looping(10, 3);
  looping(10, 0);
  looping(10, 2);
  looping(13, 4);
  looping(5, 0); 
  looping(1, 2);
  looping(5, 0);
  sleep (100);
}

//<<<<<<<<<<<<<<<<<<<<<<<< mySpecialKeys >>>>>>>>>>>>>>>>>>>>>>
void mySpecialKeys(int key, int x, int y)
{
  switch(key)
    {	
      // controls for camera
    case GLUT_KEY_UP:  cam.pitch(7.0); break; // pitch camera down
    case GLUT_KEY_DOWN: cam.pitch(-7.0); break; // pitch camera up	
    case GLUT_KEY_RIGHT: cam.yaw(-7.0); break; // yaw camera rigth
    case GLUT_KEY_LEFT: cam.yaw( 7.0); break;  // yaw camera left
    case GLUT_KEY_F1: exit(0);
    }
  glutPostRedisplay(); // draw it again
}


//<<<<<<<<<<<<<<<<<<<<<<<< myKeyboard >>>>>>>>>>>>>>>>>>>>>>
void myKeyboard(unsigned char key, int x, int y)
{
  // NOTE: CTRL-F = 'F' - 64
  
  switch(key)
    {	
    case 'w': cam.slide(0,0,-0.4); break; // slide camera forward
    case 'z': cam.slide(0,0,0.4); break; // slide camera back
    case 's': cam.roll(-4.0); break; // roll counter-clockwise
    case 'a': cam.roll(4.0); break; // roll clockwise
    case 'g': case 'G': flyThrough();
    case 'q': exit(0);
    default : break;
    }
  glutPostRedisplay(); // draw it again
}


// displaySDL
void displaySDL(void)
{
  cam.setShape(50.0, 64.0f/48.0f, 0.1, 100.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  cam.setModelViewMatrix();
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  
  scn.drawSceneOpenGL(); glutSwapBuffers();
} // end of display

// Main
int main(int argc, char **argv)
{
  //Get the file name from user input
  printf("\nPlease enter the SDL file name: ");
  scanf("%s", filename);
  
  glutInit(&argc, argv);
  glutInitDisplayMode(GLUT_DOUBLE | GLUT_DEPTH | GLUT_RGB );
  glutInitWindowSize(640, 480);
  glutInitWindowPosition(100, 100);
  glutCreateWindow("Read/Draw an SDL scene (D. Houngninou)");
  glutSpecialFunc(mySpecialKeys);
  glutKeyboardFunc(myKeyboard);
  glutDisplayFunc(displaySDL);
  
  glEnable(GL_LIGHTING);
  glEnable(GL_LIGHT0);
  glShadeModel(GL_SMOOTH);
  glEnable(GL_DEPTH_TEST);
  glEnable(GL_NORMALIZE);
  glViewport(0, 0, 640, 480);
  scn.read(filename); //read the SDL file and build the objects
  scn.makeLightsOpenGL(); // scan the light list and make OpenGL lights
  
  // set initial camera position
  cam.set(6, 1.3, 6,     0, 0.25, 0,     0,3,0);
  
  glutMainLoop();
}


