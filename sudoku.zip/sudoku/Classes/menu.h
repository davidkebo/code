//  Written by: Cadrian Chan & David Houngninou & Yu-Ying Liang
//	CS436 Washington University in St. Louis
//  Copyright 2010 All rights reserved.

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "sudokuViewController.h"


@interface menu : UIViewController {
	sudokuViewController *traditional;
	sudokuViewController *jigsawmap;
    IBOutlet UIButton *bonusButton;
    IBOutlet UIButton *specialButton;
    IBOutlet UIButton *traditionalButton;
}
- (IBAction)bonus;
- (IBAction)special;
- (IBAction)traditional;
@end
