//
//  sudokuViewController.m
//  sudoku
//
//  Written by: Cadrian Chan & David Houngninou & Yu-Ying Liang
//	CS436 Washington University in St. Louis
//  Copyright 2010 All rights reserved.

#import "sudokuViewController.h"

@implementation sudokuViewController
@synthesize typeNumber;

- (IBAction)home:(id)sender{
	[self.navigationController popViewControllerAnimated: YES];
	[self.navigationController setNavigationBarHidden:YES animated:NO];
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	
	
	selectedValue = 1;
	[self setGame:typeNumber];
	
	cell11.tag = 11;
	cell12.tag = 12;
	cell13.tag = 13;
	cell14.tag = 14;
	cell15.tag = 15;
	cell16.tag = 16;
	cell17.tag = 17;
	cell18.tag = 18;
	cell19.tag = 19;
	
	cell21.tag = 21;
	cell22.tag = 22;
	cell23.tag = 23;
	cell24.tag = 24;
	cell25.tag = 25;
	cell26.tag = 26;
	cell27.tag = 27;
	cell28.tag = 28;
	cell29.tag = 29;
	
	cell31.tag = 31;
	cell32.tag = 32;
	cell33.tag = 33;
	cell34.tag = 34;
	cell35.tag = 35;
	cell36.tag = 36;
	cell37.tag = 37;
	cell38.tag = 38;
	cell39.tag = 39;
	
	cell41.tag = 41;
	cell42.tag = 42;
	cell43.tag = 43;
	cell44.tag = 44;
	cell45.tag = 45;
	cell46.tag = 46;
	cell47.tag = 47;
	cell48.tag = 48;
	cell49.tag = 49;
	
	cell51.tag = 51;
	cell52.tag = 52;
	cell53.tag = 53;
	cell54.tag = 54;
	cell55.tag = 55;
	cell56.tag = 56;
	cell57.tag = 57;
	cell58.tag = 58;
	cell59.tag = 59;
	
	cell61.tag = 61;
	cell62.tag = 62;
	cell63.tag = 63;
	cell64.tag = 64;
	cell65.tag = 65;
	cell66.tag = 66;
	cell67.tag = 67;
	cell68.tag = 68;
	cell69.tag = 69;
	
	cell71.tag = 71;
	cell72.tag = 72;
	cell73.tag = 73;
	cell74.tag = 74;
	cell75.tag = 75;
	cell76.tag = 76;
	cell77.tag = 77;
	cell78.tag = 78;
	cell79.tag = 79;
	
	cell81.tag = 81;
	cell82.tag = 82;
	cell83.tag = 83;
	cell84.tag = 84;
	cell85.tag = 85;
	cell86.tag = 86;
	cell87.tag = 87;
	cell88.tag = 88;
	cell89.tag = 89;
	
	cell91.tag = 91;
	cell92.tag = 92;
	cell93.tag = 93;
	cell94.tag = 94;
	cell95.tag = 95;
	cell96.tag = 96;
	cell97.tag = 97;
	cell98.tag = 98;
	cell99.tag = 99;
	
	Value1.tag = 1;
	Value2.tag = 2;
	Value3.tag = 3;
	Value4.tag = 4;
	Value5.tag = 5;
	Value6.tag = 6;
	Value7.tag = 7;
	Value8.tag = 8;
	Value9.tag = 9;
	Value0.tag = 0;
	
	buttonArray = [[NSMutableArray alloc] initWithObjects:
				   Value0,Value1,Value2,Value3,Value4,Value5,Value6,Value7,Value8,Value9,@"",
				   cell11,cell12,cell13,cell14,cell15,cell16,cell17,cell18,cell19,@"",
				   cell21,cell22,cell23,cell24,cell25,cell26,cell27,cell28,cell29,@"",
				   cell31,cell32,cell33,cell34,cell35,cell36,cell37,cell38,cell39,@"",
				   cell41,cell42,cell43,cell44,cell45,cell46,cell47,cell48,cell49,@"",
				   cell51,cell52,cell53,cell54,cell55,cell56,cell57,cell58,cell59,@"",
				   cell61,cell62,cell63,cell64,cell65,cell66,cell67,cell68,cell69,@"",
				   cell71,cell72,cell73,cell74,cell75,cell76,cell77,cell78,cell79,@"",
				   cell81,cell82,cell83,cell84,cell85,cell86,cell87,cell88,cell89,@"",
				   cell91,cell92,cell93,cell94,cell95,cell96,cell97,cell98,cell99,nil ] ;
	
	
	for (int i = 0; i < 10; i++){
		if(i != 1)			
			[[buttonArray objectAtIndex:i] setBackgroundImage:[UIImage imageNamed:@"whiteButton.png"] forState:UIControlStateNormal];
		else
			[[buttonArray objectAtIndex:i] setBackgroundImage:[UIImage imageNamed:@"redButton.png"] forState:UIControlStateNormal];
	}
	[self setCells];
	
    [super viewDidLoad];
}

- (IBAction)value:(id)sender {
	int i = [sender tag]%10 -1;
	int j = [sender tag]/10 -1;
	cell *c;
	c = [b getcell:j column:i];	
	
	if(c.enabled){
		if(selectedValue != 0){
			if([b setcell:j col:i num: selectedValue t: typeNumber]){
				[[buttonArray objectAtIndex:[sender tag] ] setTitle:[NSString stringWithFormat: @"%d", selectedValue] forState:UIControlStateNormal];	
			}
		}	
		else{
			[b cleancell:j column:i];
			[[buttonArray objectAtIndex:[sender tag] ] setTitle:[NSString stringWithFormat: @""] forState:UIControlStateNormal];
		}
	}
}

- (IBAction)modify:(id)sender{	
	selectedValue = [sender tag];
	
	for (int i = 0; i<10; i++){
		if(i != [sender tag])
			[[buttonArray objectAtIndex:i] setBackgroundImage:[UIImage imageNamed:@"whiteButton.png"] forState:UIControlStateNormal];
		else
			[[buttonArray objectAtIndex:i] setBackgroundImage:[UIImage imageNamed:@"redButton.png"] forState:UIControlStateNormal];
	}
}

- (IBAction)reset:(id)sender{
	[self setCells];
	[b restart];
}

- (IBAction)newgame:(id)sender{
	[self setGame:typeNumber];
	[self setCells];
}

- (void)setCells{
	cell *c;
	
	//DEBUG
	//type = 2;
	
	if(typeNumber == 1){
		for(int j = 1; j < 10; j++){
			for (int i = 1; i < 10; i++) {
				c = [b getcell:j-1 column:i-1];
				
				if(c.enabled == NO){
					[[buttonArray objectAtIndex: (j*10+i)] setTitleColor:UIColor.orangeColor forState:UIControlStateNormal];
					[[buttonArray objectAtIndex: (j*10+i)] setTitle:[NSString stringWithFormat: @"%d", c.value] forState:UIControlStateNormal];
				}
				else {
					[[buttonArray objectAtIndex: (j*10+i)] setTitleColor:UIColor.blackColor forState:UIControlStateNormal];
					[[buttonArray objectAtIndex: (j*10+i)] setTitle:[NSString stringWithFormat: @""] forState:UIControlStateNormal];				
				}
			}
		}
	}
	
	else if (typeNumber == 2) {

		for(int j = 1; j < 10; j++){
			for (int i = 1; i < 10; i++) {
				c = [b getcell:j-1 column:i-1];
				
				if(c.enabled == NO){
					[[buttonArray objectAtIndex: (j*10+i)] setTitleColor:UIColor.orangeColor forState:UIControlStateNormal];
					[[buttonArray objectAtIndex: (j*10+i)] setTitle:[NSString stringWithFormat: @"%d", c.value] forState:UIControlStateNormal];
				}
				else {
					[[buttonArray objectAtIndex: (j*10+i)] setTitleColor:UIColor.blackColor forState:UIControlStateNormal];
					[[buttonArray objectAtIndex: (j*10+i)] setTitle:[NSString stringWithFormat: @""] forState:UIControlStateNormal];				
				}
				
				switch (c.color) {
					case 0:
						[[buttonArray objectAtIndex: (j*10+i)] setBackgroundColor:[UIColor redColor]];
						break;
					case 1:
						[[buttonArray objectAtIndex: (j*10+i)] setBackgroundColor:[UIColor yellowColor]];
						break;
					case 2:
						[[buttonArray objectAtIndex: (j*10+i)] setBackgroundColor:[UIColor greenColor]];
						break;
					case 3:
						[[buttonArray objectAtIndex: (j*10+i)] setBackgroundColor:[UIColor lightGrayColor]];
						break;
					case 4:
						[[buttonArray objectAtIndex: (j*10+i)] setBackgroundColor:[UIColor cyanColor]];
						break;
					case 5:
						[[buttonArray objectAtIndex: (j*10+i)] setBackgroundColor:[UIColor blueColor]];
						break;
					case 6:
						[[buttonArray objectAtIndex: (j*10+i)] setBackgroundColor:[UIColor purpleColor]];
						break;
					case 7:
						[[buttonArray objectAtIndex: (j*10+i)] setBackgroundColor:[UIColor brownColor]];
						break;
					case 8:
						[[buttonArray objectAtIndex: (j*10+i)] setBackgroundColor:[UIColor grayColor]];
						break;
					default:
						break;						
				}				
			}
		}
	}
}


- (void)setGame:(int)gameType{
	typeNumber = gameType;
	[b release];
	b = [[board alloc] init:gameType];
}




/*
 // Override to allow orientations other than the default portrait orientation.
 - (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
 // Return YES for supported orientations
 return (interfaceOrientation == UIInterfaceOrientationPortrait);
 }
 */

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[buttonArray release];
	[b release];
    [super dealloc];
}

@end
