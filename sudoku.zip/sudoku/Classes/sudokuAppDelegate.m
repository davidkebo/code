//
//  sudokuAppDelegate.m
//  sudoku
//
//  Written by: Cadrian Chan & David Houngninou & Yu-Ying Liang
//	CS436 Washington University in St. Louis
//  Copyright 2010 All rights reserved.

#import "sudokuAppDelegate.h"

@implementation sudokuAppDelegate

@synthesize window;
@synthesize navigationController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {
   // Override point for customization after app launch    
    [window addSubview:navigationController.view];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [navigationController release];
    [window release];
    [super dealloc];
}


@end
