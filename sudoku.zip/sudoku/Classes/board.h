//
//  board.h
//  ShowDoku
//
//  Written by: Cadrian Chan & David Houngninou & Yu-Ying Liang
//	CS436 Washington University in St. Louis
//  Copyright 2010 All rights reserved.


#import <Foundation/Foundation.h>
#import "cell.h"
#include <stdlib.h>

@interface board : NSObject {
	int cellType; 
	cell *cellArray[9][9];
	int solnArray[9][9];
	NSMutableArray *color0Array ;
	NSMutableArray *color1Array ;
	NSMutableArray *color2Array ;
	NSMutableArray *color3Array ;
	NSMutableArray *color4Array ;
	NSMutableArray *color5Array ;
	NSMutableArray *color6Array ;
	NSMutableArray *color7Array ;
	NSMutableArray *color8Array ;
}

@property (readwrite) int cellType;

- (id)init:(int) type;
- (void)puzzlegenerator: (int) type;
-(BOOL) setcell:(int)row col:(int)column  num:(int)number t: (int)type;
- (cell*) getcell:(int)j column:(int)i;
- (void) cleancell:(int)j column:(int)i;
- (void) restart;

- (void)solnArrayInit;
- (void)debugPrintBoard;
- (void)generateRandBoard;
- (void)swap:(int)r0 czero:(int)c0 rone:(int)r1 cone:(int)c1;
- (void)swapRow:(int)r0 rowone:(int)r1;
- (void)swapCol:(int)c0 colone:(int)c1;


@end

