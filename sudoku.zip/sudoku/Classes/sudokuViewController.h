//
//  sudokuViewController.h
//  sudoku
//
//  Written by: Cadrian Chan & David Houngninou & Yu-Ying Liang
//	CS436 Washington University in St. Louis
//  Copyright 2010 All rights reserved.

#import <UIKit/UIKit.h>
#import "board.h"

@interface sudokuViewController : UIViewController {
	int selectedValue;
	int typeNumber;
	
	board *b;
	
	NSMutableArray *buttonArray;
	
	IBOutlet UIButton *cell11; 
	IBOutlet UIButton *cell12;
	IBOutlet UIButton *cell13;
	IBOutlet UIButton *cell14;
	IBOutlet UIButton *cell15;
	IBOutlet UIButton *cell16;
	IBOutlet UIButton *cell17;
	IBOutlet UIButton *cell18;
	IBOutlet UIButton *cell19;
	
	IBOutlet UIButton *cell21;
	IBOutlet UIButton *cell22;
	IBOutlet UIButton *cell23;
	IBOutlet UIButton *cell24;
	IBOutlet UIButton *cell25;
	IBOutlet UIButton *cell26;
	IBOutlet UIButton *cell27;
	IBOutlet UIButton *cell28;
	IBOutlet UIButton *cell29;
	
	IBOutlet UIButton *cell31;
	IBOutlet UIButton *cell32;
	IBOutlet UIButton *cell33;
	IBOutlet UIButton *cell34;
	IBOutlet UIButton *cell35;
	IBOutlet UIButton *cell36;
	IBOutlet UIButton *cell37;
	IBOutlet UIButton *cell38;
	IBOutlet UIButton *cell39;
	
	IBOutlet UIButton *cell41;
	IBOutlet UIButton *cell42;
	IBOutlet UIButton *cell43;
	IBOutlet UIButton *cell44;
	IBOutlet UIButton *cell45;
	IBOutlet UIButton *cell46;
	IBOutlet UIButton *cell47;
	IBOutlet UIButton *cell48;
	IBOutlet UIButton *cell49;
	
	IBOutlet UIButton *cell51;
	IBOutlet UIButton *cell52;
	IBOutlet UIButton *cell53;
	IBOutlet UIButton *cell54;
	IBOutlet UIButton *cell55;
	IBOutlet UIButton *cell56;
	IBOutlet UIButton *cell57;
	IBOutlet UIButton *cell58;
	IBOutlet UIButton *cell59;
	
	IBOutlet UIButton *cell61;
	IBOutlet UIButton *cell62;
	IBOutlet UIButton *cell63;
	IBOutlet UIButton *cell64;
	IBOutlet UIButton *cell65;
	IBOutlet UIButton *cell66;
	IBOutlet UIButton *cell67;
	IBOutlet UIButton *cell68;
	IBOutlet UIButton *cell69;
	
	IBOutlet UIButton *cell71;
	IBOutlet UIButton *cell72;
	IBOutlet UIButton *cell73;
	IBOutlet UIButton *cell74;
	IBOutlet UIButton *cell75;
	IBOutlet UIButton *cell76;
	IBOutlet UIButton *cell77;
	IBOutlet UIButton *cell78;
	IBOutlet UIButton *cell79;
	
	IBOutlet UIButton *cell81;
	IBOutlet UIButton *cell82;
	IBOutlet UIButton *cell83;
	IBOutlet UIButton *cell84;
	IBOutlet UIButton *cell85;
	IBOutlet UIButton *cell86;
	IBOutlet UIButton *cell87;
	IBOutlet UIButton *cell88;
	IBOutlet UIButton *cell89;
	
	IBOutlet UIButton *cell91;
	IBOutlet UIButton *cell92;
	IBOutlet UIButton *cell93;
	IBOutlet UIButton *cell94;
	IBOutlet UIButton *cell95;
	IBOutlet UIButton *cell96;
	IBOutlet UIButton *cell97;
	IBOutlet UIButton *cell98;
	IBOutlet UIButton *cell99;
	
	IBOutlet UIButton *Value1;
	IBOutlet UIButton *Value2;
	IBOutlet UIButton *Value3;
	IBOutlet UIButton *Value4;
	IBOutlet UIButton *Value5;
	IBOutlet UIButton *Value6;
	IBOutlet UIButton *Value7;
	IBOutlet UIButton *Value8;
	IBOutlet UIButton *Value9;
	IBOutlet UIButton *Value0;
	
}

- (IBAction)modify:(id)sender;
- (IBAction)value:(id)sender;
- (IBAction)home:(id)sender;
- (IBAction)reset:(id)sender;
- (IBAction)newgame:(id)sender;
- (void) setCells;
- (void) setGame:(int) gameType;


@property int typeNumber;

@end

