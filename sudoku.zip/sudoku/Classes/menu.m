//  Written by: Cadrian Chan & David Houngninou & Yu-Ying Liang
//	CS436 Washington University in St. Louis
//  Copyright 2010 All rights reserved.

#import "menu.h"

@implementation menu
- (IBAction)bonus {
    
}

- (IBAction)special {
	jigsawmap = [[sudokuViewController alloc] initWithNibName:@"sudokuViewController" bundle:nil];
	jigsawmap.typeNumber = 2;
	[self.navigationController pushViewController:jigsawmap animated:YES];
	[self.navigationController setNavigationBarHidden:YES animated:NO];
}

- (IBAction)traditional {
    traditional = [[sudokuViewController alloc] initWithNibName:@"sudokuViewController" bundle:nil];
	traditional.typeNumber = 1;
	[self.navigationController pushViewController:traditional animated:YES];
	[self.navigationController setNavigationBarHidden:YES animated:NO];
}
@end
