//
//  board.m
//  sudoku
//
//  Created by David Kebo on 4/25/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "board.h"

@implementation board
@synthesize cellType;


- (id)init:(int) type{		
	self.cellType = 1;
	[self puzzlegenerator: self.cellType];
	
	return self;
}

-(BOOL) setcell:(int)row col:(int)column  num:(int)number t: (int)type;
{    
    int rowQuad = row/3;
    int columnQuad = column/3;
    
    
    if(type == 1){    //traditional rule
        
        for (int j = 0; j < 9; j++){
            if (cellArray[j][column].value == number)
                return NO;
		}
        
        for (int i = 0; i < 9; i++){
            if (cellArray[row][i].value == number)
                return NO;
		}
        
        for(int i = 3*columnQuad; i<3*columnQuad+3; i++){
            for(int j = 3*rowQuad; j<3*rowQuad+3; j++){
                if (cellArray[j][i].value == number)
                    return NO;
            }
        }
        
		cellArray[row][column].value = number;
        return YES;
    }
    else{ //if(type == 2){    //special rule
        return YES;
    }
	
}
- (void)puzzlegenerator: (int) celltype{
	int randNum = 1;//change to rand func later	
	
	for(int i = 0;i<9;i++){
		for(int j = 0;j<9;j++){
			cellArray[i][j] =[[cell alloc]init];
		}
	}
	
	if(randNum == 1){
		cellArray[0][0].value = 1; cellArray[0][4].value = 6; cellArray[0][7].value = 2; cellArray[1][3].value = 3; cellArray[1][6].value = 8;
		cellArray[2][1].value = 4; cellArray[2][5].value = 5; cellArray[2][8].value = 9; cellArray[3][0].value = 3; cellArray[3][7].value = 6;
		cellArray[4][2].value = 8; cellArray[4][6].value = 1; cellArray[5][1].value = 5; cellArray[5][8].value = 7; cellArray[6][0].value = 2;
		cellArray[6][3].value = 8; cellArray[6][7].value = 3; cellArray[7][2].value = 5; cellArray[7][5].value = 1; cellArray[8][1].value = 9;
		cellArray[8][4].value = 5; cellArray[8][8].value = 6;

		cellArray[0][0].enabled = NO; cellArray[0][4].enabled = NO; cellArray[0][7].enabled = NO; cellArray[1][3].enabled = NO; cellArray[1][6].enabled = NO;
		cellArray[2][1].enabled = NO; cellArray[2][5].enabled = NO; cellArray[2][8].enabled = NO; cellArray[3][0].enabled = NO; cellArray[3][7].enabled = NO;
		cellArray[4][2].enabled = NO; cellArray[4][6].enabled = NO; cellArray[5][1].enabled = NO; cellArray[5][8].enabled = NO; cellArray[6][0].enabled = NO;
		cellArray[6][3].enabled = NO; cellArray[6][7].enabled = NO; cellArray[7][2].enabled = NO; cellArray[7][5].enabled = NO; cellArray[8][1].enabled = NO;
		cellArray[8][4].enabled = NO; cellArray[8][8].enabled = NO;
	}
}

- (cell*) getcell:(int)j column:(int)i{
	return cellArray[j][i];
}

- (void) cleancell:(int)j column:(int)i{
	cellArray[j][i].value = 0;
}

- (void) restart{
	for(int i = 0; i < 9; i++)
		for(int j = 0; j < 9; j++){
			if(cellArray[j][i].enabled)
				cellArray[j][i].value = 0;
		}
}

@end
