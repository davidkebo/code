//
//  cell.h
//  ShowDoku
//
//  Written by: Cadrian Chan & David Houngninou & Yu-Ying Liang
//	CS436 Washington University in St. Louis
//  Copyright 2010 All rights reserved.

#import <Foundation/Foundation.h>

@interface cell : NSObject {
	int value;
	BOOL enabled;
	int color;
	int hint; 
}

@property (readwrite) int value;
@property (readwrite) BOOL enabled;
@property (readwrite) int color;
@property (readwrite) int hint;

- (id)init;

@end