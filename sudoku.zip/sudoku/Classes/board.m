//
//  board.m
//  ShowDoku
//
//  Written by: Cadrian Chan & David Houngninou & Yu-Ying Liang
//	CS436 Washington University in St. Louis
//  Copyright 2010 All rights reserved.

#import "board.h"

@implementation board
@synthesize cellType;


- (id)init:(int) type{		
	self.cellType = type;
	
	self.solnArrayInit;
	
	self.generateRandBoard;
	//self.debugPrintBoard;
	
	[self puzzlegenerator: self.cellType];
	
	return self;
}

-(BOOL) setcell:(int)row col:(int)column  num:(int)number t: (int)type;
{    
    int rowQuad = row/3;
    int columnQuad = column/3;
	cell *c;
    
    
    if(type == 1){    //traditional rule
        
        for (int j = 0; j < 9; j++){
            if (cellArray[j][column].value == number)
                return NO;
		}
        
        for (int i = 0; i < 9; i++){
            if (cellArray[row][i].value == number)
                return NO;
		}
        
        for(int i = 3*columnQuad; i<3*columnQuad+3; i++){
            for(int j = 3*rowQuad; j<3*rowQuad+3; j++){
                if (cellArray[j][i].value == number)
                    return NO;
            }
        }
        
		cellArray[row][column].value = number;
        return YES;
    }
    else{ // Jigsaw rule
		
		for (int j = 0; j < 9; j++){
            if (cellArray[j][column].value == number)
                return NO;
		}
        
        for (int i = 0; i < 9; i++){
            if (cellArray[row][i].value == number)
                return NO;
		}
        
        switch (cellArray[row][column].color){
			case 0:
				for (int i = 0; i < 9; i++){
					c = [color0Array objectAtIndex:i];
					if(number == c.value )
					return NO;
				}
				break;
			case 1:
				for (int i = 0; i < 9; i++){
					c = [color1Array objectAtIndex:i];
					if(number == c.value )
						return NO;
				}
				break;
			case 2:
				for (int i = 0; i < 9; i++){
					c = [color2Array objectAtIndex:i];
					if(number == c.value )
						return NO;
				}
				break;
			case 3:
				for (int i = 0; i < 9; i++){
					c = [color3Array objectAtIndex:i];
					if(number == c.value )
						return NO;
				}
				break;
			case 4:
				for (int i = 0; i < 9; i++){
					c = [color4Array objectAtIndex:i];
					if(number == c.value )
						return NO;
				}
				break;
			case 5:
				for (int i = 0; i < 9; i++){
					c = [color5Array objectAtIndex:i];
					if(number == c.value )
						return NO;
				}
				break;
			case 6:
				for (int i = 0; i < 9; i++){
					c = [color6Array objectAtIndex:i];
					if(number == c.value )
						return NO;
				}
				break;
			case 7:
				for (int i = 0; i < 9; i++){
					c = [color7Array objectAtIndex:i];
					if(number == c.value )
						return NO;
				}
				break;
			case 8:
				for (int i = 0; i < 9; i++){
					c = [color8Array objectAtIndex:i];
					if(number == c.value )
						return NO;
				}
				break;
			default:
				break;		
		}		
        
		cellArray[row][column].value = number;
        return YES;		
    }
	
}
- (void)puzzlegenerator: (int) celltype{
	
	int randi; int randj;
	
	for(int i = 0;i<9;i++){
		for(int j = 0;j<9;j++){
			cellArray[i][j] =[[cell alloc]init];
		}
	}
	
	if(celltype == 1){
		for(int i = 0; i<15; i++){	//should change value of i according to difficulty, i larger means easier
			randi = arc4random()%9; //(0 to 8)
			randj = arc4random()%9;
			cellArray[randj][randi].value = solnArray[randj][randi];
			cellArray[randj][randi].enabled = NO;
		}
	}
	else{
		color0Array = [[NSMutableArray alloc] init];
		color1Array = [[NSMutableArray alloc] init];
		color2Array = [[NSMutableArray alloc] init];
		color3Array = [[NSMutableArray alloc] init];
		color4Array = [[NSMutableArray alloc] init];
		color5Array = [[NSMutableArray alloc] init];
		color6Array = [[NSMutableArray alloc] init];
		color7Array = [[NSMutableArray alloc] init];
		color8Array = [[NSMutableArray alloc] init];

		switch (arc4random()%5){
			case 0:
				cellArray[0][0].color = 0; cellArray[0][1].color = 0; cellArray[0][2].color = 0;cellArray[0][3].color = 3; cellArray[0][4].color = 3; cellArray[0][5].color = 6;cellArray[0][6].color = 6; cellArray[0][7].color = 6; cellArray[0][8].color = 6;
				cellArray[1][0].color = 0; cellArray[1][1].color = 0; cellArray[1][2].color = 3;cellArray[1][3].color = 3; cellArray[1][4].color = 3; cellArray[1][5].color = 6;cellArray[1][6].color = 7; cellArray[1][7].color = 6; cellArray[1][8].color = 6;
				cellArray[2][0].color = 0; cellArray[2][1].color = 0; cellArray[2][2].color = 3;cellArray[2][3].color = 3; cellArray[2][4].color = 3; cellArray[2][5].color = 4;cellArray[2][6].color = 7; cellArray[2][7].color = 6; cellArray[2][8].color = 6;
				cellArray[3][0].color = 1; cellArray[3][1].color = 0; cellArray[3][2].color = 0;cellArray[3][3].color = 4; cellArray[3][4].color = 3; cellArray[3][5].color = 4;cellArray[3][6].color = 7; cellArray[3][7].color = 7; cellArray[3][8].color = 7;
				cellArray[4][0].color = 1; cellArray[4][1].color = 1; cellArray[4][2].color = 1;cellArray[4][3].color = 4; cellArray[4][4].color = 4; cellArray[4][5].color = 4;cellArray[4][6].color = 7; cellArray[4][7].color = 7; cellArray[4][8].color = 7;
				cellArray[5][0].color = 1; cellArray[5][1].color = 1; cellArray[5][2].color = 1;cellArray[5][3].color = 4; cellArray[5][4].color = 5; cellArray[5][5].color = 4;cellArray[5][6].color = 8; cellArray[5][7].color = 8; cellArray[5][8].color = 7;
				cellArray[6][0].color = 2; cellArray[6][1].color = 2; cellArray[6][2].color = 1;cellArray[6][3].color = 4; cellArray[6][4].color = 5; cellArray[6][5].color = 5;cellArray[6][6].color = 5; cellArray[6][7].color = 8; cellArray[6][8].color = 8;
				cellArray[7][0].color = 2; cellArray[7][1].color = 2; cellArray[7][2].color = 1;cellArray[7][3].color = 2; cellArray[7][4].color = 5; cellArray[7][5].color = 5;cellArray[7][6].color = 5; cellArray[7][7].color = 8; cellArray[7][8].color = 8;
				cellArray[8][0].color = 2; cellArray[8][1].color = 2; cellArray[8][2].color = 2;cellArray[8][3].color = 2; cellArray[8][4].color = 5; cellArray[8][5].color = 5;cellArray[8][6].color = 8; cellArray[8][7].color = 8; cellArray[8][8].color = 8;
				
				cellArray[0][0].value = 7; cellArray[0][0].enabled = NO;
				cellArray[0][1].value = 6; cellArray[0][1].enabled = NO;
				cellArray[4][0].value = 3; cellArray[4][0].enabled = NO;
				cellArray[2][2].value = 2; cellArray[2][2].enabled = NO;
				cellArray[3][2].value = 1; cellArray[3][2].enabled = NO;
				cellArray[4][2].value = 5; cellArray[4][2].enabled = NO;
				cellArray[5][2].value = 7; cellArray[5][2].enabled = NO;
				cellArray[6][3].value = 3; cellArray[6][3].enabled = NO;
				cellArray[7][3].value = 2; cellArray[7][3].enabled = NO;
				cellArray[4][4].value = 9; cellArray[4][4].enabled = NO;
				cellArray[1][5].value = 8; cellArray[1][5].enabled = NO;
				cellArray[2][5].value = 1; cellArray[2][5].enabled = NO;
				cellArray[3][6].value = 5; cellArray[3][6].enabled = NO;
				cellArray[4][6].value = 7; cellArray[4][6].enabled = NO;
				cellArray[5][6].value = 4; cellArray[5][6].enabled = NO;
				cellArray[6][6].value = 9; cellArray[6][6].enabled = NO;
				cellArray[2][7].value = 7; cellArray[2][7].enabled = NO;
				cellArray[4][7].value = 6; cellArray[4][7].enabled = NO;
				cellArray[4][8].value = 8; cellArray[4][8].enabled = NO;
				cellArray[8][8].value = 5; cellArray[8][8].enabled = NO;
				break;
			case 1:
				cellArray[0][0].color = 0; cellArray[0][1].color = 0; cellArray[0][2].color = 0;cellArray[0][3].color = 0; cellArray[0][4].color = 3; cellArray[0][5].color = 6;cellArray[0][6].color = 6; cellArray[0][7].color = 6; cellArray[0][8].color = 6;
				cellArray[1][0].color = 0; cellArray[1][1].color = 0; cellArray[1][2].color = 1;cellArray[1][3].color = 0; cellArray[1][4].color = 3; cellArray[1][5].color = 3;cellArray[1][6].color = 6; cellArray[1][7].color = 6; cellArray[1][8].color = 6;
				cellArray[2][0].color = 0; cellArray[2][1].color = 1; cellArray[2][2].color = 1;cellArray[2][3].color = 4; cellArray[2][4].color = 3; cellArray[2][5].color = 3;cellArray[2][6].color = 3; cellArray[2][7].color = 6; cellArray[2][8].color = 7;
				cellArray[3][0].color = 0; cellArray[3][1].color = 1; cellArray[3][2].color = 1;cellArray[3][3].color = 4; cellArray[3][4].color = 4; cellArray[3][5].color = 3;cellArray[3][6].color = 3; cellArray[3][7].color = 6; cellArray[3][8].color = 7;
				cellArray[4][0].color = 1; cellArray[4][1].color = 1; cellArray[4][2].color = 5;cellArray[4][3].color = 4; cellArray[4][4].color = 4; cellArray[4][5].color = 4;cellArray[4][6].color = 3; cellArray[4][7].color = 7; cellArray[4][8].color = 7;
				cellArray[5][0].color = 1; cellArray[5][1].color = 2; cellArray[5][2].color = 5;cellArray[5][3].color = 5; cellArray[5][4].color = 4; cellArray[5][5].color = 4;cellArray[5][6].color = 7; cellArray[5][7].color = 7; cellArray[5][8].color = 8;
				cellArray[6][0].color = 1; cellArray[6][1].color = 2; cellArray[6][2].color = 5;cellArray[6][3].color = 5; cellArray[6][4].color = 5; cellArray[6][5].color = 4;cellArray[6][6].color = 7; cellArray[6][7].color = 7; cellArray[6][8].color = 8;
				cellArray[7][0].color = 2; cellArray[7][1].color = 2; cellArray[7][2].color = 2;cellArray[7][3].color = 5; cellArray[7][4].color = 5; cellArray[7][5].color = 8;cellArray[7][6].color = 7; cellArray[7][7].color = 8; cellArray[7][8].color = 8;
				cellArray[8][0].color = 2; cellArray[8][1].color = 2; cellArray[8][2].color = 2;cellArray[8][3].color = 2; cellArray[8][4].color = 5; cellArray[8][5].color = 8;cellArray[8][6].color = 8; cellArray[8][7].color = 8; cellArray[8][8].color = 8;
				
				cellArray[2][0].value = 8; cellArray[2][0].enabled = NO;
				cellArray[4][0].value = 7; cellArray[4][0].enabled = NO;
				cellArray[2][1].value = 3; cellArray[2][1].enabled = NO;
				cellArray[5][1].value = 9; cellArray[5][1].enabled = NO;
				cellArray[0][2].value = 3; cellArray[0][2].enabled = NO;
				cellArray[2][2].value = 5; cellArray[2][2].enabled = NO;
				cellArray[4][2].value = 2; cellArray[4][2].enabled = NO;
				cellArray[0][3].value = 1; cellArray[0][3].enabled = NO;
				cellArray[3][3].value = 4; cellArray[3][3].enabled = NO;
				cellArray[8][3].value = 8; cellArray[8][3].enabled = NO;
				cellArray[1][4].value = 3; cellArray[1][4].enabled = NO;
				cellArray[4][4].value = 1; cellArray[4][4].enabled = NO;
				cellArray[7][4].value = 6; cellArray[7][4].enabled = NO;
				cellArray[8][4].value = 9; cellArray[8][4].enabled = NO;
				cellArray[0][5].value = 4; cellArray[0][5].enabled = NO;
				cellArray[5][5].value = 2; cellArray[5][5].enabled = NO;
				cellArray[2][6].value = 4; cellArray[2][6].enabled = NO;
				cellArray[4][6].value = 6; cellArray[4][6].enabled = NO;
				cellArray[6][6].value = 9; cellArray[6][6].enabled = NO;
				cellArray[8][6].value = 5; cellArray[8][6].enabled = NO;
				cellArray[3][7].value = 3; cellArray[3][7].enabled = NO;
				cellArray[6][7].value = 1; cellArray[6][7].enabled = NO;
				cellArray[4][8].value = 4; cellArray[4][8].enabled = NO;
				cellArray[7][8].value = 3; cellArray[7][8].enabled = NO;
				break;
				
			case 2:
				
				cellArray[0][0].color = 0; cellArray[0][1].color = 0; cellArray[0][2].color = 0;cellArray[0][3].color = 3; cellArray[0][4].color = 3; cellArray[0][5].color = 3;cellArray[0][6].color = 3; cellArray[0][7].color = 6; cellArray[0][8].color = 6;
				cellArray[1][0].color = 0; cellArray[1][1].color = 0; cellArray[1][2].color = 0;cellArray[1][3].color = 3; cellArray[1][4].color = 3; cellArray[1][5].color = 3;cellArray[1][6].color = 3; cellArray[1][7].color = 6; cellArray[1][8].color = 6;
				cellArray[2][0].color = 0; cellArray[2][1].color = 0; cellArray[2][2].color = 1;cellArray[2][3].color = 1; cellArray[2][4].color = 4; cellArray[2][5].color = 3;cellArray[2][6].color = 6; cellArray[2][7].color = 6; cellArray[2][8].color = 6;
				cellArray[3][0].color = 0; cellArray[3][1].color = 1; cellArray[3][2].color = 1;cellArray[3][3].color = 1; cellArray[3][4].color = 4; cellArray[3][5].color = 4;cellArray[3][6].color = 7; cellArray[3][7].color = 6; cellArray[3][8].color = 6;
				cellArray[4][0].color = 1; cellArray[4][1].color = 1; cellArray[4][2].color = 1;cellArray[4][3].color = 4; cellArray[4][4].color = 4; cellArray[4][5].color = 4;cellArray[4][6].color = 7; cellArray[4][7].color = 7; cellArray[4][8].color = 7;
				cellArray[5][0].color = 2; cellArray[5][1].color = 2; cellArray[5][2].color = 1;cellArray[5][3].color = 4; cellArray[5][4].color = 4; cellArray[5][5].color = 7;cellArray[5][6].color = 7; cellArray[5][7].color = 7; cellArray[5][8].color = 8;
				cellArray[6][0].color = 2; cellArray[6][1].color = 2; cellArray[6][2].color = 2;cellArray[6][3].color = 5; cellArray[6][4].color = 4; cellArray[6][5].color = 7;cellArray[6][6].color = 7; cellArray[6][7].color = 8; cellArray[6][8].color = 8;
				cellArray[7][0].color = 2; cellArray[7][1].color = 2; cellArray[7][2].color = 5;cellArray[7][3].color = 5; cellArray[7][4].color = 5; cellArray[7][5].color = 5;cellArray[7][6].color = 8; cellArray[7][7].color = 8; cellArray[7][8].color = 8;
				cellArray[8][0].color = 2; cellArray[8][1].color = 2; cellArray[8][2].color = 5;cellArray[8][3].color = 5; cellArray[8][4].color = 5; cellArray[8][5].color = 5;cellArray[8][6].color = 8; cellArray[8][7].color = 8; cellArray[8][8].color = 8;
				
				cellArray[0][0].value = 4; cellArray[0][0].enabled = NO;
				cellArray[0][8].value = 9; cellArray[0][8].enabled = NO;
				cellArray[1][1].value = 1; cellArray[1][1].enabled = NO;
				cellArray[1][3].value = 8; cellArray[1][3].enabled = NO;
				cellArray[1][6].value = 6; cellArray[1][6].enabled = NO;
				cellArray[1][7].value = 5; cellArray[1][7].enabled = NO;
				cellArray[3][2].value = 9; cellArray[3][2].enabled = NO;
				cellArray[3][3].value = 4; cellArray[3][3].enabled = NO;
				cellArray[3][4].value = 1; cellArray[3][4].enabled = NO;
				cellArray[3][5].value = 7; cellArray[3][5].enabled = NO;
				cellArray[4][1].value = 5; cellArray[4][1].enabled = NO;
				cellArray[4][7].value = 3; cellArray[4][7].enabled = NO;
				cellArray[4][8].value = 7; cellArray[4][8].enabled = NO;
				cellArray[5][0].value = 1; cellArray[5][0].enabled = NO;
				cellArray[5][3].value = 3; cellArray[5][3].enabled = NO;
				cellArray[5][4].value = 5; cellArray[5][4].enabled = NO;
				cellArray[7][1].value = 8; cellArray[7][1].enabled = NO;
				cellArray[7][2].value = 4; cellArray[7][2].enabled = NO;
				cellArray[7][5].value = 3; cellArray[7][5].enabled = NO;
				cellArray[7][7].value = 9; cellArray[7][7].enabled = NO;
				cellArray[8][0].value = 5; cellArray[8][0].enabled = NO;
				cellArray[8][5].value = 8; cellArray[8][5].enabled = NO;
				cellArray[8][8].value = 4; cellArray[8][8].enabled = NO;
				break;
			case 3:
				cellArray[0][0].color = 0; cellArray[0][1].color = 0; cellArray[0][2].color = 0;cellArray[0][3].color = 3; cellArray[0][4].color = 3; cellArray[0][5].color = 3;cellArray[0][6].color = 3; cellArray[0][7].color = 3; cellArray[0][8].color = 6;
				cellArray[1][0].color = 0; cellArray[1][1].color = 0; cellArray[1][2].color = 0;cellArray[1][3].color = 3; cellArray[1][4].color = 3; cellArray[1][5].color = 3;cellArray[1][6].color = 3; cellArray[1][7].color = 6; cellArray[1][8].color = 6;
				cellArray[2][0].color = 0; cellArray[2][1].color = 0; cellArray[2][2].color = 0;cellArray[2][3].color = 4; cellArray[2][4].color = 4; cellArray[2][5].color = 4;cellArray[2][6].color = 6; cellArray[2][7].color = 6; cellArray[2][8].color = 6;
				cellArray[3][0].color = 1; cellArray[3][1].color = 1; cellArray[3][2].color = 1;cellArray[3][3].color = 1; cellArray[3][4].color = 4; cellArray[3][5].color = 6;cellArray[3][6].color = 6; cellArray[3][7].color = 6; cellArray[3][8].color = 7;
				cellArray[4][0].color = 1; cellArray[4][1].color = 1; cellArray[4][2].color = 1;cellArray[4][3].color = 1; cellArray[4][4].color = 4; cellArray[4][5].color = 7;cellArray[4][6].color = 7; cellArray[4][7].color = 7; cellArray[4][8].color = 7;
				cellArray[5][0].color = 1; cellArray[5][1].color = 2; cellArray[5][2].color = 2;cellArray[5][3].color = 2; cellArray[5][4].color = 4; cellArray[5][5].color = 7;cellArray[5][6].color = 7; cellArray[5][7].color = 7; cellArray[5][8].color = 7;
				cellArray[6][0].color = 2; cellArray[6][1].color = 2; cellArray[6][2].color = 2;cellArray[6][3].color = 4; cellArray[6][4].color = 4; cellArray[6][5].color = 4;cellArray[6][6].color = 8; cellArray[6][7].color = 8; cellArray[6][8].color = 8;
				cellArray[7][0].color = 2; cellArray[7][1].color = 2; cellArray[7][2].color = 5;cellArray[7][3].color = 5; cellArray[7][4].color = 5; cellArray[7][5].color = 5;cellArray[7][6].color = 8; cellArray[7][7].color = 8; cellArray[7][8].color = 8;
				cellArray[8][0].color = 2; cellArray[8][1].color = 5; cellArray[8][2].color = 5;cellArray[8][3].color = 5; cellArray[8][4].color = 5; cellArray[8][5].color = 5;cellArray[8][6].color = 8; cellArray[8][7].color = 8; cellArray[8][8].color = 8;
				
				cellArray[0][0].value = 6; cellArray[0][0].enabled = NO;
				cellArray[0][3].value = 7; cellArray[0][3].enabled = NO;
				cellArray[0][5].value = 4; cellArray[0][5].enabled = NO;
				cellArray[0][7].value = 3; cellArray[0][7].enabled = NO;
				cellArray[0][8].value = 1; cellArray[0][8].enabled = NO;
				cellArray[1][1].value = 8; cellArray[1][1].enabled = NO;
				cellArray[1][6].value = 6; cellArray[1][6].enabled = NO;
				cellArray[2][6].value = 2; cellArray[2][6].enabled = NO;
				cellArray[3][1].value = 6; cellArray[3][1].enabled = NO;
				cellArray[3][5].value = 8; cellArray[3][5].enabled = NO;
				cellArray[3][6].value = 3; cellArray[3][6].enabled = NO;
				cellArray[4][4].value = 4; cellArray[4][4].enabled = NO;
				cellArray[5][7].value = 4; cellArray[5][7].enabled = NO;
				cellArray[6][2].value = 7; cellArray[6][2].enabled = NO;
				cellArray[6][6].value = 4; cellArray[6][6].enabled = NO;
				cellArray[7][2].value = 1; cellArray[7][2].enabled = NO;
				cellArray[7][7].value = 7; cellArray[7][7].enabled = NO;
				cellArray[8][0].value = 4; cellArray[8][0].enabled = NO;
				cellArray[8][1].value = 5; cellArray[8][1].enabled = NO;
				cellArray[8][3].value = 9; cellArray[8][3].enabled = NO;
				cellArray[8][5].value = 7; cellArray[8][5].enabled = NO;
				cellArray[8][6].value = 1; cellArray[8][6].enabled = NO;
				cellArray[8][8].value = 3; cellArray[8][8].enabled = NO;
				break;

			case 4:
				cellArray[0][0].color = 0; cellArray[0][1].color = 0; cellArray[0][2].color = 0;cellArray[0][3].color = 4; cellArray[0][4].color = 4; cellArray[0][5].color = 4;cellArray[0][6].color = 4; cellArray[0][7].color = 4; cellArray[0][8].color = 6;
				cellArray[1][0].color = 1; cellArray[1][1].color = 0; cellArray[1][2].color = 0;cellArray[1][3].color = 4; cellArray[1][4].color = 4; cellArray[1][5].color = 4;cellArray[1][6].color = 6; cellArray[1][7].color = 4; cellArray[1][8].color = 6;
				cellArray[2][0].color = 1; cellArray[2][1].color = 1; cellArray[2][2].color = 0;cellArray[2][3].color = 0; cellArray[2][4].color = 5; cellArray[2][5].color = 5;cellArray[2][6].color = 6; cellArray[2][7].color = 6; cellArray[2][8].color = 6;
				cellArray[3][0].color = 1; cellArray[3][1].color = 1; cellArray[3][2].color = 0;cellArray[3][3].color = 0; cellArray[3][4].color = 5; cellArray[3][5].color = 5;cellArray[3][6].color = 6; cellArray[3][7].color = 6; cellArray[3][8].color = 6;
				cellArray[4][0].color = 1; cellArray[4][1].color = 1; cellArray[4][2].color = 1;cellArray[4][3].color = 1; cellArray[4][4].color = 5; cellArray[4][5].color = 5;cellArray[4][6].color = 5; cellArray[4][7].color = 7; cellArray[4][8].color = 7;
				cellArray[5][0].color = 3; cellArray[5][1].color = 3; cellArray[5][2].color = 1;cellArray[5][3].color = 3; cellArray[5][4].color = 3; cellArray[5][5].color = 5;cellArray[5][6].color = 7; cellArray[5][7].color = 7; cellArray[5][8].color = 7;
				cellArray[6][0].color = 3; cellArray[6][1].color = 3; cellArray[6][2].color = 3;cellArray[6][3].color = 3; cellArray[6][4].color = 8; cellArray[6][5].color = 8;cellArray[6][6].color = 8; cellArray[6][7].color = 7; cellArray[6][8].color = 7;
				cellArray[7][0].color = 2; cellArray[7][1].color = 2; cellArray[7][2].color = 2;cellArray[7][3].color = 3; cellArray[7][4].color = 8; cellArray[7][5].color = 8;cellArray[7][6].color = 8; cellArray[7][7].color = 7; cellArray[7][8].color = 7;
				cellArray[8][0].color = 2; cellArray[8][1].color = 2; cellArray[8][2].color = 2;cellArray[8][3].color = 2; cellArray[8][4].color = 2; cellArray[8][5].color = 2;cellArray[8][6].color = 8; cellArray[8][7].color = 8; cellArray[8][8].color = 8;
				
				cellArray[0][0].value = 5; cellArray[0][0].enabled = NO;
				cellArray[0][2].value = 9; cellArray[0][2].enabled = NO;
				cellArray[0][6].value = 8; cellArray[0][6].enabled = NO;
				cellArray[0][8].value = 1; cellArray[0][8].enabled = NO;
				cellArray[1][1].value = 4; cellArray[1][1].enabled = NO;
				cellArray[1][6].value = 6; cellArray[1][6].enabled = NO;
				cellArray[1][7].value = 5; cellArray[1][7].enabled = NO;
				cellArray[2][3].value = 1; cellArray[2][3].enabled = NO;
				cellArray[2][5].value = 8; cellArray[2][5].enabled = NO;
				cellArray[3][2].value = 2; cellArray[3][2].enabled = NO;
				cellArray[3][5].value = 1; cellArray[3][5].enabled = NO;
				cellArray[3][6].value = 7; cellArray[3][6].enabled = NO;
				cellArray[4][0].value = 3; cellArray[4][0].enabled = NO;
				cellArray[4][6].value = 4; cellArray[4][6].enabled = NO;
				cellArray[4][8].value = 7; cellArray[4][8].enabled = NO;
				cellArray[5][2].value = 1; cellArray[5][2].enabled = NO;
				cellArray[5][3].value = 2; cellArray[5][3].enabled = NO;
				cellArray[5][5].value = 5; cellArray[5][5].enabled = NO;
				cellArray[6][3].value = 3; cellArray[6][3].enabled = NO;
				cellArray[6][5].value = 4; cellArray[6][5].enabled = NO;
				cellArray[7][1].value = 2; cellArray[7][1].enabled = NO;
				cellArray[7][7].value = 8; cellArray[7][7].enabled = NO;
				cellArray[8][0].value = 8; cellArray[8][0].enabled = NO;
				cellArray[8][2].value = 4; cellArray[8][2].enabled = NO;
				cellArray[8][6].value = 2; cellArray[8][6].enabled = NO;
				cellArray[8][8].value = 6; cellArray[8][8].enabled = NO;


				break;
		}
		
		
		for(int j = 0; j < 9; j++)
			for (int i = 0; i < 9; i++) {
				switch (cellArray[j][i].color){
					case 0:
						[color0Array addObject:cellArray[j][i]];
						break;
					case 1:
						[color1Array addObject:cellArray[j][i]];
						break;
					case 2:
						[color2Array addObject:cellArray[j][i]];
						break;
					case 3:
						[color3Array addObject:cellArray[j][i]];
						break;
					case 4:
						[color4Array addObject:cellArray[j][i]];
						break;
					case 5:
						[color5Array addObject:cellArray[j][i]];
						break;
					case 6:
						[color6Array addObject:cellArray[j][i]];
						break;
					case 7:
						[color7Array addObject:cellArray[j][i]];
						break;
					case 8:
						[color8Array addObject:cellArray[j][i]];
						break;
					default:
						break;		
				}
			}
	}
}

- (void)solnArrayInit{
	solnArray[0][0] = 5; solnArray[0][1] = 1; solnArray[0][2] = 2;
	solnArray[0][3] = 3; solnArray[0][4] = 6; solnArray[0][5] = 9;
	solnArray[0][6] = 4; solnArray[0][7] = 8; solnArray[0][8] = 7;
	
	solnArray[1][0] = 3; solnArray[1][1] = 6; solnArray[1][2] = 7;
	solnArray[1][3] = 2; solnArray[1][4] = 8; solnArray[1][5] = 4;
	solnArray[1][6] = 1; solnArray[1][7] = 9; solnArray[1][8] = 5;
	
	solnArray[2][0] = 4; solnArray[2][1] = 8; solnArray[2][2] = 9;
	solnArray[2][3] = 1; solnArray[2][4] = 7; solnArray[2][5] = 5;
	solnArray[2][6] = 2; solnArray[2][7] = 3; solnArray[2][8] = 6;
	
	solnArray[3][0] = 6; solnArray[3][1] = 7; solnArray[3][2] = 4;
	solnArray[3][3] = 8; solnArray[3][4] = 1; solnArray[3][5] = 3;
	solnArray[3][6] = 5; solnArray[3][7] = 2; solnArray[3][8] = 9;
	
	solnArray[4][0] = 1; solnArray[4][1] = 3; solnArray[4][2] = 5;
	solnArray[4][3] = 9; solnArray[4][4] = 2; solnArray[4][5] = 7;
	solnArray[4][6] = 6; solnArray[4][7] = 4; solnArray[4][8] = 8;
	
	solnArray[5][0] = 9; solnArray[5][1] = 2; solnArray[5][2] = 8;
	solnArray[5][3] = 4; solnArray[5][4] = 5; solnArray[5][5] = 6;
	solnArray[5][6] = 3; solnArray[5][7] = 7; solnArray[5][8] = 1;
	
	solnArray[6][0] = 7; solnArray[6][1] = 4; solnArray[6][2] = 3;
	solnArray[6][3] = 6; solnArray[6][4] = 9; solnArray[6][5] = 1;
	solnArray[6][6] = 8; solnArray[6][7] = 5; solnArray[6][8] = 2;
	
	solnArray[7][0] = 2; solnArray[7][1] = 5; solnArray[7][2] = 6;
	solnArray[7][3] = 7; solnArray[7][4] = 3; solnArray[7][5] = 8;
	solnArray[7][6] = 9; solnArray[7][7] = 1; solnArray[7][8] = 4;
	
	solnArray[8][0] = 8; solnArray[8][1] = 9; solnArray[8][2] = 1;
	solnArray[8][3] = 5; solnArray[8][4] = 4; solnArray[8][5] = 2;
	solnArray[8][6] = 7; solnArray[8][7] = 6; solnArray[8][8] = 3;
}

- (void)debugPrintBoard{
	for(int i = 0;i<9;i++){
		for(int j = 0;j<9;j++){
			cellArray[i][j] =[[cell alloc]init];
		}
	}
	
	for(int i = 0; i<9; i++){
		for(int j = 0; j<9; j++){
			cellArray[i][j].value = solnArray[i][j];
			cellArray[i][j].enabled = NO;
		}
	}
}

- (void)generateRandBoard{
	for(int i = 0; i < arc4random()%10; i++){	//do each kind of shuffle 10 times
		//swap 3 rows by 3 rows
		int bigRowA = arc4random() % 3; //bigRow means the 3rows together
		int bigRowB = arc4random() % 3;
		if (bigRowA != bigRowB) {
			[self swapRow:bigRowA*3 rowone:bigRowB*3];
			[self swapRow:bigRowA*3+1 rowone:bigRowB*3+1];
			[self swapRow:bigRowA*3+2 rowone:bigRowB*3+2];	//we have to swap the 3 rows together to preserve valid state
		}
	}
	
	for(int i = 0; i < arc4random()%10; i++){
		//swap 3 cols by 3 cols
		int bigColA = arc4random() % 3; //bigRow means the 3rows together
		int bigColB = arc4random() % 3;
		if (bigColA != bigColB) {
			[self swapCol:bigColA*3 colone:bigColB*3];
			[self swapCol:bigColA*3+1 colone:bigColB*3+1];
			[self swapCol:bigColA*3+2 colone:bigColB*3+2];	//swap 3 cols tgt to preserve validity
		}
	}
	
	for(int i = 0; i < arc4random()%10; i++){
		//swap row by row within a single bigRow
		int rowA = arc4random() % 3; //if we swap eg. 0 with 3, game state might become invalid
		int rowB = arc4random() % 3;
		if (rowA != rowB) {
			[self swapRow:rowA rowone:rowB];
		}
		rowA = arc4random()%3 + 3;
		rowB = arc4random()%3 + 3;
		if (rowA != rowB) {
			[self swapRow:rowA rowone:rowB];
		}
		rowA = arc4random()%3 + 6;
		rowB = arc4random()%3 + 6;
		if (rowA != rowB) {
			[self swapRow:rowA rowone:rowB];
		}
	}
	
	for(int i = 0; i < arc4random()%10; i++){
		//swap col by col within bigCol
		int colA = arc4random() % 3; //if we swap eg. 0 with 3, game state might become invalid
		int colB = arc4random() % 3;
		if (colA != colB) {
			[self swapCol:colA colone:colB];
		}
		colA = arc4random()%3 + 3;
		colB = arc4random()%3 + 3;
		if (colA != colB) {
			[self swapCol:colA colone:colB];
		}
		colA = arc4random()%3 + 6;
		colB = arc4random()%3 + 6;
		if (colA != colB) {
			[self swapCol:colA colone:colB];
		}
	}
}

- (void)swapRow:(int)r0 rowone:(int)r1{
	for(int col=0; col<9; col++){
		[self swap:r0 czero:col rone:r1 cone:col];
	}
}

- (void)swapCol:(int)c0 colone:(int)c1{
	for(int row=0; row<9; row++){
		[self swap:row czero:c0 rone:row cone:c1];
	}
}

- (void) swap:(int)r0 czero:(int)c0 rone:(int)r1 cone:(int)c1{
	int temp = solnArray[r0][c0];
	solnArray[r0][c0] = solnArray[r1][c1];
	solnArray[r1][c1] = temp;
}

- (cell*) getcell:(int)j column:(int)i{
	return cellArray[j][i];
}

- (void) cleancell:(int)j column:(int)i{
	cellArray[j][i].value = 0;
}

- (void) restart{
	for(int i = 0; i < 9; i++)
		for(int j = 0; j < 9; j++){
			if(cellArray[j][i].enabled)
				cellArray[j][i].value = 0;
		}
}


@end

