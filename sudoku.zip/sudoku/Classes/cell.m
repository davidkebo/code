//
//  cell.m
//  ShowDoku
//
//  Written by: Cadrian Chan & David Houngninou & Yu-Ying Liang
//	CS436 Washington University in St. Louis
//  Copyright 2010 All rights reserved.

#import "cell.h"
@implementation cell
@synthesize value,enabled,color,hint;

- (id)init {
	self.value = 0;
	self.enabled = YES;
	self.color = 1;
	self.hint = 0;
	
	return self;
}	

@end