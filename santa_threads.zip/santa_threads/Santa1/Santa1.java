import java.util.ArrayList;
import java.util.Scanner;

// Santa class
public class Santa1 {

	public static void main (String [] args) throws InterruptedException {

		// data structure shared by threads
		ArrayList<String> work = new ArrayList<String>();

		// setup Santa and UI thread - pass them the shared work array
		Santa ourSanta = new Santa(work);
		UI ourUI = new UI(work);

		// Add handle on each objects
		ourSanta.UIhandle(ourUI);
		ourUI.Santahandle(ourSanta);

		// Start both threads
		ourUI.start();
		ourSanta.start();
	}
}

// UI class
class UI extends Thread{
	// Scanner is a usefult Java class for reading a line at a time
	Scanner sc = new Scanner(System.in);
	Santa ourSanta;

	ArrayList <String> workList;

	// Boolean flag that can be changed by user typing "quit"
	private boolean keepWorking = true;

	// constructor
	public UI(ArrayList<String>  workList) {
		this.workList = workList;
	}

	public boolean getKeepWorking() {
		return keepWorking;
	}

	public void setKeepWorking(boolean keepWorking) {
		this.keepWorking = keepWorking;
	}

	public void run() {

		while(keepWorking ) {
			String line = sc.nextLine(); // Get user input

			// If UI thread receives 'quit' from standard input
			if(line.matches("quit")){
				setKeepWorking(false);
				Log.log("UI thread received quit signal, terminating ...");
			}

			// If the Santa sends an interrupt signal shutdown
			else if (Thread.currentThread().isInterrupted()){
				setKeepWorking(false);
				Log.log("UI thread is interrupted by Santa, terminating ...");
			}

			// Otherwise notify Santa of additional work
			else {
				taskMaker (line); // Add multiple tasks to the work list
				Log.log("Work Request: " + line);
				synchronized(ourSanta) {
					ourSanta.notify();
				}
			}
		} // end while
	} // end Run

	// Split a string of tasks and add tasks to the worklist
	public void taskMaker (String userInput){
		String[] result = userInput.split(",");
		for (int i=0; i<result.length; i++){
			workList.add(result[i]);
		}
	}

	// Handle on Santa object
	public void Santahandle(Santa ourSanta){
		this.ourSanta = ourSanta;
	}
}

class Santa extends Thread {

	private int rounds = 0, power = 100;
	UI ourUI;
	private ArrayList <String> workList;

	public Santa(ArrayList<String> work) {
		workList = work;
	}

	public void run() {
		// work loop for Santa as long as he has power
		Log.log("Santa starting work power: " + power);

		while (isStillAlive() ) {
			// Wait for UI Thread notify
			synchronized(this) {
				try {
					wait();
				} catch(InterruptedException e) {
					throw new RuntimeException(e);
				}
			}
			// Santa wakes up and start the work in the queue
			rounds = workList.size();

			for (int i=0; i<rounds; i++) {
				doWork();
				power--;
				if ((power % 10)==0)Log.log("Santa power=" + power);
			}
		}
		// Poor Santa has died. Terminate the UI Thread
		ourUI.interrupt();
		Log.log("Santa is now deceased :( ");
	}

	public boolean isStillAlive() {
		return (power > 0);
	}

	private void doWork() {
		// we have work so let's do it by removing from workList
		String workid = workList.remove(0);
		Log.log("log: santa working on " + workid + " power=" + power);
	}

	// Handle on UI object
	public void UIhandle(UI ourUI){
		this.ourUI = ourUI;
	}
}

class Log {
	public static void log(String line) {
		System.out.println(line);
	}
}