#include <stdio.h> 
#include <stdlib.h> 
#include <pthread.h>
#include <iostream>
#include <string>
#include <queue>
using namespace std;

void *ui_function( void *ptr );
void *santa_function( void *ptr );
pthread_mutex_t work_mutex = PTHREAD_MUTEX_INITIALIZER;

// Incoming work requests are kept in this queue
// data structure shared by threads
queue<int> workqueue;
bool is_running = true;

main() 
{
	// UI thread and Santa thread
	pthread_t ui_thread, santa_thread; 
	
	// Create independent threads each of which will execute their task
	pthread_create( &ui_thread, NULL, ui_function, NULL);
	pthread_create( &santa_thread, NULL, santa_function, NULL);
	
	// Wait to thread to complete
	pthread_join( ui_thread, NULL); 
	pthread_join( santa_thread, NULL);
	
	exit(0);
}

void *ui_function( void *ptr ) 
{
	int input; // user input
	bool done = false;
	
	while (is_running)
	{
		for ( ; ; ) {
			if ( std::cin>> input )
				break;
			// Clean up the mess
			std::cin.clear();
			std::cin.ignore ( std::numeric_limits<std::streamsize>::max(), '\n' );
			std::cerr<<"Enter numbers only\n";
		}
		
		// If UI thread receives 'quit' from standard input
		if (input == 1 /*"quit"*/)
		{
			is_running = false;
			printf("UI thread received quit signal, terminating ...\n");
		}
		else 
		{
			printf("Work request: %d \n", input);
			// Apply mutex to protect critical region
			pthread_mutex_lock(&work_mutex);
			workqueue.push(input);
			pthread_mutex_unlock(&work_mutex);
		}
	}
	printf("UI thread terminated \n");
}

void *santa_function( void *ptr ) 
{
	int power= 100;
	int queuesize = 0;
	// work loop for Santa as long as he has power
	printf("Santa starting work power: %d \n", power);
	
	// work loop for Santa as long as he has power
	while (power>0) {
		queuesize = workqueue.size();
		
		if (queuesize >= 3)
		{
			for (int i=0; i<queuesize; i++) {
				printf("log: santa working on %d power = %d \n", workqueue.front(), power);
				// UI cannot add to the queue will Santa is working
				// Apply mutex to protect critical region
				pthread_mutex_lock(&work_mutex);
				workqueue.pop();
				pthread_mutex_unlock(&work_mutex);
				power--;
			}
		}
	}
	
	// Poor Santa has died. Terminate the UI Thread
	printf("Santa is now deceased :(  \n");
	is_running = false;
}