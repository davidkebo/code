This is the C++ version of Santa:
- does not support characters, type numbers instead
- does not support comma separators
- Type '1' to quit

David Kebo Houngninou
