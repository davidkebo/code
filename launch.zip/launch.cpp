/* File:launch.cpp
   Program launcher application
   ----------------------------------------------------------------
   Class: CS 375			 Instructor: Dr. Richardson
   Assignment: Project 5		 Date assigned: October 21, 2008 
   Programmer: David Houngninou		 Date completed: October 30, 2008  */

#include <signal.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <iostream>
#include <iomanip>
using namespace std;

int choice; 
void displayMenu(); // Displays a menu of options to the user

int main(int argc, char *argv[]) // Main function
{
  displayMenu();
  int pid, status;
  
  while (choice != 0)
    {
      switch (choice) 
	{ 
	case 1: // Gnuplot
	  
	  pid = fork();
	  switch (pid) 
	    {
	    case -1:
	      cerr << "fork error" << endl;
	      break;
	    case 0: // Child
	      execlp("gnuplot","gnuplot", (char *)0);
	      break;
	    default: // Parent waits until child finishes
	      wait(&status);	 
	      // Clear the screen and redisplay the menu
	      system("clear");
	      cout << "Child has finished (PID = " << pid << ")" << endl;
	      if(WIFEXITED(status))
		cout << "Child exit status: " << WEXITSTATUS(status) << endl;
	      else
		cout << "Child exitted abnormally." << endl;
	      
	      displayMenu();
	      
	      break;
	    }
	  
	  break;
	  
	case 2: // Octave
	  
	  pid = fork();
	  switch (pid) 
	    {
	    case -1:
	      cerr << "fork error" << endl;
	      break;
	    case 0: // Child
	      execlp("octave","octave", (char *)0);
	      break;
	    default: // Parent waits until child finishes
	      wait(&status);
	      // Clear the screen and redisplay the menu
	      system("clear");
	      cout << "Child has finished (PID = " << pid << ")" << endl;
	      if(WIFEXITED(status))
		cout << "Child exit status: " << WEXITSTATUS(status) << endl;
	      else
		cout << "Child exitted abnormally." << endl;
	      
	      displayMenu();
	      
	      break;
	    }
	  
	  break;
	  
	case 3: // Bash
	  
	  pid = fork();
	  switch (pid) 
	    {
	    case -1:
	      cerr << "fork error" << endl;
	      break;
	    case 0: // Child
	      execlp("bash","bash", (char *)0); 
	      break;
	    default: // Parent waits until child finishes
	      wait(&status);	
	      // Clear the screen and redisplay the menu
	      system("clear");
	      cout << "Child has finished (PID = " << pid << ")" << endl;
	      if(WIFEXITED(status))
		cout << "Child exit status: " << WEXITSTATUS(status) << endl;
	      else
		cout << "Child exitted abnormally." << endl;
	      
	      displayMenu();
	      
	      break;
	    }
	  
	  break;
	  
	case 4: // Launch
	  
	  pid = fork();
	  switch (pid) 
	    {
	    case -1:
	      cerr << "fork error" << endl;
	      break;
	    case 0: // Child 
	      if ( (pid = fork()) == 0) // second child (To avoid Zombies)
		execlp("gnome-terminal","gnome-terminal","-x", "./launch", (char *)0);
	      // First child, so exit. Second process is adopted by init
	      exit(0);
	      break;     
	    default: 
	      // Clear the screen and redisplay the menu
	      system("clear");
	      displayMenu();	      
	      break;
	    }
	  
	  break;
	  
	case 5: // OpenOffice writer	  
	  
	  pid = fork();
	  switch (pid) 
	    {
	    case -1:
	      cerr << "fork error" << endl;
	      break;
	    case 0: // Child
	      if ( (pid = fork()) == 0) // second child (To avoid Zombies)
		execlp("oowriter","oowriter", (char *)0);
	      // First child, so exit. Second process is adopted by init
	      exit(0);
	      break;
	    default: 
	      // Clear the screen and redisplay the menu
	      system("clear");
	      displayMenu();
	      
	      break;
	    }
	  
	  break;
	  
	case 6: // OpenOffice calc
	  
	  pid = fork();
	  switch (pid) 
	    {
	    case -1:
	      cerr << "fork error" << endl;
	      break;
	    case 0: // Child
	      if ( (pid = fork()) == 0) // second child (To avoid Zombies)
		execlp("oocalc","oocalc", (char *)0);
	      // First child, so exit. Second process is adopted by init
	      exit(0);
	      break;
	    default: 
	      // Clear the screen and redisplay the menu
	      system("clear");
	      displayMenu();
	      
	      break;
	    }
	  
	  break;
	  
	case 7: // Firefox home page
	  
	  pid = fork();
	  switch (pid) 
	    {
	    case -1:
	      cerr << "fork error" << endl;
	      break;
	    case 0: // Child
	      if ( (pid = fork()) == 0) // second child (To avoid Zombies)
		execlp("firefox","firefox", (char *)0);
	      // First child, so exit. Second process is adopted by init
	      exit(0);
	      break;
	    default: 
	      // Clear the screen and redisplay the menu
	      system("clear");
	      displayMenu();
	      
	      break;
	    }
	  
	  break;
	  
	case 8: // Firefox Ubuntu page
	  
	  pid = fork();
	  switch (pid) 
	    {
	    case -1:
	      cerr << "fork error" << endl;
	      break;
	    case 0: // Child
	      if ( (pid = fork()) == 0) // second child (To avoid Zombies)
		execlp("firefox","firefox","www.ubuntu.com", (char *)0);
	      // First child, so exit. Second process is adopted by init
	      exit(0);
	      break;
	    default: 
	      // Clear the screen and redisplay the menu
	      system("clear");
	      displayMenu();
	      
	      break;
	    }
	  
	  break;
	} 
    } // End While
  return 0;
} // End Main

void displayMenu() // Displays a menu of options to the user
{
  // User Menu
  printf ("\nMenu Options: ");
  printf ("\nType 1 for gnuplot.");
  printf ("\nType 2 for octave.");
  printf ("\nType 3 for bash.");
  printf ("\nType 4 for launch.");
  printf ("\nType 5 for OpenOffice Writer.");
  printf ("\nType 6 for OpenOffice Calc.");
  printf ("\nType 7 for Firefox home page.");
  printf ("\nType 8 for Firefox Ubuntu page.");
  printf ("\nType 0 to exit the program.\n");
  printf ("\nEnter your choice: ");
  
  scanf ("%d",&choice);
} // End displayMenu()

