using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;

namespace Project1
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamReader infile = new StreamReader("Staff.csv");
            string line;
            string[] studentParams = new string[4];
            Student[] classArray = new Student[20];
            int counter = 0;
            line = infile.ReadLine();
            //reads in students from the input file and stores them in classArray
            while( line != null)
            {
                Student tempStudent = new Student();

                studentParams = line.Split(',');

                tempStudent.LastName = studentParams[0];
                tempStudent.FirstName = studentParams[1];
                tempStudent.Email = studentParams[2];
                tempStudent.Group = studentParams[3];

                classArray.SetValue(tempStudent, counter);
                
                line = infile.ReadLine();
                counter++;
            }//end while

            char choice = ' ';
            string strchoice = " ";

            //asks user to choose function
            while ((choice!= 'q')&&(choice!= 'Q'))
            {
                Student s1 = new Student(); // student object
                StudentFunctions.PrintMenu();
                strchoice = System.Console.ReadLine();
                choice = strchoice[0];

                //perform function requested by user
               switch (choice)
               { 
                   case 'a':
                   case'A':
                       Console.WriteLine("Please enter the information of the student you want to add: ");
                       s1.GetStudent();
                       StudentFunctions.AddStudent(classArray, s1);
                       break;
                   case 'r':
                   case'R':
                       Console.WriteLine("Please enter the information of the student you want to remove: ");
                       s1.GetStudent();
                       StudentFunctions.RemoveStudent(classArray, s1);   
                       break;
                   case 'm':
                   case'M':
                        Console.WriteLine("Please enter the information of the student you want to modify: ");
                        s1.GetStudent();
                        StudentFunctions.ModifyStudent(classArray, s1);
                        break;
                   case 'f':
                   case'F':
                        StudentFunctions.FindStudent(classArray);
                        break;
                   case'l':
                   case'L':
                       StudentFunctions.ListStudent(classArray);
                       break;
                   case'g':
                   case'G':
                       StudentFunctions.ReportGroup(classArray);
                       break;
                   case'q':
                   case'Q':
                       break;
                   default:
                        Console.WriteLine("This is not a valid entry, please try again.");
                        break;
                 }//end switch
            } // end while
 
            System.Console.WriteLine();     // write blank line to console
        }//end Main
    }//end class Program
}//end namespace Project1
