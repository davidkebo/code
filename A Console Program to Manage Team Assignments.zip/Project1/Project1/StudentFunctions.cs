using System;
using System.IO;
//using System.Collections.Generic;
//using System.Text;

namespace Project1
{
    class StudentFunctions
    {
        //Function: AddStudent
        //This function adds a student to StudentArray
        //In: Student[], Student
        //Out: void
        public static void AddStudent(Student[] StudentArray, Student aStudent)
        {
            //searches for already exisiting student
            if (SearchStudent(ref StudentArray, aStudent) == true)
                Console.WriteLine("\nThis entry already exists in the file\n");
            else
            {
                //saves student in alphabetical order
                SaveStudent(StudentArray, aStudent);
                Console.WriteLine("\nStudent successfully added\n");
            }//end else
        }//end AddStudent

        //Function: RemoveStudent
        //This function removes a student from StudentArray
        //In: Student[], Student
        //Out: void
        public static void RemoveStudent(Student[] StudentArray, Student aStudent)
        {
            int index;
            //searches for student to remove
            if (SearchStudent(ref StudentArray, aStudent) == false)
                Console.WriteLine("\nThe entry you are trying to remove is not in the file\n");
            else
            {
                //determines the index in StudentArray of aStudent
               index = GetIndex(StudentArray, aStudent);
                //Deletes the student at index from StudentArray
               DeleteStudent(StudentArray, index);
               Console.WriteLine("\nThe entry has been succesfully removed from the list\n");
            }//end else
        }//end RemoveStudent

        //Function: ModifyStudent
        //This function makes changes to a student from StudentArray
        //In: Student[], Student
        //Out: void
        public static void ModifyStudent(Student[] StudentArray, Student aStudent)
        {
            char choice = ' ';
            string strchoice = " ";
            int index;
            string modification;

            //as long as aStudent is found, make modifications
            if (SearchStudent(ref StudentArray, aStudent) == true)
            {   // The user chooses which field he wants to modify
                index = GetIndex(StudentArray, aStudent);

                while ((choice != 'q') && (choice != 'Q'))
                {
                    Console.WriteLine("L. Modify the last name");
                    Console.WriteLine("F. Modify the first name");
                    Console.WriteLine("E. Modify the email");
                    Console.WriteLine("G. Modify the group");
                    Console.WriteLine("Q. Quit");
                    Console.WriteLine("Please make a choice: ");
                    strchoice = Console.ReadLine();
                    choice = strchoice[0];

                    //make the selected modification
                    switch (choice)
                    {
                        case 'l':
                        case 'L':
                            Console.WriteLine("Please enter the new Last name");
                            modification = Console.ReadLine();
                            StudentArray[index].LastName = modification;
                            Console.WriteLine("\nModification made\n");
                            break;
                        case 'f':
                        case 'F':
                            Console.WriteLine("Please enter the new first name");
                            modification = Console.ReadLine();
                            StudentArray[index].FirstName = modification;
                            Console.WriteLine("\nModification made\n");
                            break;
                        case 'e':
                        case 'E':
                            Console.WriteLine("Please enter the new email");
                            modification = Console.ReadLine();
                            StudentArray[index].Email = modification;
                            Console.WriteLine("\nModification made\n");
                            break;
                        case 'g':
                        case 'G':
                            Console.WriteLine("Please enter the new group");
                            modification = Console.ReadLine();
                            StudentArray[index].Group = modification;
                            Console.WriteLine("\nModification made\n");
                            break;
                        case 'q':
                        case'Q':
                            break;
                        default:
                            Console.WriteLine("This is not a valid entry.");
                            break;
                    }//end switch
                }//end while
            }//end if
            else
                Console.WriteLine("The entry you are trying to modify is not in the file");
        }//end ModifyStudent

        //Function: FindStudent
        //This function finds a student in StudentArray
        //In: Student[]
        //Out: void
        public static void FindStudent(Student[] StudentArray)
        {
            //this is the array containing the list of students matching
            Student[] StudentsFound = new Student[20];  
            char choice;
            string strchoice;
            string search;

            // This is the list of fields for the user to choose from
            System.Console.WriteLine("L. Search by last name");
            System.Console.WriteLine("F. Search by first name");
            System.Console.WriteLine("E. Search by email");
            System.Console.WriteLine("G. Search by group");
            System.Console.WriteLine("Please make a choice: ");
            strchoice = System.Console.ReadLine();
            choice = strchoice[0];

            //search for students based on the chosen field
            switch (choice)
            {
                case 'l':
                case 'L':
                    Console.WriteLine("Please enter the last name");
                    search = Console.ReadLine();
                    //search StudentArray for the last name entered
                    for (int i = 0, j=0; i < StudentArray.GetLength(0); i++)
                    {
                        if (StudentArray[i] != null)
                        {
                            //if the last names match add that student to StudentsFound
                            if (StudentArray[i].LastName == search)
                            {
                                StudentsFound[j] = StudentArray[i];
                                j++;
                            }//end if
                        }//end if
                    }//end for
                    break;

                case 'f':
                case 'F':
                    Console.WriteLine("Please enter the first name");
                    search = Console.ReadLine();
                    //search StudentArray for the first name entered
                    for (int i = 0, j=0; i < StudentArray.GetLength(0); i++)
                    {
                        if (StudentArray[i] != null)
                        {
                            //if the first names match add that student to StudentsFound
                            if (StudentArray[i].FirstName == search)
                            {
                                StudentsFound[j] = StudentArray[i];
                                j++;
                            }//end if
                        }//end if
                    }//end for
                    break;

                case 'e':
                case 'E':
                    Console.WriteLine("Please enter the email");
                    search = Console.ReadLine();
                    //search StudentArray for the email entered
                    for (int i = 0, j=0; i < StudentArray.GetLength(0); i++)
                    {
                        if (StudentArray[i] != null)
                        {
                            //if the emails match add that student to StudentsFound
                            if (StudentArray[i].Email == search)
                            {
                                StudentsFound[j] = StudentArray[i];
                                j++;
                            }//end if
                        }//end if
                    }//end for
                    break;

                case 'g':
                case 'G':
                    Console.WriteLine("Please enter the group");
                    search = Console.ReadLine();
                    //search StudentArray for the group entered
                    for (int i = 0, j=0; i < StudentArray.GetLength(0); i++)
                    {
                        if (StudentArray[i] != null)
                        {
                            //if the groups match add that student to StudentsFound
                            if (StudentArray[i].Group == search)
                            {
                                StudentsFound[j] = StudentArray[i];
                                j++;
                            }//end if
                        }//end if
                    }//end for
                    break;

                default:
                    Console.WriteLine("This is not a valid entry.");
                    break;
            }//end switch

            //print out the list of students found
            Console.WriteLine("\nThe Students found in your search are: ");
            for (int i = 0; i < StudentArray.GetLength(0); i++)
            {
                if(StudentsFound[i] == null)
                {
                    Console.WriteLine("End of students found.\n");
                    break;
                }//end if
                else
                {
                    Console.WriteLine(StudentsFound[i]);
                }//end else
            }//end for

            //empty StudentsFound array
            for(int i = 0; i < StudentArray.GetLength(0); i++)
            {
                StudentsFound[i] = null;
            }//end for
        }//end FindStudent

        //Function: DeleteStudent
        //This function deletes the student at index from StudentArray
        //In: Student[], int
        //Out: void
        public static void DeleteStudent(Student[] StudentArray, int index)
        {
            for (int i = index; i < StudentArray.GetLength(0); i++)
            {
                //shifts students to the left, deleting student at index
                if (i == (StudentArray.GetLength(0) - 1))
                    StudentArray[i] = null;
                else
                    StudentArray[i] = StudentArray[i + 1];
            }//end for
        }//end DeleteStudent
 
        //Function: SearchStudent
        //This function returns true if aStudent is found in StudentArray
        //StudentArray passed by reference
        //In: Student[], Student
        //Out: bool
        public static bool SearchStudent(ref Student[] StudentArray, Student aStudent)
        {
            bool check = false;
            //searches for student match based on email
            for (int i = 0; i < StudentArray.GetLength(0); i++)
            {
                if (StudentArray[i] != null)
                {
                    if (StudentArray[i].Email == aStudent.Email)
                    {
                        check = true;
                    }//end if
                }//end if
            }//end for
            return check;
        }//end SearchStudent
        
        //Function: GetIndex
        //This function returns the index of aStudnet in StudentArray
        //Returns -1 if no index found
        //In: Student[], Student
        //Out: int
        public static int GetIndex(Student[] StudentArray, Student aStudent)
        {
            //searches for aStudent by matching email
            for (int i = 0; i < StudentArray.GetLength(0); i++)
            {
                if (StudentArray[i].Email == aStudent.Email)
                {
                    return i;
                }//end if
            }//end for
            return -1;
        }//end GetIndex

        //Function: SaveStudent
        //This function saves the given student in StudentArray
        //In: Student[], Student
        //Out: void
        public static void SaveStudent(Student[] StudentArray, Student aStudent)
        {
            //finds the end of the current list of students
            int index = 0;
            for (int i = 0; i < StudentArray.GetLength(0); i++)
            {
                if (StudentArray[i] == null)
                {
                    index = i;
                    break;
                }//end if
            }//end for

            //saves the new student at the end of the list
            StudentArray[index] = aStudent;

            //alphabetizes the students using sort algorithm
            bool pass = true;
            while (pass)
            {
                Student tempStudent = new Student();
                pass = false;

                for (int i = 0; i < StudentArray.GetLength(0); i++)
                {
                    if ((StudentArray[i] == null) || (StudentArray[i + 1] == null))
                    {
                        break;
                    }//end if

                    //switch students if i comes after i+1
                    else if (string.CompareOrdinal(StudentArray[i].LastName, StudentArray[i + 1].LastName) > 0)
                    {
                        pass = true;
                        tempStudent = StudentArray[i];
                        StudentArray[i] = StudentArray[i + 1];
                        StudentArray[i + 1] = tempStudent;
                    }//end else if
                }//end for
            }//end while
        }//end SaveStudent

        //Function: ListStudent
        //This function outputs the list of students to and output file and the screen
        //In: Student[]
        //Out: void
        public static void ListStudent(Student[] StudentArray)
        {
            SelectionSort(StudentArray);
            //  Write the string representation of the student objects to a file
            StreamWriter sw = new StreamWriter("TestFile.txt");
            for (int i = 0; i < StudentArray.GetLength(0); i++)
            {
                if(StudentArray[i] != null)
                    sw.WriteLine(StudentArray[i].ToString() + "\n");
            }//end for
            sw.Close();

            // Read the file created and echo contents to the console.
            StreamReader sr = new StreamReader("TestFile.txt");
            string line;
            line = sr.ReadLine();
            while (line != null)
            {
                Console.WriteLine(line);
                line = sr.ReadLine();
            }//end while
            sr.Close();

            // display the file (in Notepad)to see if it is as expected.
            System.Diagnostics.Process.Start("TestFile.txt");

            // Now stop the program and prompt user
            Console.WriteLine("\n\rPress ENTER to continue");
            line = Console.ReadLine();
        }//end ListStudent

        //Function: ReportGroup
        //This function outputs a list of the groups to an output file and and screen
        //In: Student[]
        //Out: void
        public static void ReportGroup(Student[] StudentArray)
        {
            //create an array of each group
            Student[] groupX = new Student[10];
            Student[] groupY = new Student[10];
            Student[] groupZ = new Student[10];
            int x = 0;
            int y = 0;
            int z = 0;

            //determine which students are in each group
            //put them in the respective group array
            for (int i = 0; i < StudentArray.GetLength(0); i++)
            {
                if (StudentArray[i] != null)
                {
                    if (StudentArray[i].Group == "X")
                    {
                        groupX[x] = StudentArray[i];
                        x++;
                    }//end if
                    else if (StudentArray[i].Group == "Y")
                    {
                        groupY[y] = StudentArray[i];
                        y++;
                    }//end else if
                    else if (StudentArray[i].Group == "Z")
                    {
                        groupZ[z] = StudentArray[i];
                        z++;
                    }//end else if
                }//end if
            }//end for

            //output each group to the output file
            StreamWriter sw = new StreamWriter("TestFile.txt");

            sw.WriteLine("Members of Group X are: ");
            for (int i = 0; i < groupX.GetLength(0); i++)
            {
                if (groupX[i] != null)
                    sw.WriteLine(groupX[i].ToString());
            }//end for

            sw.WriteLine("\nMembers of Group Y are: ");
            for (int i = 0; i < groupY.GetLength(0); i++)
            {
                if (groupY[i] != null)
                    sw.WriteLine(groupY[i].ToString());
            }//end for

            sw.WriteLine("\nMembers of Group Z are: ");
            for (int i = 0; i < groupZ.GetLength(0); i++)
            {
                if (groupZ[i] != null)
                    sw.WriteLine(groupZ[i].ToString());
            }//end for

            sw.Close();

            // Read the file created and echo contents to the console.
            StreamReader sr = new StreamReader("TestFile.txt");
            string line;
            line = sr.ReadLine();
            while (line != null)
            {
                Console.WriteLine(line);
                line = sr.ReadLine();
            }//end while
            sr.Close();            
        }//end ReportGroup

        //Function: SelectionSort
        // Extra function to sort the array of students by last names.
        //In: Student[]
        //Out: void
        public static void SelectionSort(Student[] StudentArray)
        {
            for (int pass = 0; pass < StudentArray.GetLength(0); pass++)
            {
                int smallIndex = pass;
                for (int j = pass + 1; j < StudentArray.GetLength(0); j++)
                {
                    if ((StudentArray[j] == null) || (StudentArray[j + 1] == null))
                        break;

                    else if (string.CompareOrdinal(StudentArray[j].LastName, StudentArray[smallIndex].LastName) < 0)
                        smallIndex = j;
                }//end for

                if (smallIndex != pass)
                {
                    Student temp = StudentArray[pass];
                    StudentArray[pass] = StudentArray[smallIndex];
                    StudentArray[smallIndex] = temp;
                }//end if
            }//end for
        } // end SelectionSort

        //Function: PrintMenu
        //Prints the users list of options to the screen
        //In: void
        //Out: void
        public static void PrintMenu()
        {
            Console.WriteLine("A. Add a student");
            Console.WriteLine("R. Remove a student");
            Console.WriteLine("M. Modify a Student");
            Console.WriteLine("F. Find a student");
            Console.WriteLine("L. Create list of all students");
            Console.WriteLine("G. Create report of each group");
            Console.WriteLine("Q. Quit");
            Console.WriteLine("Please make a choice: ");
        }  // end PrintMenu
    }//end class StudentFunctions
}//end namespace Project1
