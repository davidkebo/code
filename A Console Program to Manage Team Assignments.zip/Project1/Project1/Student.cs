using System;
using System.Collections.Generic;
using System.Text;

namespace Project1
{
    class Student
    {
        private string lastname;
        private string firstname;
        private string email;
        private string group;
       
        public Student()
        {
            lastname = "";
            firstname = "";
            email = "";
            group = "";
        }// end constructor with no params

        public Student(string lName, string fName, string eMail, string Group)
        {
            lastname = lName;
            firstname = fName;
            email = eMail;
            group = Group;
        }// end constructor with three params

        // Override default ToString()
        public override string ToString()
        {
            return this.lastname + ", " + this.firstname +
                "\t\t   Email: " + this.email + "\t\t   Group: " + this.group;
        }

        // property LastName
        public string LastName
        {
            get { return lastname; }
            set { lastname = value; }
        }// end property LastName

        // property FirstName
        public string FirstName
        {
            get { return firstname; }
            set { firstname = value; }
        }// end property FirstName

        // property Email
        public string Email
        {
            get { return email; }
            set { email = value; }
        }// end property Email

        // property Group
        public string Group
        {
            get { return group; }
            set { group = value; }
        }// end property Group

        //Function: GetStudent
        //This function gets a student from the user
        //In: void
        //Out: void
        public void GetStudent()
        {
            Console.Write("first name?   ");
            this.firstname = System.Console.ReadLine();

            Console.Write("last name?   ");
            this.lastname = System.Console.ReadLine();

            Console.Write("email  ");
            this.email = System.Console.ReadLine();

            Console.Write("group  ");
            this.group = System.Console.ReadLine();
        }//end GetStudent
    }//end class Student
}//end namespace Project1
