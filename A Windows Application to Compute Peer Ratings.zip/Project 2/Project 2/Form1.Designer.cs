namespace Project_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.t1 = new System.Windows.Forms.TabPage();
            this.p3 = new System.Windows.Forms.Panel();
            this.radioButton25 = new System.Windows.Forms.RadioButton();
            this.radioButton26 = new System.Windows.Forms.RadioButton();
            this.radioButton27 = new System.Windows.Forms.RadioButton();
            this.radioButton28 = new System.Windows.Forms.RadioButton();
            this.radioButton29 = new System.Windows.Forms.RadioButton();
            this.radioButton30 = new System.Windows.Forms.RadioButton();
            this.radioButton31 = new System.Windows.Forms.RadioButton();
            this.radioButton32 = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.p2 = new System.Windows.Forms.Panel();
            this.radioButton33 = new System.Windows.Forms.RadioButton();
            this.radioButton34 = new System.Windows.Forms.RadioButton();
            this.radioButton35 = new System.Windows.Forms.RadioButton();
            this.radioButton36 = new System.Windows.Forms.RadioButton();
            this.radioButton37 = new System.Windows.Forms.RadioButton();
            this.radioButton38 = new System.Windows.Forms.RadioButton();
            this.radioButton39 = new System.Windows.Forms.RadioButton();
            this.radioButton40 = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.p1 = new System.Windows.Forms.Panel();
            this.radioButton41 = new System.Windows.Forms.RadioButton();
            this.radioButton42 = new System.Windows.Forms.RadioButton();
            this.radioButton43 = new System.Windows.Forms.RadioButton();
            this.radioButton44 = new System.Windows.Forms.RadioButton();
            this.radioButton45 = new System.Windows.Forms.RadioButton();
            this.radioButton46 = new System.Windows.Forms.RadioButton();
            this.radioButton47 = new System.Windows.Forms.RadioButton();
            this.radioButton48 = new System.Windows.Forms.RadioButton();
            this.label7 = new System.Windows.Forms.Label();
            this.t2 = new System.Windows.Forms.TabPage();
            this.p6 = new System.Windows.Forms.Panel();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.p5 = new System.Windows.Forms.Panel();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.radioButton11 = new System.Windows.Forms.RadioButton();
            this.radioButton12 = new System.Windows.Forms.RadioButton();
            this.radioButton13 = new System.Windows.Forms.RadioButton();
            this.radioButton14 = new System.Windows.Forms.RadioButton();
            this.radioButton15 = new System.Windows.Forms.RadioButton();
            this.radioButton16 = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.p4 = new System.Windows.Forms.Panel();
            this.radioButton17 = new System.Windows.Forms.RadioButton();
            this.radioButton18 = new System.Windows.Forms.RadioButton();
            this.radioButton19 = new System.Windows.Forms.RadioButton();
            this.radioButton20 = new System.Windows.Forms.RadioButton();
            this.radioButton21 = new System.Windows.Forms.RadioButton();
            this.radioButton22 = new System.Windows.Forms.RadioButton();
            this.radioButton23 = new System.Windows.Forms.RadioButton();
            this.radioButton24 = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.t3 = new System.Windows.Forms.TabPage();
            this.p9 = new System.Windows.Forms.Panel();
            this.radioButton49 = new System.Windows.Forms.RadioButton();
            this.radioButton50 = new System.Windows.Forms.RadioButton();
            this.radioButton51 = new System.Windows.Forms.RadioButton();
            this.radioButton52 = new System.Windows.Forms.RadioButton();
            this.radioButton53 = new System.Windows.Forms.RadioButton();
            this.radioButton54 = new System.Windows.Forms.RadioButton();
            this.radioButton55 = new System.Windows.Forms.RadioButton();
            this.radioButton56 = new System.Windows.Forms.RadioButton();
            this.label8 = new System.Windows.Forms.Label();
            this.p8 = new System.Windows.Forms.Panel();
            this.radioButton57 = new System.Windows.Forms.RadioButton();
            this.radioButton58 = new System.Windows.Forms.RadioButton();
            this.radioButton59 = new System.Windows.Forms.RadioButton();
            this.radioButton60 = new System.Windows.Forms.RadioButton();
            this.radioButton61 = new System.Windows.Forms.RadioButton();
            this.radioButton62 = new System.Windows.Forms.RadioButton();
            this.radioButton63 = new System.Windows.Forms.RadioButton();
            this.radioButton64 = new System.Windows.Forms.RadioButton();
            this.label9 = new System.Windows.Forms.Label();
            this.p7 = new System.Windows.Forms.Panel();
            this.radioButton65 = new System.Windows.Forms.RadioButton();
            this.radioButton66 = new System.Windows.Forms.RadioButton();
            this.radioButton67 = new System.Windows.Forms.RadioButton();
            this.radioButton68 = new System.Windows.Forms.RadioButton();
            this.radioButton69 = new System.Windows.Forms.RadioButton();
            this.radioButton70 = new System.Windows.Forms.RadioButton();
            this.radioButton71 = new System.Windows.Forms.RadioButton();
            this.radioButton72 = new System.Windows.Forms.RadioButton();
            this.label10 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.label16 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.label18 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.t1.SuspendLayout();
            this.p3.SuspendLayout();
            this.p2.SuspendLayout();
            this.p1.SuspendLayout();
            this.t2.SuspendLayout();
            this.p6.SuspendLayout();
            this.p5.SuspendLayout();
            this.p4.SuspendLayout();
            this.t3.SuspendLayout();
            this.p9.SuspendLayout();
            this.p8.SuspendLayout();
            this.p7.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.t1);
            this.tabControl1.Controls.Add(this.t2);
            this.tabControl1.Controls.Add(this.t3);
            this.tabControl1.Enabled = false;
            this.tabControl1.Location = new System.Drawing.Point(329, 108);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(506, 303);
            this.tabControl1.TabIndex = 0;
            // 
            // t1
            // 
            this.t1.Controls.Add(this.p3);
            this.t1.Controls.Add(this.p2);
            this.t1.Controls.Add(this.p1);
            this.t1.Location = new System.Drawing.Point(4, 22);
            this.t1.Name = "t1";
            this.t1.Padding = new System.Windows.Forms.Padding(3);
            this.t1.Size = new System.Drawing.Size(498, 277);
            this.t1.TabIndex = 0;
            this.t1.Text = "Member 1";
            this.t1.UseVisualStyleBackColor = true;
            // 
            // p3
            // 
            this.p3.Controls.Add(this.radioButton25);
            this.p3.Controls.Add(this.radioButton26);
            this.p3.Controls.Add(this.radioButton27);
            this.p3.Controls.Add(this.radioButton28);
            this.p3.Controls.Add(this.radioButton29);
            this.p3.Controls.Add(this.radioButton30);
            this.p3.Controls.Add(this.radioButton31);
            this.p3.Controls.Add(this.radioButton32);
            this.p3.Controls.Add(this.label5);
            this.p3.Location = new System.Drawing.Point(4, 196);
            this.p3.Name = "p3";
            this.p3.Size = new System.Drawing.Size(492, 68);
            this.p3.TabIndex = 63;
            this.p3.Enter += new System.EventHandler(this.p1_Enter);
            // 
            // radioButton25
            // 
            this.radioButton25.AutoSize = true;
            this.radioButton25.Location = new System.Drawing.Point(420, 37);
            this.radioButton25.Name = "radioButton25";
            this.radioButton25.Size = new System.Drawing.Size(69, 17);
            this.radioButton25.TabIndex = 65;
            this.radioButton25.Text = "No Show";
            this.radioButton25.UseVisualStyleBackColor = true;
            this.radioButton25.CheckedChanged += new System.EventHandler(this.noshow);
            // 
            // radioButton26
            // 
            this.radioButton26.AutoSize = true;
            this.radioButton26.Location = new System.Drawing.Point(345, 37);
            this.radioButton26.Name = "radioButton26";
            this.radioButton26.Size = new System.Drawing.Size(74, 17);
            this.radioButton26.TabIndex = 64;
            this.radioButton26.Text = "Superficial";
            this.radioButton26.UseVisualStyleBackColor = true;
            this.radioButton26.CheckedChanged += new System.EventHandler(this.superficial);
            // 
            // radioButton27
            // 
            this.radioButton27.AutoSize = true;
            this.radioButton27.Location = new System.Drawing.Point(248, 37);
            this.radioButton27.Name = "radioButton27";
            this.radioButton27.Size = new System.Drawing.Size(92, 17);
            this.radioButton27.TabIndex = 63;
            this.radioButton27.Text = "Unsatisfactory";
            this.radioButton27.UseVisualStyleBackColor = true;
            this.radioButton27.CheckedChanged += new System.EventHandler(this.unsatisfactory);
            // 
            // radioButton28
            // 
            this.radioButton28.AutoSize = true;
            this.radioButton28.Location = new System.Drawing.Point(169, 37);
            this.radioButton28.Name = "radioButton28";
            this.radioButton28.Size = new System.Drawing.Size(67, 17);
            this.radioButton28.TabIndex = 62;
            this.radioButton28.Text = "Deficient";
            this.radioButton28.UseVisualStyleBackColor = true;
            this.radioButton28.CheckedChanged += new System.EventHandler(this.deficient);
            // 
            // radioButton29
            // 
            this.radioButton29.AutoSize = true;
            this.radioButton29.Location = new System.Drawing.Point(420, 7);
            this.radioButton29.Name = "radioButton29";
            this.radioButton29.Size = new System.Drawing.Size(65, 17);
            this.radioButton29.TabIndex = 61;
            this.radioButton29.Text = "Marginal";
            this.radioButton29.UseVisualStyleBackColor = true;
            this.radioButton29.CheckedChanged += new System.EventHandler(this.marginal);
            // 
            // radioButton30
            // 
            this.radioButton30.AutoSize = true;
            this.radioButton30.Location = new System.Drawing.Point(345, 7);
            this.radioButton30.Name = "radioButton30";
            this.radioButton30.Size = new System.Drawing.Size(64, 17);
            this.radioButton30.TabIndex = 60;
            this.radioButton30.Text = "Ordinary";
            this.radioButton30.UseVisualStyleBackColor = true;
            this.radioButton30.CheckedChanged += new System.EventHandler(this.ordinary);
            // 
            // radioButton31
            // 
            this.radioButton31.AutoSize = true;
            this.radioButton31.Location = new System.Drawing.Point(248, 11);
            this.radioButton31.Name = "radioButton31";
            this.radioButton31.Size = new System.Drawing.Size(75, 17);
            this.radioButton31.TabIndex = 59;
            this.radioButton31.Text = "Very Good";
            this.radioButton31.UseVisualStyleBackColor = true;
            this.radioButton31.CheckedChanged += new System.EventHandler(this.verygood);
            // 
            // radioButton32
            // 
            this.radioButton32.AutoSize = true;
            this.radioButton32.Location = new System.Drawing.Point(170, 9);
            this.radioButton32.Name = "radioButton32";
            this.radioButton32.Size = new System.Drawing.Size(68, 17);
            this.radioButton32.TabIndex = 58;
            this.radioButton32.Text = "Excellent";
            this.radioButton32.UseVisualStyleBackColor = true;
            this.radioButton32.CheckedChanged += new System.EventHandler(this.excellent);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 11);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 13);
            this.label5.TabIndex = 57;
            this.label5.Text = "Member 3";
            // 
            // p2
            // 
            this.p2.Controls.Add(this.radioButton33);
            this.p2.Controls.Add(this.radioButton34);
            this.p2.Controls.Add(this.radioButton35);
            this.p2.Controls.Add(this.radioButton36);
            this.p2.Controls.Add(this.radioButton37);
            this.p2.Controls.Add(this.radioButton38);
            this.p2.Controls.Add(this.radioButton39);
            this.p2.Controls.Add(this.radioButton40);
            this.p2.Controls.Add(this.label6);
            this.p2.Location = new System.Drawing.Point(0, 122);
            this.p2.Name = "p2";
            this.p2.Size = new System.Drawing.Size(496, 68);
            this.p2.TabIndex = 64;
            this.p2.Enter += new System.EventHandler(this.p1_Enter);
            // 
            // radioButton33
            // 
            this.radioButton33.AutoSize = true;
            this.radioButton33.Location = new System.Drawing.Point(424, 42);
            this.radioButton33.Name = "radioButton33";
            this.radioButton33.Size = new System.Drawing.Size(69, 17);
            this.radioButton33.TabIndex = 57;
            this.radioButton33.Text = "No Show";
            this.radioButton33.UseVisualStyleBackColor = true;
            this.radioButton33.CheckedChanged += new System.EventHandler(this.noshow);
            // 
            // radioButton34
            // 
            this.radioButton34.AutoSize = true;
            this.radioButton34.Location = new System.Drawing.Point(349, 40);
            this.radioButton34.Name = "radioButton34";
            this.radioButton34.Size = new System.Drawing.Size(74, 17);
            this.radioButton34.TabIndex = 56;
            this.radioButton34.Text = "Superficial";
            this.radioButton34.UseVisualStyleBackColor = true;
            this.radioButton34.CheckedChanged += new System.EventHandler(this.superficial);
            // 
            // radioButton35
            // 
            this.radioButton35.AutoSize = true;
            this.radioButton35.Location = new System.Drawing.Point(248, 40);
            this.radioButton35.Name = "radioButton35";
            this.radioButton35.Size = new System.Drawing.Size(92, 17);
            this.radioButton35.TabIndex = 55;
            this.radioButton35.Text = "Unsatisfactory";
            this.radioButton35.UseVisualStyleBackColor = true;
            this.radioButton35.CheckedChanged += new System.EventHandler(this.unsatisfactory);
            // 
            // radioButton36
            // 
            this.radioButton36.AutoSize = true;
            this.radioButton36.Location = new System.Drawing.Point(173, 42);
            this.radioButton36.Name = "radioButton36";
            this.radioButton36.Size = new System.Drawing.Size(67, 17);
            this.radioButton36.TabIndex = 54;
            this.radioButton36.Text = "Deficient";
            this.radioButton36.UseVisualStyleBackColor = true;
            this.radioButton36.CheckedChanged += new System.EventHandler(this.deficient);
            // 
            // radioButton37
            // 
            this.radioButton37.AutoSize = true;
            this.radioButton37.Location = new System.Drawing.Point(424, 12);
            this.radioButton37.Name = "radioButton37";
            this.radioButton37.Size = new System.Drawing.Size(65, 17);
            this.radioButton37.TabIndex = 53;
            this.radioButton37.Text = "Marginal";
            this.radioButton37.UseVisualStyleBackColor = true;
            this.radioButton37.CheckedChanged += new System.EventHandler(this.marginal);
            // 
            // radioButton38
            // 
            this.radioButton38.AutoSize = true;
            this.radioButton38.Location = new System.Drawing.Point(349, 10);
            this.radioButton38.Name = "radioButton38";
            this.radioButton38.Size = new System.Drawing.Size(64, 17);
            this.radioButton38.TabIndex = 52;
            this.radioButton38.Text = "Ordinary";
            this.radioButton38.UseVisualStyleBackColor = true;
            this.radioButton38.CheckedChanged += new System.EventHandler(this.ordinary);
            // 
            // radioButton39
            // 
            this.radioButton39.AutoSize = true;
            this.radioButton39.Location = new System.Drawing.Point(248, 10);
            this.radioButton39.Name = "radioButton39";
            this.radioButton39.Size = new System.Drawing.Size(75, 17);
            this.radioButton39.TabIndex = 51;
            this.radioButton39.Text = "Very Good";
            this.radioButton39.UseVisualStyleBackColor = true;
            this.radioButton39.CheckedChanged += new System.EventHandler(this.verygood);
            // 
            // radioButton40
            // 
            this.radioButton40.AutoSize = true;
            this.radioButton40.Location = new System.Drawing.Point(173, 10);
            this.radioButton40.Name = "radioButton40";
            this.radioButton40.Size = new System.Drawing.Size(68, 17);
            this.radioButton40.TabIndex = 50;
            this.radioButton40.Text = "Excellent";
            this.radioButton40.UseVisualStyleBackColor = true;
            this.radioButton40.CheckedChanged += new System.EventHandler(this.excellent);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 12);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 13);
            this.label6.TabIndex = 49;
            this.label6.Text = "Member 2";
            // 
            // p1
            // 
            this.p1.Controls.Add(this.radioButton41);
            this.p1.Controls.Add(this.radioButton42);
            this.p1.Controls.Add(this.radioButton43);
            this.p1.Controls.Add(this.radioButton44);
            this.p1.Controls.Add(this.radioButton45);
            this.p1.Controls.Add(this.radioButton46);
            this.p1.Controls.Add(this.radioButton47);
            this.p1.Controls.Add(this.radioButton48);
            this.p1.Controls.Add(this.label7);
            this.p1.Location = new System.Drawing.Point(0, 48);
            this.p1.Name = "p1";
            this.p1.Size = new System.Drawing.Size(496, 68);
            this.p1.TabIndex = 62;
            this.p1.Enter += new System.EventHandler(this.p1_Enter);
            // 
            // radioButton41
            // 
            this.radioButton41.AutoSize = true;
            this.radioButton41.Location = new System.Drawing.Point(421, 44);
            this.radioButton41.Name = "radioButton41";
            this.radioButton41.Size = new System.Drawing.Size(69, 17);
            this.radioButton41.TabIndex = 49;
            this.radioButton41.Text = "No Show";
            this.radioButton41.UseVisualStyleBackColor = true;
            this.radioButton41.CheckedChanged += new System.EventHandler(this.noshow);
            // 
            // radioButton42
            // 
            this.radioButton42.AutoSize = true;
            this.radioButton42.Location = new System.Drawing.Point(349, 44);
            this.radioButton42.Name = "radioButton42";
            this.radioButton42.Size = new System.Drawing.Size(74, 17);
            this.radioButton42.TabIndex = 48;
            this.radioButton42.Text = "Superficial";
            this.radioButton42.UseVisualStyleBackColor = true;
            this.radioButton42.CheckedChanged += new System.EventHandler(this.superficial);
            // 
            // radioButton43
            // 
            this.radioButton43.AutoSize = true;
            this.radioButton43.Location = new System.Drawing.Point(247, 44);
            this.radioButton43.Name = "radioButton43";
            this.radioButton43.Size = new System.Drawing.Size(92, 17);
            this.radioButton43.TabIndex = 47;
            this.radioButton43.Text = "Unsatisfactory";
            this.radioButton43.UseVisualStyleBackColor = true;
            this.radioButton43.CheckedChanged += new System.EventHandler(this.unsatisfactory);
            // 
            // radioButton44
            // 
            this.radioButton44.AutoSize = true;
            this.radioButton44.Location = new System.Drawing.Point(174, 44);
            this.radioButton44.Name = "radioButton44";
            this.radioButton44.Size = new System.Drawing.Size(67, 17);
            this.radioButton44.TabIndex = 46;
            this.radioButton44.Text = "Deficient";
            this.radioButton44.UseVisualStyleBackColor = true;
            this.radioButton44.CheckedChanged += new System.EventHandler(this.deficient);
            // 
            // radioButton45
            // 
            this.radioButton45.AutoSize = true;
            this.radioButton45.Location = new System.Drawing.Point(421, 14);
            this.radioButton45.Name = "radioButton45";
            this.radioButton45.Size = new System.Drawing.Size(65, 17);
            this.radioButton45.TabIndex = 45;
            this.radioButton45.Text = "Marginal";
            this.radioButton45.UseVisualStyleBackColor = true;
            this.radioButton45.CheckedChanged += new System.EventHandler(this.marginal);
            // 
            // radioButton46
            // 
            this.radioButton46.AutoSize = true;
            this.radioButton46.Location = new System.Drawing.Point(349, 15);
            this.radioButton46.Name = "radioButton46";
            this.radioButton46.Size = new System.Drawing.Size(64, 17);
            this.radioButton46.TabIndex = 44;
            this.radioButton46.Text = "Ordinary";
            this.radioButton46.UseVisualStyleBackColor = true;
            this.radioButton46.CheckedChanged += new System.EventHandler(this.ordinary);
            // 
            // radioButton47
            // 
            this.radioButton47.AutoSize = true;
            this.radioButton47.Location = new System.Drawing.Point(248, 14);
            this.radioButton47.Name = "radioButton47";
            this.radioButton47.Size = new System.Drawing.Size(75, 17);
            this.radioButton47.TabIndex = 43;
            this.radioButton47.Text = "Very Good";
            this.radioButton47.UseVisualStyleBackColor = true;
            this.radioButton47.CheckedChanged += new System.EventHandler(this.verygood);
            // 
            // radioButton48
            // 
            this.radioButton48.AutoSize = true;
            this.radioButton48.Location = new System.Drawing.Point(174, 12);
            this.radioButton48.Name = "radioButton48";
            this.radioButton48.Size = new System.Drawing.Size(68, 17);
            this.radioButton48.TabIndex = 42;
            this.radioButton48.Text = "Excellent";
            this.radioButton48.UseVisualStyleBackColor = true;
            this.radioButton48.CheckedChanged += new System.EventHandler(this.excellent);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(10, 14);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 13);
            this.label7.TabIndex = 41;
            this.label7.Text = "Member 1";
            // 
            // t2
            // 
            this.t2.Controls.Add(this.p6);
            this.t2.Controls.Add(this.p5);
            this.t2.Controls.Add(this.p4);
            this.t2.Location = new System.Drawing.Point(4, 22);
            this.t2.Name = "t2";
            this.t2.Padding = new System.Windows.Forms.Padding(3);
            this.t2.Size = new System.Drawing.Size(498, 277);
            this.t2.TabIndex = 1;
            this.t2.Text = "Member2";
            this.t2.UseVisualStyleBackColor = true;
            // 
            // p6
            // 
            this.p6.Controls.Add(this.radioButton1);
            this.p6.Controls.Add(this.radioButton2);
            this.p6.Controls.Add(this.radioButton3);
            this.p6.Controls.Add(this.radioButton4);
            this.p6.Controls.Add(this.radioButton5);
            this.p6.Controls.Add(this.radioButton6);
            this.p6.Controls.Add(this.radioButton7);
            this.p6.Controls.Add(this.radioButton8);
            this.p6.Controls.Add(this.label2);
            this.p6.Location = new System.Drawing.Point(4, 196);
            this.p6.Name = "p6";
            this.p6.Size = new System.Drawing.Size(492, 68);
            this.p6.TabIndex = 66;
            this.p6.Enter += new System.EventHandler(this.p1_Enter);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(420, 37);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(69, 17);
            this.radioButton1.TabIndex = 65;
            this.radioButton1.Text = "No Show";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.noshow);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(345, 37);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(74, 17);
            this.radioButton2.TabIndex = 64;
            this.radioButton2.Text = "Superficial";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.superficial);
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(248, 37);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(92, 17);
            this.radioButton3.TabIndex = 63;
            this.radioButton3.Text = "Unsatisfactory";
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.unsatisfactory);
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(169, 37);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(67, 17);
            this.radioButton4.TabIndex = 62;
            this.radioButton4.Text = "Deficient";
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.CheckedChanged += new System.EventHandler(this.deficient);
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(420, 7);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(65, 17);
            this.radioButton5.TabIndex = 61;
            this.radioButton5.Text = "Marginal";
            this.radioButton5.UseVisualStyleBackColor = true;
            this.radioButton5.CheckedChanged += new System.EventHandler(this.marginal);
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Location = new System.Drawing.Point(345, 7);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(64, 17);
            this.radioButton6.TabIndex = 60;
            this.radioButton6.Text = "Ordinary";
            this.radioButton6.UseVisualStyleBackColor = true;
            this.radioButton6.CheckedChanged += new System.EventHandler(this.ordinary);
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Location = new System.Drawing.Point(248, 11);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(75, 17);
            this.radioButton7.TabIndex = 59;
            this.radioButton7.Text = "Very Good";
            this.radioButton7.UseVisualStyleBackColor = true;
            this.radioButton7.CheckedChanged += new System.EventHandler(this.verygood);
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Location = new System.Drawing.Point(170, 9);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(68, 17);
            this.radioButton8.TabIndex = 58;
            this.radioButton8.Text = "Excellent";
            this.radioButton8.UseVisualStyleBackColor = true;
            this.radioButton8.CheckedChanged += new System.EventHandler(this.excellent);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 13);
            this.label2.TabIndex = 57;
            this.label2.Text = "Member 3";
            // 
            // p5
            // 
            this.p5.Controls.Add(this.radioButton9);
            this.p5.Controls.Add(this.radioButton10);
            this.p5.Controls.Add(this.radioButton11);
            this.p5.Controls.Add(this.radioButton12);
            this.p5.Controls.Add(this.radioButton13);
            this.p5.Controls.Add(this.radioButton14);
            this.p5.Controls.Add(this.radioButton15);
            this.p5.Controls.Add(this.radioButton16);
            this.p5.Controls.Add(this.label3);
            this.p5.Location = new System.Drawing.Point(0, 122);
            this.p5.Name = "p5";
            this.p5.Size = new System.Drawing.Size(496, 68);
            this.p5.TabIndex = 67;
            this.p5.Enter += new System.EventHandler(this.p1_Enter);
            // 
            // radioButton9
            // 
            this.radioButton9.AutoSize = true;
            this.radioButton9.Location = new System.Drawing.Point(424, 42);
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.Size = new System.Drawing.Size(69, 17);
            this.radioButton9.TabIndex = 57;
            this.radioButton9.Text = "No Show";
            this.radioButton9.UseVisualStyleBackColor = true;
            this.radioButton9.CheckedChanged += new System.EventHandler(this.noshow);
            // 
            // radioButton10
            // 
            this.radioButton10.AutoSize = true;
            this.radioButton10.Location = new System.Drawing.Point(349, 40);
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Size = new System.Drawing.Size(74, 17);
            this.radioButton10.TabIndex = 56;
            this.radioButton10.Text = "Superficial";
            this.radioButton10.UseVisualStyleBackColor = true;
            this.radioButton10.CheckedChanged += new System.EventHandler(this.superficial);
            // 
            // radioButton11
            // 
            this.radioButton11.AutoSize = true;
            this.radioButton11.Location = new System.Drawing.Point(248, 40);
            this.radioButton11.Name = "radioButton11";
            this.radioButton11.Size = new System.Drawing.Size(92, 17);
            this.radioButton11.TabIndex = 55;
            this.radioButton11.Text = "Unsatisfactory";
            this.radioButton11.UseVisualStyleBackColor = true;
            this.radioButton11.CheckedChanged += new System.EventHandler(this.unsatisfactory);
            // 
            // radioButton12
            // 
            this.radioButton12.AutoSize = true;
            this.radioButton12.Location = new System.Drawing.Point(173, 42);
            this.radioButton12.Name = "radioButton12";
            this.radioButton12.Size = new System.Drawing.Size(67, 17);
            this.radioButton12.TabIndex = 54;
            this.radioButton12.Text = "Deficient";
            this.radioButton12.UseVisualStyleBackColor = true;
            this.radioButton12.CheckedChanged += new System.EventHandler(this.deficient);
            // 
            // radioButton13
            // 
            this.radioButton13.AutoSize = true;
            this.radioButton13.Location = new System.Drawing.Point(424, 12);
            this.radioButton13.Name = "radioButton13";
            this.radioButton13.Size = new System.Drawing.Size(65, 17);
            this.radioButton13.TabIndex = 53;
            this.radioButton13.Text = "Marginal";
            this.radioButton13.UseVisualStyleBackColor = true;
            this.radioButton13.CheckedChanged += new System.EventHandler(this.marginal);
            // 
            // radioButton14
            // 
            this.radioButton14.AutoSize = true;
            this.radioButton14.Location = new System.Drawing.Point(349, 10);
            this.radioButton14.Name = "radioButton14";
            this.radioButton14.Size = new System.Drawing.Size(64, 17);
            this.radioButton14.TabIndex = 52;
            this.radioButton14.Text = "Ordinary";
            this.radioButton14.UseVisualStyleBackColor = true;
            this.radioButton14.CheckedChanged += new System.EventHandler(this.ordinary);
            // 
            // radioButton15
            // 
            this.radioButton15.AutoSize = true;
            this.radioButton15.Location = new System.Drawing.Point(248, 10);
            this.radioButton15.Name = "radioButton15";
            this.radioButton15.Size = new System.Drawing.Size(75, 17);
            this.radioButton15.TabIndex = 51;
            this.radioButton15.Text = "Very Good";
            this.radioButton15.UseVisualStyleBackColor = true;
            this.radioButton15.CheckedChanged += new System.EventHandler(this.verygood);
            // 
            // radioButton16
            // 
            this.radioButton16.AutoSize = true;
            this.radioButton16.Location = new System.Drawing.Point(173, 10);
            this.radioButton16.Name = "radioButton16";
            this.radioButton16.Size = new System.Drawing.Size(68, 17);
            this.radioButton16.TabIndex = 50;
            this.radioButton16.Text = "Excellent";
            this.radioButton16.UseVisualStyleBackColor = true;
            this.radioButton16.CheckedChanged += new System.EventHandler(this.excellent);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 13);
            this.label3.TabIndex = 49;
            this.label3.Text = "Member 2";
            // 
            // p4
            // 
            this.p4.Controls.Add(this.radioButton17);
            this.p4.Controls.Add(this.radioButton18);
            this.p4.Controls.Add(this.radioButton19);
            this.p4.Controls.Add(this.radioButton20);
            this.p4.Controls.Add(this.radioButton21);
            this.p4.Controls.Add(this.radioButton22);
            this.p4.Controls.Add(this.radioButton23);
            this.p4.Controls.Add(this.radioButton24);
            this.p4.Controls.Add(this.label4);
            this.p4.Location = new System.Drawing.Point(0, 48);
            this.p4.Name = "p4";
            this.p4.Size = new System.Drawing.Size(496, 68);
            this.p4.TabIndex = 65;
            this.p4.Enter += new System.EventHandler(this.p1_Enter);
            // 
            // radioButton17
            // 
            this.radioButton17.AutoSize = true;
            this.radioButton17.Location = new System.Drawing.Point(421, 44);
            this.radioButton17.Name = "radioButton17";
            this.radioButton17.Size = new System.Drawing.Size(69, 17);
            this.radioButton17.TabIndex = 49;
            this.radioButton17.Text = "No Show";
            this.radioButton17.UseVisualStyleBackColor = true;
            this.radioButton17.CheckedChanged += new System.EventHandler(this.noshow);
            // 
            // radioButton18
            // 
            this.radioButton18.AutoSize = true;
            this.radioButton18.Location = new System.Drawing.Point(349, 44);
            this.radioButton18.Name = "radioButton18";
            this.radioButton18.Size = new System.Drawing.Size(74, 17);
            this.radioButton18.TabIndex = 48;
            this.radioButton18.Text = "Superficial";
            this.radioButton18.UseVisualStyleBackColor = true;
            this.radioButton18.CheckedChanged += new System.EventHandler(this.superficial);
            // 
            // radioButton19
            // 
            this.radioButton19.AutoSize = true;
            this.radioButton19.Location = new System.Drawing.Point(247, 44);
            this.radioButton19.Name = "radioButton19";
            this.radioButton19.Size = new System.Drawing.Size(92, 17);
            this.radioButton19.TabIndex = 47;
            this.radioButton19.Text = "Unsatisfactory";
            this.radioButton19.UseVisualStyleBackColor = true;
            this.radioButton19.CheckedChanged += new System.EventHandler(this.unsatisfactory);
            // 
            // radioButton20
            // 
            this.radioButton20.AutoSize = true;
            this.radioButton20.Location = new System.Drawing.Point(174, 44);
            this.radioButton20.Name = "radioButton20";
            this.radioButton20.Size = new System.Drawing.Size(67, 17);
            this.radioButton20.TabIndex = 46;
            this.radioButton20.Text = "Deficient";
            this.radioButton20.UseVisualStyleBackColor = true;
            this.radioButton20.CheckedChanged += new System.EventHandler(this.deficient);
            // 
            // radioButton21
            // 
            this.radioButton21.AutoSize = true;
            this.radioButton21.Location = new System.Drawing.Point(421, 14);
            this.radioButton21.Name = "radioButton21";
            this.radioButton21.Size = new System.Drawing.Size(65, 17);
            this.radioButton21.TabIndex = 45;
            this.radioButton21.Text = "Marginal";
            this.radioButton21.UseVisualStyleBackColor = true;
            this.radioButton21.CheckedChanged += new System.EventHandler(this.marginal);
            // 
            // radioButton22
            // 
            this.radioButton22.AutoSize = true;
            this.radioButton22.Location = new System.Drawing.Point(349, 15);
            this.radioButton22.Name = "radioButton22";
            this.radioButton22.Size = new System.Drawing.Size(64, 17);
            this.radioButton22.TabIndex = 44;
            this.radioButton22.Text = "Ordinary";
            this.radioButton22.UseVisualStyleBackColor = true;
            this.radioButton22.CheckedChanged += new System.EventHandler(this.ordinary);
            // 
            // radioButton23
            // 
            this.radioButton23.AutoSize = true;
            this.radioButton23.Location = new System.Drawing.Point(248, 14);
            this.radioButton23.Name = "radioButton23";
            this.radioButton23.Size = new System.Drawing.Size(75, 17);
            this.radioButton23.TabIndex = 43;
            this.radioButton23.Text = "Very Good";
            this.radioButton23.UseVisualStyleBackColor = true;
            this.radioButton23.CheckedChanged += new System.EventHandler(this.verygood);
            // 
            // radioButton24
            // 
            this.radioButton24.AutoSize = true;
            this.radioButton24.Location = new System.Drawing.Point(174, 12);
            this.radioButton24.Name = "radioButton24";
            this.radioButton24.Size = new System.Drawing.Size(68, 17);
            this.radioButton24.TabIndex = 42;
            this.radioButton24.Text = "Excellent";
            this.radioButton24.UseVisualStyleBackColor = true;
            this.radioButton24.CheckedChanged += new System.EventHandler(this.excellent);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 14);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 13);
            this.label4.TabIndex = 41;
            this.label4.Text = "Member 1";
            // 
            // t3
            // 
            this.t3.Controls.Add(this.p9);
            this.t3.Controls.Add(this.p8);
            this.t3.Controls.Add(this.p7);
            this.t3.Location = new System.Drawing.Point(4, 22);
            this.t3.Name = "t3";
            this.t3.Size = new System.Drawing.Size(498, 277);
            this.t3.TabIndex = 2;
            this.t3.Text = "Member3";
            this.t3.UseVisualStyleBackColor = true;
            // 
            // p9
            // 
            this.p9.Controls.Add(this.radioButton49);
            this.p9.Controls.Add(this.radioButton50);
            this.p9.Controls.Add(this.radioButton51);
            this.p9.Controls.Add(this.radioButton52);
            this.p9.Controls.Add(this.radioButton53);
            this.p9.Controls.Add(this.radioButton54);
            this.p9.Controls.Add(this.radioButton55);
            this.p9.Controls.Add(this.radioButton56);
            this.p9.Controls.Add(this.label8);
            this.p9.Location = new System.Drawing.Point(4, 196);
            this.p9.Name = "p9";
            this.p9.Size = new System.Drawing.Size(492, 68);
            this.p9.TabIndex = 66;
            this.p9.Enter += new System.EventHandler(this.p1_Enter);
            // 
            // radioButton49
            // 
            this.radioButton49.AutoSize = true;
            this.radioButton49.Location = new System.Drawing.Point(420, 37);
            this.radioButton49.Name = "radioButton49";
            this.radioButton49.Size = new System.Drawing.Size(69, 17);
            this.radioButton49.TabIndex = 65;
            this.radioButton49.Text = "No Show";
            this.radioButton49.UseVisualStyleBackColor = true;
            this.radioButton49.CheckedChanged += new System.EventHandler(this.noshow);
            // 
            // radioButton50
            // 
            this.radioButton50.AutoSize = true;
            this.radioButton50.Location = new System.Drawing.Point(345, 37);
            this.radioButton50.Name = "radioButton50";
            this.radioButton50.Size = new System.Drawing.Size(74, 17);
            this.radioButton50.TabIndex = 64;
            this.radioButton50.Text = "Superficial";
            this.radioButton50.UseVisualStyleBackColor = true;
            this.radioButton50.CheckedChanged += new System.EventHandler(this.superficial);
            // 
            // radioButton51
            // 
            this.radioButton51.AutoSize = true;
            this.radioButton51.Location = new System.Drawing.Point(248, 37);
            this.radioButton51.Name = "radioButton51";
            this.radioButton51.Size = new System.Drawing.Size(92, 17);
            this.radioButton51.TabIndex = 63;
            this.radioButton51.Text = "Unsatisfactory";
            this.radioButton51.UseVisualStyleBackColor = true;
            this.radioButton51.CheckedChanged += new System.EventHandler(this.unsatisfactory);
            // 
            // radioButton52
            // 
            this.radioButton52.AutoSize = true;
            this.radioButton52.Location = new System.Drawing.Point(169, 37);
            this.radioButton52.Name = "radioButton52";
            this.radioButton52.Size = new System.Drawing.Size(67, 17);
            this.radioButton52.TabIndex = 62;
            this.radioButton52.Text = "Deficient";
            this.radioButton52.UseVisualStyleBackColor = true;
            this.radioButton52.CheckedChanged += new System.EventHandler(this.deficient);
            // 
            // radioButton53
            // 
            this.radioButton53.AutoSize = true;
            this.radioButton53.Location = new System.Drawing.Point(420, 7);
            this.radioButton53.Name = "radioButton53";
            this.radioButton53.Size = new System.Drawing.Size(65, 17);
            this.radioButton53.TabIndex = 61;
            this.radioButton53.Text = "Marginal";
            this.radioButton53.UseVisualStyleBackColor = true;
            this.radioButton53.CheckedChanged += new System.EventHandler(this.marginal);
            // 
            // radioButton54
            // 
            this.radioButton54.AutoSize = true;
            this.radioButton54.Location = new System.Drawing.Point(345, 7);
            this.radioButton54.Name = "radioButton54";
            this.radioButton54.Size = new System.Drawing.Size(64, 17);
            this.radioButton54.TabIndex = 60;
            this.radioButton54.Text = "Ordinary";
            this.radioButton54.UseVisualStyleBackColor = true;
            this.radioButton54.CheckedChanged += new System.EventHandler(this.ordinary);
            // 
            // radioButton55
            // 
            this.radioButton55.AutoSize = true;
            this.radioButton55.Location = new System.Drawing.Point(248, 11);
            this.radioButton55.Name = "radioButton55";
            this.radioButton55.Size = new System.Drawing.Size(75, 17);
            this.radioButton55.TabIndex = 59;
            this.radioButton55.Text = "Very Good";
            this.radioButton55.UseVisualStyleBackColor = true;
            this.radioButton55.CheckedChanged += new System.EventHandler(this.verygood);
            // 
            // radioButton56
            // 
            this.radioButton56.AutoSize = true;
            this.radioButton56.Location = new System.Drawing.Point(170, 9);
            this.radioButton56.Name = "radioButton56";
            this.radioButton56.Size = new System.Drawing.Size(68, 17);
            this.radioButton56.TabIndex = 58;
            this.radioButton56.Text = "Excellent";
            this.radioButton56.UseVisualStyleBackColor = true;
            this.radioButton56.CheckedChanged += new System.EventHandler(this.excellent);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 11);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(54, 13);
            this.label8.TabIndex = 57;
            this.label8.Text = "Member 3";
            // 
            // p8
            // 
            this.p8.Controls.Add(this.radioButton57);
            this.p8.Controls.Add(this.radioButton58);
            this.p8.Controls.Add(this.radioButton59);
            this.p8.Controls.Add(this.radioButton60);
            this.p8.Controls.Add(this.radioButton61);
            this.p8.Controls.Add(this.radioButton62);
            this.p8.Controls.Add(this.radioButton63);
            this.p8.Controls.Add(this.radioButton64);
            this.p8.Controls.Add(this.label9);
            this.p8.Location = new System.Drawing.Point(0, 122);
            this.p8.Name = "p8";
            this.p8.Size = new System.Drawing.Size(496, 68);
            this.p8.TabIndex = 67;
            this.p8.Enter += new System.EventHandler(this.p1_Enter);
            // 
            // radioButton57
            // 
            this.radioButton57.AutoSize = true;
            this.radioButton57.Location = new System.Drawing.Point(424, 42);
            this.radioButton57.Name = "radioButton57";
            this.radioButton57.Size = new System.Drawing.Size(69, 17);
            this.radioButton57.TabIndex = 57;
            this.radioButton57.Text = "No Show";
            this.radioButton57.UseVisualStyleBackColor = true;
            this.radioButton57.CheckedChanged += new System.EventHandler(this.noshow);
            // 
            // radioButton58
            // 
            this.radioButton58.AutoSize = true;
            this.radioButton58.Location = new System.Drawing.Point(349, 40);
            this.radioButton58.Name = "radioButton58";
            this.radioButton58.Size = new System.Drawing.Size(74, 17);
            this.radioButton58.TabIndex = 56;
            this.radioButton58.Text = "Superficial";
            this.radioButton58.UseVisualStyleBackColor = true;
            this.radioButton58.CheckedChanged += new System.EventHandler(this.superficial);
            // 
            // radioButton59
            // 
            this.radioButton59.AutoSize = true;
            this.radioButton59.Location = new System.Drawing.Point(248, 40);
            this.radioButton59.Name = "radioButton59";
            this.radioButton59.Size = new System.Drawing.Size(92, 17);
            this.radioButton59.TabIndex = 55;
            this.radioButton59.Text = "Unsatisfactory";
            this.radioButton59.UseVisualStyleBackColor = true;
            this.radioButton59.CheckedChanged += new System.EventHandler(this.unsatisfactory);
            // 
            // radioButton60
            // 
            this.radioButton60.AutoSize = true;
            this.radioButton60.Location = new System.Drawing.Point(173, 42);
            this.radioButton60.Name = "radioButton60";
            this.radioButton60.Size = new System.Drawing.Size(67, 17);
            this.radioButton60.TabIndex = 54;
            this.radioButton60.Text = "Deficient";
            this.radioButton60.UseVisualStyleBackColor = true;
            this.radioButton60.CheckedChanged += new System.EventHandler(this.deficient);
            // 
            // radioButton61
            // 
            this.radioButton61.AutoSize = true;
            this.radioButton61.Location = new System.Drawing.Point(424, 12);
            this.radioButton61.Name = "radioButton61";
            this.radioButton61.Size = new System.Drawing.Size(65, 17);
            this.radioButton61.TabIndex = 53;
            this.radioButton61.Text = "Marginal";
            this.radioButton61.UseVisualStyleBackColor = true;
            this.radioButton61.CheckedChanged += new System.EventHandler(this.marginal);
            // 
            // radioButton62
            // 
            this.radioButton62.AutoSize = true;
            this.radioButton62.Location = new System.Drawing.Point(349, 10);
            this.radioButton62.Name = "radioButton62";
            this.radioButton62.Size = new System.Drawing.Size(64, 17);
            this.radioButton62.TabIndex = 52;
            this.radioButton62.Text = "Ordinary";
            this.radioButton62.UseVisualStyleBackColor = true;
            this.radioButton62.CheckedChanged += new System.EventHandler(this.ordinary);
            // 
            // radioButton63
            // 
            this.radioButton63.AutoSize = true;
            this.radioButton63.Location = new System.Drawing.Point(248, 10);
            this.radioButton63.Name = "radioButton63";
            this.radioButton63.Size = new System.Drawing.Size(75, 17);
            this.radioButton63.TabIndex = 51;
            this.radioButton63.Text = "Very Good";
            this.radioButton63.UseVisualStyleBackColor = true;
            this.radioButton63.CheckedChanged += new System.EventHandler(this.verygood);
            // 
            // radioButton64
            // 
            this.radioButton64.AutoSize = true;
            this.radioButton64.Location = new System.Drawing.Point(173, 10);
            this.radioButton64.Name = "radioButton64";
            this.radioButton64.Size = new System.Drawing.Size(68, 17);
            this.radioButton64.TabIndex = 50;
            this.radioButton64.Text = "Excellent";
            this.radioButton64.UseVisualStyleBackColor = true;
            this.radioButton64.CheckedChanged += new System.EventHandler(this.excellent);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(10, 12);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(54, 13);
            this.label9.TabIndex = 49;
            this.label9.Text = "Member 2";
            // 
            // p7
            // 
            this.p7.Controls.Add(this.radioButton65);
            this.p7.Controls.Add(this.radioButton66);
            this.p7.Controls.Add(this.radioButton67);
            this.p7.Controls.Add(this.radioButton68);
            this.p7.Controls.Add(this.radioButton69);
            this.p7.Controls.Add(this.radioButton70);
            this.p7.Controls.Add(this.radioButton71);
            this.p7.Controls.Add(this.radioButton72);
            this.p7.Controls.Add(this.label10);
            this.p7.Location = new System.Drawing.Point(0, 48);
            this.p7.Name = "p7";
            this.p7.Size = new System.Drawing.Size(496, 68);
            this.p7.TabIndex = 65;
            this.p7.Enter += new System.EventHandler(this.p1_Enter);
            // 
            // radioButton65
            // 
            this.radioButton65.AutoSize = true;
            this.radioButton65.Location = new System.Drawing.Point(421, 44);
            this.radioButton65.Name = "radioButton65";
            this.radioButton65.Size = new System.Drawing.Size(69, 17);
            this.radioButton65.TabIndex = 49;
            this.radioButton65.Text = "No Show";
            this.radioButton65.UseVisualStyleBackColor = true;
            this.radioButton65.CheckedChanged += new System.EventHandler(this.noshow);
            // 
            // radioButton66
            // 
            this.radioButton66.AutoSize = true;
            this.radioButton66.Location = new System.Drawing.Point(349, 42);
            this.radioButton66.Name = "radioButton66";
            this.radioButton66.Size = new System.Drawing.Size(74, 17);
            this.radioButton66.TabIndex = 48;
            this.radioButton66.Text = "Superficial";
            this.radioButton66.UseVisualStyleBackColor = true;
            this.radioButton66.CheckedChanged += new System.EventHandler(this.superficial);
            // 
            // radioButton67
            // 
            this.radioButton67.AutoSize = true;
            this.radioButton67.Location = new System.Drawing.Point(247, 44);
            this.radioButton67.Name = "radioButton67";
            this.radioButton67.Size = new System.Drawing.Size(92, 17);
            this.radioButton67.TabIndex = 47;
            this.radioButton67.Text = "Unsatisfactory";
            this.radioButton67.UseVisualStyleBackColor = true;
            this.radioButton67.CheckedChanged += new System.EventHandler(this.unsatisfactory);
            // 
            // radioButton68
            // 
            this.radioButton68.AutoSize = true;
            this.radioButton68.Location = new System.Drawing.Point(174, 44);
            this.radioButton68.Name = "radioButton68";
            this.radioButton68.Size = new System.Drawing.Size(67, 17);
            this.radioButton68.TabIndex = 46;
            this.radioButton68.Text = "Deficient";
            this.radioButton68.UseVisualStyleBackColor = true;
            this.radioButton68.CheckedChanged += new System.EventHandler(this.deficient);
            // 
            // radioButton69
            // 
            this.radioButton69.AutoSize = true;
            this.radioButton69.Location = new System.Drawing.Point(421, 14);
            this.radioButton69.Name = "radioButton69";
            this.radioButton69.Size = new System.Drawing.Size(65, 17);
            this.radioButton69.TabIndex = 45;
            this.radioButton69.Text = "Marginal";
            this.radioButton69.UseVisualStyleBackColor = true;
            this.radioButton69.CheckedChanged += new System.EventHandler(this.marginal);
            // 
            // radioButton70
            // 
            this.radioButton70.AutoSize = true;
            this.radioButton70.Location = new System.Drawing.Point(349, 12);
            this.radioButton70.Name = "radioButton70";
            this.radioButton70.Size = new System.Drawing.Size(64, 17);
            this.radioButton70.TabIndex = 44;
            this.radioButton70.Text = "Ordinary";
            this.radioButton70.UseVisualStyleBackColor = true;
            this.radioButton70.CheckedChanged += new System.EventHandler(this.ordinary);
            // 
            // radioButton71
            // 
            this.radioButton71.AutoSize = true;
            this.radioButton71.Location = new System.Drawing.Point(248, 14);
            this.radioButton71.Name = "radioButton71";
            this.radioButton71.Size = new System.Drawing.Size(75, 17);
            this.radioButton71.TabIndex = 43;
            this.radioButton71.Text = "Very Good";
            this.radioButton71.UseVisualStyleBackColor = true;
            this.radioButton71.CheckedChanged += new System.EventHandler(this.verygood);
            // 
            // radioButton72
            // 
            this.radioButton72.AutoSize = true;
            this.radioButton72.Location = new System.Drawing.Point(174, 12);
            this.radioButton72.Name = "radioButton72";
            this.radioButton72.Size = new System.Drawing.Size(68, 17);
            this.radioButton72.TabIndex = 42;
            this.radioButton72.Text = "Excellent";
            this.radioButton72.UseVisualStyleBackColor = true;
            this.radioButton72.CheckedChanged += new System.EventHandler(this.excellent);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(10, 14);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(54, 13);
            this.label10.TabIndex = 41;
            this.label10.Text = "Member 1";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 121);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(216, 20);
            this.label1.TabIndex = 14;
            this.label1.Text = "Step 2 : Choose a Group";
            // 
            // button4
            // 
            this.button4.Enabled = false;
            this.button4.Location = new System.Drawing.Point(16, 153);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(91, 28);
            this.button4.TabIndex = 13;
            this.button4.Text = "Group X";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Enabled = false;
            this.button3.Location = new System.Drawing.Point(16, 218);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(91, 28);
            this.button3.TabIndex = 12;
            this.button3.Text = "Group Z";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Enabled = false;
            this.button2.Location = new System.Drawing.Point(16, 187);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(91, 28);
            this.button2.TabIndex = 11;
            this.button2.Text = "Group Y";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(179, 9);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(483, 34);
            this.label14.TabIndex = 15;
            this.label14.Text = "Project 2, Fall 2007";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(421, 411);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(0, 20);
            this.label15.TabIndex = 17;
            // 
            // button1
            // 
            this.button1.Enabled = false;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(744, 411);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(91, 28);
            this.button1.TabIndex = 18;
            this.button1.Text = "Save Ratings";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label16
            // 
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(12, 43);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(216, 20);
            this.label16.TabIndex = 20;
            this.label16.Text = "Step 1: Select File";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(16, 73);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(100, 28);
            this.button5.TabIndex = 19;
            this.button5.Text = "Select Teams File";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label17
            // 
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(329, 76);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(506, 20);
            this.label17.TabIndex = 21;
            this.label17.Text = "Step 4 : Enter Ratings ";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // label18
            // 
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(12, 269);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(306, 20);
            this.label18.TabIndex = 22;
            this.label18.Text = "Step 3 : Enter Team Grade (0-100)";
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Location = new System.Drawing.Point(16, 292);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 23;
            // 
            // button6
            // 
            this.button6.Enabled = false;
            this.button6.Location = new System.Drawing.Point(122, 290);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(34, 23);
            this.button6.TabIndex = 24;
            this.button6.Text = "OK";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(336, 411);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(0, 20);
            this.label11.TabIndex = 25;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(971, 460);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Peer Ratings Form";
            this.tabControl1.ResumeLayout(false);
            this.t1.ResumeLayout(false);
            this.p3.ResumeLayout(false);
            this.p3.PerformLayout();
            this.p2.ResumeLayout(false);
            this.p2.PerformLayout();
            this.p1.ResumeLayout(false);
            this.p1.PerformLayout();
            this.t2.ResumeLayout(false);
            this.p6.ResumeLayout(false);
            this.p6.PerformLayout();
            this.p5.ResumeLayout(false);
            this.p5.PerformLayout();
            this.p4.ResumeLayout(false);
            this.p4.PerformLayout();
            this.t3.ResumeLayout(false);
            this.p9.ResumeLayout(false);
            this.p9.PerformLayout();
            this.p8.ResumeLayout(false);
            this.p8.PerformLayout();
            this.p7.ResumeLayout(false);
            this.p7.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage t1;
        private System.Windows.Forms.TabPage t2;
        private System.Windows.Forms.TabPage t3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Panel p3;
        private System.Windows.Forms.RadioButton radioButton25;
        private System.Windows.Forms.RadioButton radioButton26;
        private System.Windows.Forms.RadioButton radioButton27;
        private System.Windows.Forms.RadioButton radioButton28;
        private System.Windows.Forms.RadioButton radioButton29;
        private System.Windows.Forms.RadioButton radioButton30;
        private System.Windows.Forms.RadioButton radioButton31;
        private System.Windows.Forms.RadioButton radioButton32;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel p2;
        private System.Windows.Forms.RadioButton radioButton33;
        private System.Windows.Forms.RadioButton radioButton34;
        private System.Windows.Forms.RadioButton radioButton35;
        private System.Windows.Forms.RadioButton radioButton36;
        private System.Windows.Forms.RadioButton radioButton37;
        private System.Windows.Forms.RadioButton radioButton38;
        private System.Windows.Forms.RadioButton radioButton39;
        private System.Windows.Forms.RadioButton radioButton40;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel p1;
        private System.Windows.Forms.RadioButton radioButton41;
        private System.Windows.Forms.RadioButton radioButton42;
        private System.Windows.Forms.RadioButton radioButton43;
        private System.Windows.Forms.RadioButton radioButton44;
        private System.Windows.Forms.RadioButton radioButton45;
        private System.Windows.Forms.RadioButton radioButton46;
        private System.Windows.Forms.RadioButton radioButton47;
        private System.Windows.Forms.RadioButton radioButton48;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel p6;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel p5;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.RadioButton radioButton10;
        private System.Windows.Forms.RadioButton radioButton11;
        private System.Windows.Forms.RadioButton radioButton12;
        private System.Windows.Forms.RadioButton radioButton13;
        private System.Windows.Forms.RadioButton radioButton14;
        private System.Windows.Forms.RadioButton radioButton15;
        private System.Windows.Forms.RadioButton radioButton16;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel p4;
        private System.Windows.Forms.RadioButton radioButton17;
        private System.Windows.Forms.RadioButton radioButton18;
        private System.Windows.Forms.RadioButton radioButton19;
        private System.Windows.Forms.RadioButton radioButton20;
        private System.Windows.Forms.RadioButton radioButton21;
        private System.Windows.Forms.RadioButton radioButton22;
        private System.Windows.Forms.RadioButton radioButton23;
        private System.Windows.Forms.RadioButton radioButton24;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel p9;
        private System.Windows.Forms.RadioButton radioButton49;
        private System.Windows.Forms.RadioButton radioButton50;
        private System.Windows.Forms.RadioButton radioButton51;
        private System.Windows.Forms.RadioButton radioButton52;
        private System.Windows.Forms.RadioButton radioButton53;
        private System.Windows.Forms.RadioButton radioButton54;
        private System.Windows.Forms.RadioButton radioButton55;
        private System.Windows.Forms.RadioButton radioButton56;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel p8;
        private System.Windows.Forms.RadioButton radioButton57;
        private System.Windows.Forms.RadioButton radioButton58;
        private System.Windows.Forms.RadioButton radioButton59;
        private System.Windows.Forms.RadioButton radioButton60;
        private System.Windows.Forms.RadioButton radioButton61;
        private System.Windows.Forms.RadioButton radioButton62;
        private System.Windows.Forms.RadioButton radioButton63;
        private System.Windows.Forms.RadioButton radioButton64;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel p7;
        private System.Windows.Forms.RadioButton radioButton65;
        private System.Windows.Forms.RadioButton radioButton66;
        private System.Windows.Forms.RadioButton radioButton67;
        private System.Windows.Forms.RadioButton radioButton68;
        private System.Windows.Forms.RadioButton radioButton69;
        private System.Windows.Forms.RadioButton radioButton70;
        private System.Windows.Forms.RadioButton radioButton71;
        private System.Windows.Forms.RadioButton radioButton72;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
    }
}