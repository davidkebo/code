using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Project_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Array containing the student objects pulled from the stream
        Student[] classArray = new Student[20];
        //create an array of each group
        Student[] groupX = new Student[10];
        Student[] groupY = new Student[10];
        Student[] groupZ = new Student[10];
        Student[] SelectedGroup = new Student[10];
        double TeamGrade;
        string SelectedPanel;

        // Action on Save Button: Computes the score of the selected group members 
        // and write the results to a file
        private void button1_Click(object sender, EventArgs e)
        {
            ComputeScore(SelectedGroup);
            Stream myStream;
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();

            saveFileDialog1.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            saveFileDialog1.FilterIndex = 2;
            saveFileDialog1.RestoreDirectory = true;

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                if ((myStream = saveFileDialog1.OpenFile()) != null)
                {
                    //  Write the string representation of the student objects to a file
                    StreamWriter sw = new StreamWriter(myStream);
                    for (int i = 0; i < SelectedGroup.GetLength(0); i++)
                    {
                        if (SelectedGroup[i] != null)
                            sw.WriteLine(SelectedGroup[i].ToString() + "\n");
                    }//end for
                    sw.Close();
                    myStream.Close();
                }
            }
        }

        // Action on button 'Open Team File': Open the file and copy data to a student Array
        private void button5_Click(object sender, EventArgs e)
        {
            Stream myStream = null;
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            openFileDialog1.InitialDirectory = "c:\\";
            openFileDialog1.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    if ((myStream = openFileDialog1.OpenFile()) != null)
                    {
                        // Enable The other buttons of the window
                        this.button4.Enabled = true;
                        this.button2.Enabled = true;
                        this.button3.Enabled = true;

                        using (myStream)
                        {
                            // Insert code to read the stream here.
                            StreamReader infile = new StreamReader(myStream);
                            string line;
                            string[] studentParams = new string[4];

                            int counter = 0;
                            line = infile.ReadLine();
                            //reads in students from the input file and stores them in classArray
                            while (line != null)
                            {
                                Student tempStudent = new Student();

                                studentParams = line.Split(',');

                                tempStudent.LastName = studentParams[0];
                                tempStudent.FirstName = studentParams[1];
                                tempStudent.Email = studentParams[2];
                                tempStudent.Group = studentParams[3];
                                tempStudent.Rating1 = 1;
                                tempStudent.Rating2 = 1;
                                tempStudent.Rating3 = 1;
                                tempStudent.Score = 0;

                                classArray.SetValue(tempStudent, counter);

                                line = infile.ReadLine();
                                counter++;

                            }//end while 
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);
                }
            }
            this.label15.Text = "";
            this.label11.Text = "";
        }
        // Action on button 'Group X'
        private void button4_Click(object sender, EventArgs e)
        {
            this.button4.Enabled = false;
            this.label11.Text = "Group X's";
            this.label17.Text = "Step 4 : Enter Ratings for Group X";
            this.textBox1.Enabled = true;
            this.button6.Enabled = true;
            ReportGroup(classArray, "X");
            CheckStatus(SelectedGroup);
            ClearButtons();
        }

        // Action on button 'Group Y'
        private void button2_Click(object sender, EventArgs e)
        {
            this.button2.Enabled = false;
            this.label11.Text = "Group Y's";
            this.label17.Text = "Step 4 : Enter Ratings for Group Y";
            this.textBox1.Enabled = true;
            this.button6.Enabled = true;
            ReportGroup(classArray, "Y");
            CheckStatus(SelectedGroup);
            ClearButtons();
        }

        // Action on button 'Group Z'
        private void button3_Click(object sender, EventArgs e)
        {
            this.button3.Enabled = false;
            this.label11.Text = "Group Z's";
            this.label17.Text = "Step 4 : Enter Ratings for Group Z";
            this.textBox1.Enabled = true;
            this.button6.Enabled = true;
            ReportGroup(classArray, "Z");
            CheckStatus(SelectedGroup);
            ClearButtons();
        }

        // Action on button 'OK': checks the validity of the team grade assigned by the user
        private void button6_Click(object sender, EventArgs e)
        {
            if ((System.Convert.ToDouble(this.textBox1.Text) < 0 || (System.Convert.ToDouble(this.textBox1.Text) > 100)))
            {
                this.label15.Text = "The grade entered is invalid";
                this.tabControl1.Enabled = false;
                this.button1.Enabled = false;
            }
            else
            {
                CheckStatus(SelectedGroup);
                TeamGrade = System.Convert.ToDouble(this.textBox1.Text);
                this.tabControl1.Enabled = true;
            }
        }

        private void excellent(object sender, EventArgs e)
        {
            AssignRatingToButton(100);
            CheckStatus(SelectedGroup);
        }

        private void verygood(object sender, EventArgs e)
        {
            AssignRatingToButton(87.5);
            CheckStatus(SelectedGroup);
        }

        private void ordinary(object sender, EventArgs e)
        {
            AssignRatingToButton(62.5);
            CheckStatus(SelectedGroup);
        }

        private void marginal(object sender, EventArgs e)
        {
            AssignRatingToButton(50);
            CheckStatus(SelectedGroup);
        }

        private void deficient(object sender, EventArgs e)
        {
            AssignRatingToButton(37.5);
            CheckStatus(SelectedGroup);
        }

        private void unsatisfactory(object sender, EventArgs e)
        {
            AssignRatingToButton(25);
            CheckStatus(SelectedGroup);
        }

        private void superficial(object sender, EventArgs e)
        {
            AssignRatingToButton(12.5);
            CheckStatus(SelectedGroup);
        }

        private void noshow(object sender, EventArgs e)
        {
            AssignRatingToButton(0);
            CheckStatus(SelectedGroup);
        }

        // CheckStatus function: Checks the status of ratings entry for the selected group
        // Displays whether or not a report can be printed
        public void CheckStatus(Student[] GroupArray)
        {
            bool check1 = false, check2 = false, check3 = false;

            if (GroupArray[0].Rating1 != 1 && GroupArray[0].Rating2 != 1 && GroupArray[0].Rating3 != 1)
                check1 = true;
            else
                check1 = false;

            if (GroupArray[1].Rating1 != 1 && GroupArray[1].Rating2 != 1 && GroupArray[1].Rating3 != 1)
                check2 = true;
            else
                check2 = false;

            if (GroupArray[2].Rating1 != 1 && GroupArray[2].Rating2 != 1 && GroupArray[2].Rating3 != 1)
                check3 = true;
            else
                check3 = false;

            if (check1 = true && check2 == true && check3 == true)
            {
                this.label15.Text = " report is completed and can be saved";
                this.button1.Enabled = true;
            }
            else
            {
                this.label15.Text = " new report is not completed yet";
                this.button1.Enabled = false;
            }
        }

        // ComputeScore: computes the final score of each member using the ratings entered and the team grade.
        public void ComputeScore(Student[] GroupArray)
        {
            double GroupAverage;
            GroupAverage = (GroupArray[0].Rating1 + GroupArray[0].Rating2 + GroupArray[0].Rating3 +
                                         GroupArray[1].Rating1 + GroupArray[1].Rating2 + GroupArray[1].Rating3 +
                                         GroupArray[2].Rating1 + GroupArray[2].Rating2 + GroupArray[2].Rating3) / 9;
            GroupArray[0].Score = Math.Round((((GroupArray[0].Rating1 + GroupArray[0].Rating2 + GroupArray[0].Rating3) / 3) / GroupAverage)
                              * TeamGrade, 1);
            GroupArray[1].Score = Math.Round((((GroupArray[1].Rating1 + GroupArray[1].Rating2 + GroupArray[1].Rating3) / 3) / GroupAverage)
                             * TeamGrade, 1);
            GroupArray[2].Score = Math.Round((((GroupArray[2].Rating1 + GroupArray[2].Rating2 + GroupArray[2].Rating3) / 3) / GroupAverage)
                             * TeamGrade, 1);
        }

        /* This function finds the radio button clicked on
           and assigns the corresponding rating */
        public void AssignRatingToButton(double score)
        {
            if (SelectedPanel == "p1")
                SelectedGroup[0].Rating1 = score;
            if (SelectedPanel == "p2")
                SelectedGroup[1].Rating1 = score;
            if (SelectedPanel == "p3")
                SelectedGroup[2].Rating1 = score;
            if (SelectedPanel == "p4")
                SelectedGroup[0].Rating2 = score;
            if (SelectedPanel == "p5")
                SelectedGroup[1].Rating2 = score;
            if (SelectedPanel == "p6")
                SelectedGroup[2].Rating2 = score;
            if (SelectedPanel == "p7")
                SelectedGroup[0].Rating3 = score;
            if (SelectedPanel == "p8")
                SelectedGroup[1].Rating3 = score;
            if (SelectedPanel == "p9")
                SelectedGroup[2].Rating3 = score;
        }

       // ReportGroup: breaks the classArray into three separate groups X, Y and Z 
       // and displays the members name on the window
        public void ReportGroup(Student[] StudentArray, string aGroup)
        {
            int x = 0, y = 0, z = 0;
          
            /*Determine which students are in each group
              put them in the respective group array */
            for (int i = 0; i < StudentArray.GetLength(0); i++)
            {
                if (StudentArray[i] != null)
                {
                    if (StudentArray[i].Group == "X")
                    {
                        groupX[x] = StudentArray[i];
                        x++;
                    }//end if
                    else if (StudentArray[i].Group == "Y")
                    {
                        groupY[y] = StudentArray[i];
                        y++;
                    }//end else if
                    else if (StudentArray[i].Group == "Z")
                    {
                        groupZ[z] = StudentArray[i];
                        z++;
                    }//end else if
                }//end if
            }//end for

            // This Displays the name of each team member on a dedicated tab
            if (aGroup == "X")
            {
                for (int i = 0; i < groupX.GetLength(0); i++)
                    SelectedGroup[i] = groupX[i];
                AddNamesOnWindow(groupX);
            }

            if (aGroup == "Y")
            {
                for (int i = 0; i < groupY.GetLength(0); i++)
                    SelectedGroup[i] = groupY[i];
                AddNamesOnWindow(groupY);
            }

            if (aGroup == "Z")
            {
                for (int i = 0; i < groupZ.GetLength(0); i++)
                    SelectedGroup[i] = groupZ[i];
                AddNamesOnWindow(groupZ);
            }
        }  //end ReportGroup

        // AddNamesOnWindow: displays members names on dedicated tabs and labels
        public void AddNamesOnWindow(Student[] GroupArray)
        {
            this.t1.Text = GroupArray[0].LastName + ", " + GroupArray[0].FirstName;
            this.label7.Text = GroupArray[0].LastName + ", " + GroupArray[0].FirstName;
            this.label6.Text = GroupArray[1].LastName + ", " + GroupArray[1].FirstName;
            this.label5.Text = GroupArray[2].LastName + ", " + GroupArray[2].FirstName;

            this.t2.Text = GroupArray[1].LastName + ", " + GroupArray[1].FirstName;
            this.label4.Text = GroupArray[0].LastName + ", " + GroupArray[0].FirstName;
            this.label3.Text = GroupArray[1].LastName + ", " + GroupArray[1].FirstName;
            this.label2.Text = GroupArray[2].LastName + ", " + GroupArray[2].FirstName;

            this.t3.Text = GroupArray[2].LastName + ", " + GroupArray[2].FirstName;
            this.label10.Text = GroupArray[0].LastName + ", " + GroupArray[0].FirstName;
            this.label9.Text = GroupArray[1].LastName + ", " + GroupArray[1].FirstName;
            this.label8.Text = GroupArray[2].LastName + ", " + GroupArray[2].FirstName;
        }

        private void p1_Enter(object sender, EventArgs e)
        {
            SelectedPanel = ((Control)sender).Name;
        }

        // ClearButtons: uncheck all the radioButtons so that the user can enter new ratings again
         public void ClearButtons()
        {
            this.radioButton72.Checked = false; this.radioButton71.Checked = false; this.radioButton70.Checked = false; this.radioButton69.Checked = false; this.radioButton68.Checked = false;
            this.radioButton67.Checked = false; this.radioButton66.Checked = false; this.radioButton65.Checked = false; this.radioButton64.Checked = false; this.radioButton63.Checked = false;
            this.radioButton62.Checked = false; this.radioButton61.Checked = false; this.radioButton60.Checked = false; this.radioButton59.Checked = false; this.radioButton58.Checked = false;
            this.radioButton57.Checked = false; this.radioButton56.Checked = false; this.radioButton55.Checked = false; this.radioButton54.Checked = false; this.radioButton53.Checked = false;
            this.radioButton52.Checked = false; this.radioButton51.Checked = false; this.radioButton50.Checked = false; this.radioButton49.Checked = false; this.radioButton48.Checked = false;
            this.radioButton47.Checked = false; this.radioButton46.Checked = false; this.radioButton45.Checked = false; this.radioButton44.Checked = false; this.radioButton43.Checked = false;
            this.radioButton43.Checked = false; this.radioButton42.Checked = false; this.radioButton41.Checked = false; this.radioButton40.Checked = false; this.radioButton39.Checked = false;
            this.radioButton38.Checked = false; this.radioButton37.Checked = false; this.radioButton36.Checked = false; this.radioButton35.Checked = false; this.radioButton34.Checked = false;
            this.radioButton33.Checked = false; this.radioButton32.Checked = false; this.radioButton31.Checked = false; this.radioButton30.Checked = false; this.radioButton29.Checked = false;
            this.radioButton28.Checked = false; this.radioButton27.Checked = false; this.radioButton26.Checked = false; this.radioButton25.Checked = false; this.radioButton24.Checked = false;
            this.radioButton23.Checked = false; this.radioButton22.Checked = false; this.radioButton21.Checked = false; this.radioButton20.Checked = false; this.radioButton19.Checked = false;
            this.radioButton18.Checked = false; this.radioButton17.Checked = false; this.radioButton16.Checked = false; this.radioButton15.Checked = false; this.radioButton14.Checked = false;
            this.radioButton13.Checked = false; this.radioButton12.Checked = false; this.radioButton11.Checked = false; this.radioButton10.Checked = false; this.radioButton9.Checked = false;
            this.radioButton8.Checked = false; this.radioButton7.Checked = false; this.radioButton6.Checked = false; this.radioButton5.Checked = false; this.radioButton4.Checked = false;
            this.radioButton3.Checked = false; this.radioButton2.Checked = false; this.radioButton1.Checked = false; 
                   
        }
    }
}