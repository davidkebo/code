using System;
using System.Collections.Generic;
using System.Text;

namespace Project_2
{
   public class Student
    {
        private string lastname;
        private string firstname;
        private string email;
        private string group;
        private double rating1;
        private double rating2;
        private double rating3;
        private double score;

        public Student()
        {
            lastname = "";
            firstname = "";
            email = "";
            group = "";
            rating1 = 1;
            rating2 = 1;
            rating3 = 1;
            score = 0;
        }// end constructor with no params

       public Student(string lName, string fName, string eMail, string Group, double r1, double r2, double r3, double aScore)
        {
            lastname = lName;
            firstname = fName;
            email = eMail;
            group = Group;
            rating1 = r1;
            rating2 = r2;
            rating3 = r3;
            score = aScore;
        }// end constructor with three params

        // Override default ToString()
        public override string ToString()
        {
            return this.lastname + ", " + this.firstname +
                "\t\t   Email: " + this.email + "\t\t   Group: " + this.group + "\t\t   Score: " + this.score;
        }

        // property LastName
        public string LastName
        {
            get { return lastname; }
            set { lastname = value; }
        }// end property LastName

        // property FirstName
        public string FirstName
        {
            get { return firstname; }
            set { firstname = value; }
        }// end property FirstName

        // property Email
        public string Email
        {
            get { return email; }
            set { email = value; }
        }// end property Email

        // property Group
        public string Group
        {
            get { return group; }
            set { group = value; }
        }// end property Group

        // property Rating1
       public double Rating1
        {
            get { return rating1; }
            set { rating1 = value; }
        }// end property Rating1

        // property Rating2
       public double Rating2
        {
            get { return rating2; }
            set { rating2 = value; }
        }// end property Rating2

        // property Rating3
       public double Rating3
        {
            get { return rating3; }
            set { rating3 = value; }
        }// end property Rating3

        // property Score
       public double Score
        {
            get { return score; }
            set { score = value; }
        }// end property Score

    }//end class Student
}//end namespace Project1
