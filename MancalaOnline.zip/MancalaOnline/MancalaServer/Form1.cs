/*File: MancalaServer.cs
  This class maintains the server for the Mancala game
 ----------------------------------------------------------------------
  Class: CS 390								Instructor: Dr. Deborah Hwang
  Software Project					     	Date assigned: October 07, 2008 
  Programmer: David Houngninou				Date completed: December 11, 2008 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using System.IO;

namespace MancalaOnline
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        IPAddress ipAddress;
        private Player[] players; // two player objects
        private Thread[] playerThreads; // Threads for client interaction
        private TcpListener server; // Listen for client connection
        private int currentPlayer; // current Player
        private Thread getPlayers; // Thread for acquring client connections
        internal bool disconnected = false; // Server closes

        private int cxClient;       // form client width     
        private int cyClient;       // form client height
        private int boxX;         // panel width
        private int boxY;         // panel height
        int pitPosition = 0; // Position of the pit

        private Pit[,] board = new Pit[2, 8]; // Board containing the 14 pits

        private void Form1_Load(object sender, EventArgs e)
        {
            players = new Player[2];
            playerThreads = new Thread[2];
            currentPlayer = 0;
            cxClient = this.ClientSize.Width;
            cyClient = this.ClientSize.Height - 90;
            boxX = cxClient / 8;
            boxY = cyClient / 2;
            int row, col;
            for (row = 0; row < 2; row++)
                for (col = 0; col < 8; col++)
                {
                    string pitName = pitPosition.ToString();  // Name the pit 
                    Point newLocation = new Point(col * boxX, (row * boxY) + 24); // Location of the Pit
                    PictureBox newPictureBox = new PictureBox(); // Picture representing a pit
                    newPictureBox.Name = pitName; // Name assigned to a pit
                    newPictureBox.Location = newLocation; // Location assigend to a pit
                    newPictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
                    int newNumberOfStones = 0; // Number of stones in a pit

                    if ((col == 0 && row == 0) || (col == 7 && row == 0)) // The 02 large Kalaha pits
                    {
                        newPictureBox.Width = boxX;
                        newPictureBox.Height = cyClient;
                        newPictureBox.Image = pictureFile("kalaha", 0);
                        newNumberOfStones = 0; // Initial number of stones
                    }

                    else // The 12 other small pits
                    {
                        newPictureBox.Width = boxX;
                        newPictureBox.Height = boxY;
                        newPictureBox.Image = pictureFile("pit", 3);
                        newNumberOfStones = 3; // Initial number of stones
                    }

                    // define the empty board
                    board[row, col] = new Pit(newPictureBox, newLocation, newNumberOfStones);
                    this.Controls.Add(board[row, col].PitBox);
                    pitPosition++;
                }

            PaintSquares(); // Draw the game board
        } // End Form1_Load

        public Bitmap pictureFile(string pitType, int number) // Create a bitmap image
        {
            string fileName;

            if (pitType == "pit")
                fileName = "c:/Mancala Files/stones" + number + ".jpg";
            else
                fileName = "c:/Mancala Files/kalaha" + number + ".jpg";

            Bitmap bmp = new Bitmap(fileName);
            return bmp;
        }// End PictureFile

        // Notify Players to stop running
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            disconnected = true;
            System.Environment.Exit(System.Environment.ExitCode);
        } // End Form1_FormClosing

        //Delegate that allows method DisplayMessage to be called
        // In the thread that maintains the GUI
        private delegate void DisplayDelegate(string message, bool clear);

        //Set text property
        internal void DisplayMessage(string message, bool clear)
        {
            //If not thread safe
            if (GameMessage.InvokeRequired)
            {
                Invoke(new DisplayDelegate(DisplayMessage), new object[] { message, clear });
            }
            else
            {
                if (clear == false)
                    GameMessage.Text += message; // Write message to text box
                else
                    GameMessage.Text = message; // Clear the message box first
            }
        } // End method DisplayMessage

        // Accept connection from 02 Players
        public void SetUp()
        {
            DisplayMessage("Waiting for players ... \r\n", false);

            // Accept first player and start a player thread
            players[0] = new Player(server.AcceptSocket(), this, 0);
            playerThreads[0] = new Thread(new ThreadStart(players[0].Run));
            playerThreads[0].Start();

            // Accept second player and start another player thread
            players[1] = new Player(server.AcceptSocket(), this, 1);
            playerThreads[1] = new Thread(new ThreadStart(players[1].Run));
            playerThreads[1].Start();

            // Let the first player know that the other player has connected
            lock (players[0])
            {
                players[0].threadSuspended = false;
                Monitor.Pulse(players[0]);
            } // end lock
        } // end method SetUp

        public bool rightPlayerSide(int location, int player) // Check player side
        {
            if ((location >= 1) && (location <= 6)) // Identify player 1's side
            {
                if (player == 0) return true;
                else return false;
            }
            else if ((location >= 8) && (location <= 13)) // Identify player 2's side
            {
                if (player == 1) return true;
                else return false;
            }
            else
                return false;
        } // end rightPlayerSide

        // Determine if a move is valid
        public bool ValidMove(int location, int player, int numberOfStones, bool endGame)
        {
            // Prevent another thread from making a move
            lock (this)
            {
                // While it is not the current player's turn, wait
                while (player != currentPlayer)
                    Monitor.Wait(this);

                // If the desired square is not empty
                if ((IsNotEmpty(numberOfStones) && rightPlayerSide(location, player)) || (endGame))
                {
                    currentPlayer = (currentPlayer + 1) % 2; // Switch Player
                    players[currentPlayer].OtherPlayerMoved(location, numberOfStones, endGame); // Notify the other player of the move
                    RefreshServerDisplay(location, numberOfStones, currentPlayer); // Refresh the server board
                    Monitor.Pulse(this); // Alert the other player that it is time to move
                    return true;
                }
                else
                    return false;
            }// End lock
        }// End ValidMove

        public void SetNewGame(int player)
        { 
         // Prevent another thread from making a move
            lock (this)
            {
                // While it is not the current player's turn, wait
                while (player != currentPlayer)
                    Monitor.Wait(this);

                    currentPlayer = (currentPlayer + 1) % 2; // Switch Player
                    players[currentPlayer].NewGame(); // Notify the other player of a new game
                    ResetGame(); // Reset the board for a new game
                    Monitor.Pulse(this); // Alert the other player
            }
        } // End SetNewGame

        public void ResetGame() // Reset the board for a new game
        {
            for (int row = 0; row < 2; row++)
                for (int col = 0; col < 8; col++)
                {
                    if ((row == 0 && col == 0) || (row == 0 && col == 7))
                    {
                        board[row, col].NumberOfStones = 0;
                        board[row, col].PitBox.Image = pictureFile("kalaha", board[row, col].NumberOfStones);
                    }
                    else
                    {
                        board[row, col].NumberOfStones = 3;
                        board[row, col].PitBox.Image = pictureFile("pit", board[row, col].NumberOfStones);
                    }
                }
            PaintSquares(); // Draw the game board
        } // End ResetGame

        public void RefreshServerDisplay(int location, int numberOfStones, int player)
        {
            int transRow = 0, transCol = 0; // Translate the location into coordinates
            // Translate the location into coordinates
            if ((location >= 1) && (location <= 6))
            {
                transRow = 1; transCol = location;
            }
            else
            {
                transRow = 0; transCol = 14 - location;
            }

            DistributeStones(numberOfStones, transRow, transCol, FullRotation(numberOfStones, location), player); // Split the stones in the pits

            PaintSquares(); // Draw the game board
        }// End UpdateServerDisplay 

        // Split the stones in the pits
        public void DistributeStones(int numStones, int row, int col, bool rotation, int player)
        {
            board[row, col].NumberOfStones = 0; // Empty the pit

            if ((col == 0 && row == 0) || (col == 7 && row == 0))
                board[row, col].PitBox.Image = pictureFile("kalaha", board[row, col].NumberOfStones);
            else
                board[row, col].PitBox.Image = pictureFile("pit", board[row, col].NumberOfStones);

            for (int i = 0; i < numStones; i++) // Fill the adjacent pits counterclockwise
            {
                if (col < 6 && row == 1)
                {
                    col++; // Jump to the next adjacent pit (Forward move)
                    board[row, col].NumberOfStones++; // Add one stone to that pit
                    board[row, col].PitBox.Image = pictureFile("pit", board[row, col].NumberOfStones);
                }
                else if (col == 6 && row == 1) // Right Kalaha Pit
                {
                    col++; // Jump to the next adjacent pit (Forward move)
                    row--;
                    board[row, col].NumberOfStones++; // Add one stone to that pit
                    board[row, col].PitBox.Image = pictureFile("kalaha", board[row, col].NumberOfStones);
                }
                else if (col > 1 && row == 0)
                {
                    col--; // Jump to the next adjacent pit (Backward move)
                    board[row, col].NumberOfStones++; // Add one stone to that pit
                    board[row, col].PitBox.Image = pictureFile("pit", board[row, col].NumberOfStones);
                }
                else if (col == 1 && row == 0) // Left Kalaha Pit
                {
                    col--;
                    board[row, col].NumberOfStones++; // Add one stone to that pit
                    board[row, col].PitBox.Image = pictureFile("kalaha", board[row, col].NumberOfStones);
                }

                else if (col == 0 && row == 0) // Left Kalaha Pit
                {
                    col++;
                    row++;
                    board[row, col].NumberOfStones++; // Add one stone to that pit
                    board[row, col].PitBox.Image = pictureFile("pit", board[row, col].NumberOfStones);
                }
            }

            int lastDropRow = row, lastDropColumn = col;

            if (rotation == true) // A valid move with full rotation
            {
                if (board[lastDropRow, lastDropColumn].NumberOfStones == 1) // Rotation ends in player's empty pit
                {
                    string niceMove = "Player " + ((player + 1) % 2) + " got player " + player + "'s stones.\r\n";
                    DisplayMessage(niceMove,false);

                    int caughtStones = 1 + board[(lastDropRow + 1) % 2, lastDropColumn].NumberOfStones; // Get Opponents stones
                    board[lastDropRow, lastDropColumn].NumberOfStones = 0;
                    board[lastDropRow, lastDropColumn].PitBox.Image = pictureFile("pit", board[lastDropRow, lastDropColumn].NumberOfStones);
                    board[(lastDropRow + 1) % 2, lastDropColumn].NumberOfStones = 0;
                    board[(lastDropRow + 1) % 2, lastDropColumn].PitBox.Image = pictureFile("pit", board[(lastDropRow + 1) % 2, lastDropColumn].NumberOfStones);

                    if (lastDropRow == 0) // Add stones to the players pit
                    {
                        board[0, 0].NumberOfStones = board[0, 0].NumberOfStones + caughtStones;
                        board[0, 0].PitBox.Image = pictureFile("kalaha", board[0, 0].NumberOfStones);
                    }
                    else if (lastDropRow == 1) // Add stones to the players pit
                    {
                        board[0, 7].NumberOfStones = board[0, 7].NumberOfStones + caughtStones;
                        board[0, 7].PitBox.Image = pictureFile("kalaha", board[0, 7].NumberOfStones);
                    }
                }
            }
        } // End DistributeStones

        // Determine whether the specified square is not empty
        public bool IsNotEmpty(int numberOfStones)
        {
            if (numberOfStones != 0)
                return true;
            else return false;
        } // End IsNotEmpty

        // Checks if a player has made a full rotation while distributing stones
        public bool FullRotation(int numberOfStones, int location)
        {
            int transCol = 0; // Translate the location into coordinates
            // Translate the location into coordinates
            if ((location >= 1) && (location <= 6))
            {
                transCol = location;
                if (numberOfStones >= 15 - transCol)
                    return true;
                else
                    return false;
            }

            else
            {
                transCol = 14 - location;
                if (numberOfStones >= 8 + transCol)
                    return true;
                else
                    return false;
            }
        } // End FullRotation

        // Determine if a game is over
        public bool GameOver(int kalaha0Stones, int kalaha1Stones, bool forfeit)
        {
            string winMessage = "Win", lostMessage = "Lost";

            if (forfeit || kalaha0Stones >= 18 || kalaha1Stones >= 18) // If the game is over
            {
                if (forfeit && kalaha0Stones >= kalaha1Stones) // If player 1 is short of stones
                {
                    winMessage = "Forfeit: Player 0 won with " + kalaha0Stones + " stones!\r\n";
                    lostMessage = "Forfeit: Player 1 lost with " + kalaha1Stones + " stones!\r\n";
                }
                else if (forfeit && kalaha1Stones >= kalaha0Stones)// If player 0 is short of stones
                {
                    winMessage = "Forfeit: Player 1 won with " + kalaha1Stones + " stones!\r\n";
                    lostMessage = "Forfeit: Player 0 lost with " + kalaha0Stones + " stones!\r\n";
                }

                else if (kalaha0Stones >= 18) // Player 0 won
                {
                    winMessage = "Player 0 won with " + kalaha0Stones + " stones!\r\n";
                    lostMessage = "Player 1 lost with " + kalaha1Stones + " stones!\r\n";
                }
                else if (kalaha1Stones >= 18) // Player 1 won
                {
                    winMessage = "Player 1 won with " + kalaha1Stones + " stones!\r\n";
                    lostMessage = "Player 0 lost with " + kalaha0Stones + " stones!\r\n";              
                }

                MessageBox.Show(winMessage, "Server: Game Over!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DisplayMessage(winMessage, false);
                DisplayMessage(lostMessage, false);

                // Write final scores to the scores file
                StreamWriter scoreWriter = new StreamWriter("C:/Mancala Files/scores.txt", true);
                StreamWriter RecentScoreWriter = new StreamWriter("C:/Mancala Files/recentScore.txt", false);
                scoreWriter.WriteLine(winMessage);
                scoreWriter.WriteLine(lostMessage);
                scoreWriter.WriteLine("--------------");
                scoreWriter.Close();
                RecentScoreWriter.WriteLine(winMessage);
                RecentScoreWriter.WriteLine(lostMessage);
                RecentScoreWriter.WriteLine("--------------");
                RecentScoreWriter.Close();
                return true;
            }

            // the game is not over yet
            else return false;
        } // End GameOver

        public void PaintSquares()
        {
            Graphics g;
            try
            {
                for (int row = 0; row < 2; row++)
                    for (int col = 0; col < 8; col++)
                    {
                        // get graphics for each Panel
                        g = board[row, col].PitBox.CreateGraphics();
                        g.Dispose(); // dispose of graphics object since we are done with it for now
                    }
            }
            catch (ObjectDisposedException)
            {
                MessageBox.Show("Server window closed", "Mancala server", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        } // end PaintSquares

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            PaintSquares();
        }

        private void aboutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            // Display the About form 
            About aboutPage = new About();
            aboutPage.ShowDialog(this);
        }

        private void quitToolStripMenuItem_Click(object sender, EventArgs e) // Close the window Form 1;
        { 
            this.Close();
        }

        private void scoresRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Scores scoreWindow = new Scores();
            StreamReader scoreReader = new StreamReader("c:/Mancala Files/scores.txt");
            // Read scores from scores.txt file and display them in a window
            string read = null;
            while ((read = scoreReader.ReadLine()) != null)
            {
                scoreWindow.scoresTextBox.Text += read + "\r\n";
            }
            scoreReader.Close();

            // Display the score form 
            scoreWindow.ShowDialog(this);
        }

        private void userManualToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Display the user manual form
            UserManual manual = new UserManual();
            manual.ShowDialog(this);
        }

        private void recentScoreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Scores scoreWindow = new Scores();
            StreamReader scoreReader = new StreamReader("c:/Mancala Files/recentScore.txt");
            // Read scores from scores.txt file and display them in a window
            string read = null;
            while ((read = scoreReader.ReadLine()) != null)
            {
                scoreWindow.scoresTextBox.Text += read + "\r\n";
            }
            scoreReader.Close();

            // Display the score form 
            scoreWindow.ShowDialog(this);
        }

        private void IPButton_Click(object sender, EventArgs e) // Get the server's IP address from a text box
        {
            string serverIP = IPtextBox.Text;

            try
            {
                ipAddress = System.Net.Dns.GetHostAddresses(serverIP)[0];
                // Set up Socket
                server = new TcpListener(ipAddress, 9999);
                server.Start();
                // Accept connections on a different thread
                getPlayers = new Thread(new ThreadStart(SetUp));
                getPlayers.Start();
                IPButton.Enabled = false;
                IPtextBox.Enabled = false;
            }
            catch (SocketException)
            {
                MessageBox.Show("The IP address is incorrect", "Mancala server IP", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    } // End class Form1


    // Class player that represents a player
    public class Player
    {
        internal Socket connection; // Socket for accepting a connection
        private NetworkStream socketStream; // Network data stream
        private Form1 server; // Reference to the server
        private BinaryWriter writer; // facilitates writing to the stream
        private BinaryReader reader; // facilitates reading from the stream
        private int number; // player number
        internal bool threadSuspended = true; // if waiting for other player

        //Constructor requiring socket
        public Player(Socket socket, Form1 serverValue, int newNumber)
        {
            connection = socket;
            server = serverValue;
            number = newNumber;

            // Create NetworkStream object for Socket
            socketStream = new NetworkStream(connection);
            // Create Streams for reading/writing bytes
            writer = new BinaryWriter(socketStream);
            reader = new BinaryReader(socketStream);
        } // End constructor

        // Signal the other player of a move
        public void OtherPlayerMoved(int location, int stones, bool endGame)
        {
            try
            {
                // Signal that opponent has moved
                writer.Write("Opponent moved.");
                writer.Write(location); // Send location of move
                writer.Write(stones); // Send number of stones
                writer.Write(server.FullRotation(stones, location));
                writer.Write(endGame);
            }
            catch (IOException)
            {
                MessageBox.Show("Game over, opponent quit", "Mancala server", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        } // End OtherPlayerMoved

        // Signal the other player of a new game
        public void NewGame()
        {
            // Signal new game
            writer.Write("Opponent requested new game.");
        }

        // Allows the players to make moves and receive moves from other player
        public void Run()
        {
            bool done = false, endOfGame = false;

            // Display on the server that a connection was made
            server.DisplayMessage("Player " + number + " connected\r\n",false);

            // Send the current player's number to the client
            writer.Write(number);

            writer.Write("Player " + number + " connected, please wait.\r\n");

            // Player 1 must wait for player 2 to arrive
            if (number == 0)
            {
                writer.Write("Waiting for another player.\r\n");

                // Wait for the notification from the server that another player has connected
                lock (this)
                {
                    while (threadSuspended)
                        Monitor.Wait(this);
                }// End lock

                writer.Write("Other player connected. Your move.\r\n");
            } // end if

            // Play game
            while (!done)
            {
                // Wait for the data to become available
                while (connection.Available == 0)
                {
                    Thread.Sleep(1000);

                    if (server.disconnected)
                        return;
                }// End while

                // receive data
                int location = reader.ReadInt32();
                int allStones = reader.ReadInt32();
                int kalaha0Stones = reader.ReadInt32();
                int kalaha1Stones = reader.ReadInt32();
                bool forfeit = reader.ReadBoolean();
                string message = reader.ReadString();

                // If a player requested a new game
                if (message == "New game")
                {
                    endOfGame = false; // Start a new game
                    writer.Write("New game request approved.");
                    server.DisplayMessage("Player " +number+ " requested a new game \r\n", true); // display message
                    server.SetNewGame(number);
                }

                else
                {
                    // if the game is over, set done to true to exit while loop
                    if (server.GameOver(kalaha0Stones, kalaha1Stones, forfeit))
                    {
                        server.DisplayMessage("Waiting for a new game ...\r\n", false);
                        endOfGame = true;
                    }

                    // If the move is valid, display the move on the server, and signal that the move is valid
                    if (server.ValidMove(location, number, allStones, endOfGame))
                    {
                        server.DisplayMessage("Player " + number + " moved.\r\n", false);
                        writer.Write("Valid move.");
                        writer.Write(server.FullRotation(allStones, location));
                        writer.Write(endOfGame);
                    }// End if

                    else // The move is invalid
                    {
                        writer.Write("Invalid move, try again.");
                        writer.Write(endOfGame);
                    }
                    endOfGame = false;
                }

            }// End while loop

            // Close the socket connection
            writer.Close();
            reader.Close();
            socketStream.Close();
            connection.Close();

        } // End Method Run

    }// End Class Player
}// End namespace MancalaOnline