/*File: MancalaBoard.cs
  This class contains objects for the Mancala game
 ----------------------------------------------------------------------
  Class: CS 390								Instructor: Dr. Deborah Hwang
  Software Project					     	Date assigned: October 07, 2008 
  Programmer: David Houngninou				Date completed: December 11, 2008 */

using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace MancalaOnline
{
    [Serializable]
    public class Pit // Class defining a pit on the Mancala board
    {
        private PictureBox picturebox; //GUI Picture box of the stones
        private Point location; // location of the pit
        private int numberOfStones; // Number of stones in the pit

        // Constructor
        public Pit(PictureBox newPictureBox, Point newlocation, int newNumberOfStones)
        {
            picturebox = newPictureBox;
            location = newlocation;
            numberOfStones = newNumberOfStones;
        } // End Constructor

        // Property accessors

        public PictureBox PitBox
        { get { return picturebox; } } // end property PitBox

        public int NumberOfStones
        {
            get { return numberOfStones; }
            set { numberOfStones = value; }
        } // end property NumberOfStones

    }  // end class Pit
}
