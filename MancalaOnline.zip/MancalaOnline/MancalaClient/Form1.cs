/*File: MancalaClient.cs
  This class maintains the clients (Players) for the Mancala game
 ----------------------------------------------------------------------
  Class: CS 390								Instructor: Dr. Deborah Hwang
  Software Project					     	Date assigned: October 07, 2008 
  Programmer: David Houngninou				Date completed: December 11, 2008 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.IO;

namespace MancalaOnline
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private Thread outputThread; // Thread for receiving data from the server
        private TcpClient connection; // client to establish connection
        private NetworkStream stream;  // Declare a network stream
        private BinaryWriter writer; // facilitates writing to the stream
        private BinaryReader reader; // facilitates reading from the stream
        private bool myTurn; // Player's turn
        private int myNumber; // Player's number
        private bool done = false; // True when game is over

        private int cxClient;       // form client width     
        private int cyClient;       // form client height
        private int boxX;         // panel width
        private int boxY;         // panel height
        int row1Position = 14; // Position of the pit
        int row2Position = 0; // Position of the pit
        int currentRow = 0, currentCol = 0, clickedLocation = 0; // Current location on the clicked pit
        bool gameOver = true, playersReady = false;

        private Pit[,] board = new Pit[2, 8]; // Board containing the 14 pits

        private void Form1_Load(object sender, EventArgs e)
        {
            cxClient = this.ClientSize.Width;
            cyClient = this.ClientSize.Height - 90;
            boxX = cxClient / 8;
            boxY = cyClient / 2;
            int row, col;

            for (row = 0; row < 2; row++)
                for (col = 0; col < 8; col++)
                {
                    string pitName;

                    // Assign names to the pits
                    if (row == 0)
                    {
                        pitName = row1Position.ToString();  // Name the pit 
                        row1Position--;
                    }
                    else
                    {
                        if (col == 7)
                            pitName = "box7";  // Name the pit 
                        else
                            pitName = row2Position.ToString();  // Name the pit 

                        row2Position++;
                    }

                    Point newLocation = new Point(col * boxX, (row * boxY) + 24); // Location of the Pit
                    PictureBox newPictureBox = new PictureBox(); // Picture representing a pit
                    newPictureBox.Name = pitName; // Name assigned to a pit
                    newPictureBox.Location = newLocation; // Location assigend to a pit
                    newPictureBox.SizeMode = PictureBoxSizeMode.StretchImage; // Stretch the picture in the box
                    int newNumberOfStones = 0; // Number of stones in a pit

                    if ((col == 0 && row == 0) || (col == 7 && row == 0)) // The 02 large Kalaha pits
                    {
                        newPictureBox.Width = boxX;
                        newPictureBox.Height = cyClient;
                        newPictureBox.Image = pictureFile("kalaha", 0);
                        newNumberOfStones = 0; // Initial number of stones
                    }

                    else // The 12 other small pits
                    {
                        newPictureBox.Width = boxX;
                        newPictureBox.Height = boxY;
                        newPictureBox.Image = pictureFile("pit", 3);
                        newNumberOfStones = 3; // Initial number of stones
                    }

                    // define the empty board
                    board[row, col] = new Pit(newPictureBox, newLocation, newNumberOfStones);
                    this.Controls.Add(board[row, col].PitBox);
                    board[row, col].PitBox.MouseUp += new MouseEventHandler(PitBox_MouseUp);
                }

            PaintSquares(); // Paint graphics
        } // End Form1_Load

        // Handler to close the server window
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            done = true;
            System.Environment.Exit(System.Environment.ExitCode);
        } // End Form1_FormClosing

        // Delegate that allows method DisplayMessage to be called
        // In the thread that maintains the GUI
        private delegate void DisplayDelegate(string message, bool clear);

        //Set text property
        internal void DisplayMessage(string message, bool clear)
        {
            //If not thread safe
            if (GameMessage.InvokeRequired)
            {
                Invoke(new DisplayDelegate(DisplayMessage), new object[] { message, clear });
            }
            else
            {
                if (clear == false)
                    GameMessage.Text += message; // Write message to text box
                else
                    GameMessage.Text = message; // Clear the message box first
            }
        } // End DisplayMessage

        //delegate that allows method CahngeIdLabel to be called
        // In the thread that maintains the GUI
        private delegate void ChangeIdLabelDelegate(string label);
        //Set label property
        internal void ChangeIdLabel(string label)
        {
            //If not thread safe
            if (idLabel.InvokeRequired)
            {
                Invoke(new ChangeIdLabelDelegate(ChangeIdLabel), new object[] { label });
            }
            else
                idLabel.Text = label;
        } // End ChangeIdLabel

        void PitBox_MouseUp(object sender, MouseEventArgs e) // Mouse click action
        {
            for (int row = 0; row < 2; row++)
                for (int col = 0; col < 8; col++)
                {
                    if (board[row, col].PitBox == sender) // Find the pit that was clicked on
                    {
                        if ((!gameOver) && (playersReady))
                        {
                            PictureBox currentBox = (PictureBox)sender; // Pit that was clicked on
                            clickedLocation = Convert.ToInt32(currentBox.Name); // Get the location of the clicked pit
                            currentRow = row; currentCol = col;
                            int kalaha0Stones = board[0, 7].NumberOfStones;
                            int kalaha1Stones = board[0, 0].NumberOfStones;
                            // Send the move to the server
                            SendClickedPit(clickedLocation, board[row, col].NumberOfStones, kalaha0Stones, kalaha1Stones, "Current Game");
                        }
                    }
                }
        } // End PitBox_MouseUp

        public bool checkForfeit() // Check if a player is short of stones
        {
            bool side1 = true, side2 = true;
            for (int col = 1; col < 7; col++)
                if (board[0, col].NumberOfStones != 0)
                    side2 = false;

            for (int col = 1; col < 7; col++)
                if (board[1, col].NumberOfStones != 0)
                    side1 = false;

            if (side1 == true || side2 == true)
                return true;
            else
                return false;
        }// End checkForfeit()

        public void PaintSquares() // Paint Graphics on the window
        {
            Graphics g;
            try
            {
                for (int row = 0; row < 2; row++)
                    for (int col = 0; col < 8; col++)
                    {
                        g = board[row, col].PitBox.CreateGraphics(); // get graphics for each Panel
                        g.Dispose(); // dispose of graphics object since we are done with it for now
                    }
            }
            catch (ObjectDisposedException)
            {
                MessageBox.Show("The game has been interrupted", "Mancala client", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }  // end PaintSquares

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            PaintSquares();
        }

        // Control thread that allows continuous update of the TextBox display
        public void Run()
        {
            myNumber = reader.ReadInt32(); // First identify the player
            ChangeIdLabel("You are player " + myNumber);
            myTurn = (myNumber == 0 ? true : false);

            try // Process incoming messages
            {
                while (!done) // Receive messages sent to client
                    ProcessMessage(reader.ReadString());
            }
            catch (IOException)
            {
                MessageBox.Show("Game over, The Mancala server is currently inactive", "Mancala server", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        } // End method Run

        public Bitmap pictureFile(string pitType, int number) // Create a bitmap image
        {
            string fileName;

            if (pitType == "pit")
                fileName = "c:/Mancala Files/stones" + number + ".jpg";
            else
                fileName = "c:/Mancala Files/kalaha" + number + ".jpg";

            Bitmap bmp = new Bitmap(fileName);
            return bmp;
        } // End PictureFile

        public void DisplayScores() // Display the players score and write them to a file
        {
            string winMessage = "Win", lostMessage = "Lost";
            gameOver = true;
            MessageBox.Show("Game over", "Player: Game Over!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            if (board[0, 7].NumberOfStones >= board[0, 0].NumberOfStones)
            {
                winMessage = "Player 0 won with " + board[0, 7].NumberOfStones + " stones!\r\n";
                lostMessage = "Player 1 lost with " + board[0, 0].NumberOfStones + " stones!\r\n";
            }
            else
            {
                winMessage = "Player 1 won with " + board[0, 0].NumberOfStones + " stones!\r\n";
                lostMessage = "Player 0 lost with " + board[0, 7].NumberOfStones + " stones!\r\n";
            }

            DisplayMessage(winMessage, false);
            DisplayMessage(lostMessage, false);

            StreamWriter scoreWriter = new StreamWriter("C:/Mancala Files/scores.txt", true);
            StreamWriter RecentScoreWriter = new StreamWriter("C:/Mancala Files/recentScore.txt", false);
            scoreWriter.WriteLine(winMessage); // Write scores to the scores file
            scoreWriter.WriteLine(lostMessage);
            scoreWriter.WriteLine("--------------");
            scoreWriter.Close();
            RecentScoreWriter.WriteLine(winMessage); // Write scores to the scores file
            RecentScoreWriter.WriteLine(lostMessage);
            RecentScoreWriter.WriteLine("--------------");
            RecentScoreWriter.Close();
        } // end DisplayScores()

        public void ResetGame() // Reset the board for a new game
        {
            gameOver = false; // Allow to restart the game
            for (int row = 0; row < 2; row++)
                for (int col = 0; col < 8; col++)
                {
                    if ((row == 0 && col == 0) || (row == 0 && col == 7)) // Empty the Kalahas
                    {
                        board[row, col].NumberOfStones = 0;
                        board[row, col].PitBox.Image = pictureFile("kalaha", board[row, col].NumberOfStones);
                    }
                    else
                    {
                        board[row, col].NumberOfStones = 3; // Fill all pits with 3 stones
                        board[row, col].PitBox.Image = pictureFile("pit", board[row, col].NumberOfStones);
                    }
                }
            PaintSquares(); // Draw the game board
        } // End ResetGame

        // Process messages sent from the server
        public void ProcessMessage(string message)
        {
            // If the move sent by the player is valid, update the display and fill the pits
            if (message == "Valid move.")
            {
                bool fullRotation = reader.ReadBoolean();
                bool endGame = reader.ReadBoolean();

                if (!endGame) // The Game is not over
                {
                    if (fullRotation) // Player made a full rotation in the board
                        DisplayMessage("Valid full rotation move, please wait. \r\n", false);
                    else
                        DisplayMessage("Valid move, please wait. \r\n", false);

                    int playerStones = board[currentRow, currentCol].NumberOfStones;
                    DistributeStones(playerStones, currentRow, currentCol, fullRotation, "player"); // Distribute the stones in the pits
                    PaintSquares();
                }
                else
                    DisplayScores(); // Game over
            }

            else if (message == "Invalid move, try again.")
            {
                bool endGame = reader.ReadBoolean();
                if (!endGame)
                {
                    // Display the move is invalid and let the player try again
                    DisplayMessage(message + "\r\n", false);
                    myTurn = true;
                }
                else
                    DisplayScores(); // Game over
            }// end else if

            else if (message == "Opponent moved.")
            {
                playersReady = true;
                // If opponent moved, find location of the move
                int location = reader.ReadInt32();
                int opponentStones = reader.ReadInt32();
                bool fullRotation = reader.ReadBoolean();
                bool endGame = reader.ReadBoolean();

                if (!endGame)
                {
                    int transRow = 0, transCol = 0; // Translate the location into coordinates

                    // Translate the location into coordinates
                    if ((location >= 1) && (location <= 6))
                    {
                        transRow = 1; transCol = location;
                    }
                    else
                    {
                        transRow = 0; transCol = 14 - location;
                    }

                    DistributeStones(opponentStones, transRow, transCol, fullRotation, "opponent"); // Distribute the stones in the pits
                    PaintSquares(); // Repaint the board
                    DisplayMessage("Opponent moved. Your turn.\r\n", false);

                    myTurn = true;  // It is now this player's turn
                }

                else
                {
                    DisplayScores(); // Game over
                    DisplayMessage("You win ! You can request a new game.\r\n", false);
                    myTurn = true;
                }
            }

            else if (message == "Other player connected. Your move.\r\n") // Wait for both players to join the game
            {
                playersReady = true; // Both Players have now joined the game
                DisplayMessage(message + "\r\n", false); // display message
            }
            else if (message == "Opponent requested new game.")
            {
                ResetGame(); // Reset the board for a new game
                DisplayMessage(message + " Your turn.\r\n", true); // display message
                myTurn = true;
            }
            else if (message == "New game request approved.")
            {
                DisplayMessage(message + " Please wait.\r\n", true); // display message
                ResetGame(); // Reset the board for a new game
            }

            else
                DisplayMessage(message + "\r\n", false); // display message
        } // End ProcessMessage

        // Distribute the stones in the pits
        public void DistributeStones(int numStones, int row, int col, bool rotation, string who)
        {
            board[row, col].NumberOfStones = 0; // Empty the pit

            if ((col == 0 && row == 0) || (col == 7 && row == 0))
                board[row, col].PitBox.Image = pictureFile("kalaha", board[row, col].NumberOfStones);
            else
                board[row, col].PitBox.Image = pictureFile("pit", board[row, col].NumberOfStones);

            for (int i = 0; i < numStones; i++) // Fill the adjacent pits counterclockwise
            {
                if (col < 6 && row == 1)
                {
                    col++; // Jump to the next adjacent pit (Forward move)
                    board[row, col].NumberOfStones++; // Add one stone to that pit
                    board[row, col].PitBox.Image = pictureFile("pit", board[row, col].NumberOfStones);
                }
                else if (col == 6 && row == 1) // Right Kalaha Pit
                {
                    col++; // Jump to the next adjacent pit (Forward move)
                    row--;
                    board[row, col].NumberOfStones++; // Add one stone to that pit
                    board[row, col].PitBox.Image = pictureFile("kalaha", board[row, col].NumberOfStones);
                }
                else if (col > 1 && row == 0)
                {
                    col--; // Jump to the next adjacent pit (Backward move)
                    board[row, col].NumberOfStones++; // Add one stone to that pit
                    board[row, col].PitBox.Image = pictureFile("pit", board[row, col].NumberOfStones);
                }
                else if (col == 1 && row == 0) // Left Kalaha Pit
                {
                    col--;
                    board[row, col].NumberOfStones++; // Add one stone to that pit
                    board[row, col].PitBox.Image = pictureFile("kalaha", board[row, col].NumberOfStones);
                }

                else if (col == 0 && row == 0) // Left Kalaha Pit
                {
                    col++;
                    row++;
                    board[row, col].NumberOfStones++; // Add one stone to that pit
                    board[row, col].PitBox.Image = pictureFile("pit", board[row, col].NumberOfStones);
                }
            }

            int lastDropRow = row, lastDropColumn = col;

            if (rotation == true) // A valid move with full rotation
            {
                if (board[lastDropRow, lastDropColumn].NumberOfStones == 1) // Rotation ends in player's empty pit
                {
                    if (who == "player")
                        DisplayMessage("Nice move! You got some stones. \r\n", false);
                    else if (who == "opponent")
                        DisplayMessage("Your opponent got your stones! \r\n", false);

                    int caughtStones = 1 + board[(lastDropRow + 1) % 2, lastDropColumn].NumberOfStones; // Get Opponents stones
                    board[lastDropRow, lastDropColumn].NumberOfStones = 0;
                    board[lastDropRow, lastDropColumn].PitBox.Image = pictureFile("pit", board[lastDropRow, lastDropColumn].NumberOfStones);
                    board[(lastDropRow + 1) % 2, lastDropColumn].NumberOfStones = 0;
                    board[(lastDropRow + 1) % 2, lastDropColumn].PitBox.Image = pictureFile("pit", board[(lastDropRow + 1) % 2, lastDropColumn].NumberOfStones);

                    if (lastDropRow == 0) // Add stones to the player's kalaha
                    {
                        board[0, 0].NumberOfStones = board[0, 0].NumberOfStones + caughtStones;
                        board[0, 0].PitBox.Image = pictureFile("kalaha", board[0, 0].NumberOfStones);
                    }
                    else if (lastDropRow == 1) // Add stones to the players kalaha
                    {
                        board[0, 7].NumberOfStones = board[0, 7].NumberOfStones + caughtStones;
                        board[0, 7].PitBox.Image = pictureFile("kalaha", board[0, 7].NumberOfStones);
                    }
                }
            }
        } // End DistributeStones

        // Sends the number of the clicked pit to the server
        public void SendClickedPit(int location, int pickedStones, int kalaha0Stones, int kalaha1Stones, string message)
        {
            // If it is the current player's move
            if (myTurn)
            {
                try
                {
                    writer.Write(location);// Send the location of the move to the server
                    writer.Write(pickedStones);// Send the number of stones to the server
                    writer.Write(kalaha0Stones);// Number of stones in player 1's Kalaha
                    writer.Write(kalaha1Stones);// Number of stones in player 2's Kalaha
                    writer.Write(checkForfeit());// In case a player is short of stones
                    writer.Write(message);// If a player requests a new game
                    myTurn = false;  // It is now the opponents turn
                }
                catch (IOException)
                {
                    MessageBox.Show("Game over, The Mancala server is currently inactive", "Mancala server", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            } // end if
        } // end method SendClickedPit

        private void userManualToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Display the user manual
            UserManual manual = new UserManual();
            manual.ShowDialog(this);
        }

        private void scoresRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Scores scoreWindow = new Scores();
            StreamReader scoreReader = new StreamReader("c:/Mancala Files/scores.txt");
            // Read scores from scores.txt file and display them in a window
            string read = null;
            while ((read = scoreReader.ReadLine()) != null)
            {
                scoreWindow.scoresTextBox.Text += read + "\r\n";
            }
            scoreReader.Close();
            // Display the score form 
            scoreWindow.ShowDialog(this);
        }

        private void quitToolStripMenuItem_Click(object sender, EventArgs e) // Close the window Form 1;
        {
            this.Close();
        }

        private void aboutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            // Display the About form 
            About aboutPage = new About();
            aboutPage.ShowDialog(this);
        }

        private void currentScoreToolStripMenuItem_Click(object sender, EventArgs e) // Display scores
        {
            Scores scoreWindow = new Scores();
            StreamReader scoreReader = new StreamReader("c:/Mancala Files/recentScore.txt");
            // Read scores from scores.txt file and display them in a window
            string read = null;
            while ((read = scoreReader.ReadLine()) != null)
            {
                scoreWindow.scoresTextBox.Text += read + "\r\n";
            }
            scoreReader.Close();
            // Display the score form 
            scoreWindow.ShowDialog(this);
        }

        private void IPButton_Click(object sender, EventArgs e)
        {
            string clientIP = IPtextBox.Text;
            try
            {
                // Make connection to the server and get the network stream
                connection = new TcpClient(clientIP, 9999);
                stream = connection.GetStream();
                writer = new BinaryWriter(stream);
                reader = new BinaryReader(stream);
                gameOver = false; // Start the game

                // Start a new thread for sending and receiving messages
                outputThread = new Thread(new ThreadStart(Run));
                outputThread.Start();
                IPButton.Enabled = false;
                IPtextBox.Enabled = false;
            }
            catch (SocketException)
            {
                MessageBox.Show("The IP address is incorrect", "Mancala client IP", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (playersReady)
                SendClickedPit(0, 0, 0, 0, "New game"); // Send a message to the server requesting a new game
        }

    } // End class Form1
}// End namespace MancalaOnline