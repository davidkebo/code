namespace MancalaOnline
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.commandsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.quitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.scoresRecordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.currentScoreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userManualToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.aboutToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.CommandPanel = new System.Windows.Forms.Panel();
            this.IPButton = new System.Windows.Forms.Button();
            this.IPtextBox = new System.Windows.Forms.TextBox();
            this.GameMessage = new System.Windows.Forms.TextBox();
            this.idLabel = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.CommandPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackgroundImage = global::MancalaClient.Properties.Resources.CommandWood;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.commandsToolStripMenuItem,
            this.helpToolStripMenuItem,
            this.aboutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(592, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // commandsToolStripMenuItem
            // 
            this.commandsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.toolStripSeparator1,
            this.quitToolStripMenuItem});
            this.commandsToolStripMenuItem.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.commandsToolStripMenuItem.Image = global::MancalaClient.Properties.Resources.glossymarbles;
            this.commandsToolStripMenuItem.Name = "commandsToolStripMenuItem";
            this.commandsToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.commandsToolStripMenuItem.Text = "Game";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Image = global::MancalaClient.Properties.Resources.glossymarbles;
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.newToolStripMenuItem.Text = "New";
            this.newToolStripMenuItem.Click += new System.EventHandler(this.newToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(149, 6);
            // 
            // quitToolStripMenuItem
            // 
            this.quitToolStripMenuItem.Name = "quitToolStripMenuItem";
            this.quitToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.quitToolStripMenuItem.Text = "Quit";
            this.quitToolStripMenuItem.Click += new System.EventHandler(this.quitToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.scoresRecordToolStripMenuItem,
            this.currentScoreToolStripMenuItem});
            this.helpToolStripMenuItem.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.helpToolStripMenuItem.Image = global::MancalaClient.Properties.Resources.MancalaBackground;
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(78, 20);
            this.helpToolStripMenuItem.Text = "Scores";
            // 
            // scoresRecordToolStripMenuItem
            // 
            this.scoresRecordToolStripMenuItem.Image = global::MancalaClient.Properties.Resources.MancalaBackground;
            this.scoresRecordToolStripMenuItem.Name = "scoresRecordToolStripMenuItem";
            this.scoresRecordToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.scoresRecordToolStripMenuItem.Text = "Scores record";
            this.scoresRecordToolStripMenuItem.Click += new System.EventHandler(this.scoresRecordToolStripMenuItem_Click);
            // 
            // currentScoreToolStripMenuItem
            // 
            this.currentScoreToolStripMenuItem.Image = global::MancalaClient.Properties.Resources.mancalaBoard;
            this.currentScoreToolStripMenuItem.Name = "currentScoreToolStripMenuItem";
            this.currentScoreToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.currentScoreToolStripMenuItem.Text = "Recent score";
            this.currentScoreToolStripMenuItem.Click += new System.EventHandler(this.currentScoreToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.userManualToolStripMenuItem,
            this.toolStripSeparator2,
            this.aboutToolStripMenuItem1});
            this.aboutToolStripMenuItem.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aboutToolStripMenuItem.Image = global::MancalaClient.Properties.Resources.manualbook;
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(64, 20);
            this.aboutToolStripMenuItem.Text = "Help";
            // 
            // userManualToolStripMenuItem
            // 
            this.userManualToolStripMenuItem.Image = global::MancalaClient.Properties.Resources.manualbook;
            this.userManualToolStripMenuItem.Name = "userManualToolStripMenuItem";
            this.userManualToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.userManualToolStripMenuItem.Text = "User Manual";
            this.userManualToolStripMenuItem.Click += new System.EventHandler(this.userManualToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(199, 6);
            // 
            // aboutToolStripMenuItem1
            // 
            this.aboutToolStripMenuItem1.Name = "aboutToolStripMenuItem1";
            this.aboutToolStripMenuItem1.Size = new System.Drawing.Size(202, 22);
            this.aboutToolStripMenuItem1.Text = "About Mancala ...";
            this.aboutToolStripMenuItem1.Click += new System.EventHandler(this.aboutToolStripMenuItem1_Click);
            // 
            // CommandPanel
            // 
            this.CommandPanel.BackgroundImage = global::MancalaClient.Properties.Resources.CommandWood;
            this.CommandPanel.Controls.Add(this.IPButton);
            this.CommandPanel.Controls.Add(this.IPtextBox);
            this.CommandPanel.Controls.Add(this.GameMessage);
            this.CommandPanel.Controls.Add(this.idLabel);
            this.CommandPanel.Cursor = System.Windows.Forms.Cursors.Default;
            this.CommandPanel.Location = new System.Drawing.Point(0, 223);
            this.CommandPanel.Name = "CommandPanel";
            this.CommandPanel.Size = new System.Drawing.Size(592, 67);
            this.CommandPanel.TabIndex = 1;
            // 
            // IPButton
            // 
            this.IPButton.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IPButton.Location = new System.Drawing.Point(524, 0);
            this.IPButton.Name = "IPButton";
            this.IPButton.Size = new System.Drawing.Size(68, 20);
            this.IPButton.TabIndex = 5;
            this.IPButton.Text = "Start";
            this.IPButton.UseVisualStyleBackColor = true;
            this.IPButton.Click += new System.EventHandler(this.IPButton_Click);
            // 
            // IPtextBox
            // 
            this.IPtextBox.BackColor = System.Drawing.Color.LemonChiffon;
            this.IPtextBox.Location = new System.Drawing.Point(390, 0);
            this.IPtextBox.Name = "IPtextBox";
            this.IPtextBox.Size = new System.Drawing.Size(134, 20);
            this.IPtextBox.TabIndex = 4;
            this.IPtextBox.Text = "192.168.1.100";
            this.IPtextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GameMessage
            // 
            this.GameMessage.BackColor = System.Drawing.Color.LemonChiffon;
            this.GameMessage.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.GameMessage.Cursor = System.Windows.Forms.Cursors.Default;
            this.GameMessage.Font = new System.Drawing.Font("Courier New", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GameMessage.ForeColor = System.Drawing.Color.Chocolate;
            this.GameMessage.Location = new System.Drawing.Point(0, 0);
            this.GameMessage.Multiline = true;
            this.GameMessage.Name = "GameMessage";
            this.GameMessage.ReadOnly = true;
            this.GameMessage.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.GameMessage.Size = new System.Drawing.Size(384, 67);
            this.GameMessage.TabIndex = 2;
            // 
            // idLabel
            // 
            this.idLabel.AutoSize = true;
            this.idLabel.BackColor = System.Drawing.Color.LemonChiffon;
            this.idLabel.Font = new System.Drawing.Font("Courier New", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idLabel.ForeColor = System.Drawing.Color.Chocolate;
            this.idLabel.Location = new System.Drawing.Point(473, 48);
            this.idLabel.Name = "idLabel";
            this.idLabel.Size = new System.Drawing.Size(78, 16);
            this.idLabel.TabIndex = 1;
            this.idLabel.Text = "Player ...";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(592, 290);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.CommandPanel);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.MaximumSize = new System.Drawing.Size(600, 324);
            this.MinimumSize = new System.Drawing.Size(600, 324);
            this.Name = "Form1";
            this.Text = "Mancala Client By Houngninou";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.CommandPanel.ResumeLayout(false);
            this.CommandPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel CommandPanel;
        private System.Windows.Forms.Label idLabel;
        private System.Windows.Forms.TextBox GameMessage;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem commandsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem quitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem scoresRecordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem userManualToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem currentScoreToolStripMenuItem;
        private System.Windows.Forms.Button IPButton;
        private System.Windows.Forms.TextBox IPtextBox;
    }
}

