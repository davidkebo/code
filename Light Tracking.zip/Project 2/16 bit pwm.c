/* This project designs a microcontroller system that will sweep 
a photo sensor mounted on top of a digital proportional 
servo motor through approximately 180 degrees and indicate 
the angle of the brightest light and the angle of the dimmest light one.
------------------------------------------------------------------
Class: EE454                     Instructor: Professor Mitchell
Programming project 2	           
Programmer: David Houngninou      Date completed: April 01, 2008 */

extern void Display_Text(unsigned char, unsigned char, unsigned char message[]);
extern void Display_Number(unsigned char, unsigned char, unsigned long int);
extern void initialize_pca();
unsigned int pwm_bit_high_time = 1000;	// Initialize zero position to zero
unsigned int currentAngle = 0;	 // Current sweeping angle
unsigned int BrightestAngle = 0;  // Angle with brightest light
unsigned int DimmestAngle = 0;	   // Angle with dimmest light
unsigned int HighestVoltage = 0;   // Highest light intensity
unsigned int SmallestVoltage = 0;	// Lowest light intensity

extern unsigned char Analog_Data(unsigned char);

// FUNCTIONS PROTOTYPES
void Delay (); // Time delays
void Reset ();  // Reset servo to initial position and reset variables

void main()
{
	unsigned int i;
	initialize_pca();

	while(1)
	{  
		Reset (); // Reset servo to initial position

		for (i = 0; i <20 ; i ++)
		{
			currentAngle = currentAngle + 9; // Angle increments
			pwm_bit_high_time = pwm_bit_high_time + 200; // Servomotor position increment

			if (Analog_Data(3)> HighestVoltage)	 // Get the greatest light intensity
		 {
			 HighestVoltage = Analog_Data(3);
			 BrightestAngle = currentAngle;
		 }

			else if (Analog_Data(3)< SmallestVoltage)  // Get the Lowest light intensity
		 {
			 SmallestVoltage = Analog_Data(3);
			 DimmestAngle = currentAngle;
		 }

			Delay (); // Time delay	 
		}
	
		// DISPLAY HIGHEST VOLTAGE	
		Display_Text(1, 0, "HIGHEST V:\0");
		Display_Number(1, 10, HighestVoltage);

		// DISPLAY LOWEST VOLTAGE	
		Display_Text(2, 0, "LOWEST V:\0");
		Display_Number(2, 10, SmallestVoltage);

		// DISPLAY ANGLE OF BRIGHTEST LIGHT	
		Display_Text(3, 0, "BRIGHTEST:\0");
		Display_Number(3, 10, BrightestAngle);

		// DISPLAY ANGLE OF DIMMEST LIGHT	
		Display_Text(4, 0, "DIMMEST:\0");
		Display_Number(4, 10, DimmestAngle);
	}	
}

void Delay ()	 // TIME DELAY
{  
	unsigned long int t;
	for (t=0;t<50000;t++);
}

void Reset () // Reset servo to initial position and reset variables
{  
	unsigned long int r;
	for (r=0;r<200000;r++);
	pwm_bit_high_time = 1000;
	currentAngle = 0;
	BrightestAngle = 0;
	DimmestAngle = 0;
	HighestVoltage = Analog_Data(3);
	SmallestVoltage = Analog_Data(3);
}
