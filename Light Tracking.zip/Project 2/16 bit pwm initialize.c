#include<at89c51xd2.h>
#include <stdio.h>
#include <string.h>

extern void LcDelay(unsigned int);
extern void LcDisplay ( unsigned int, unsigned char);

void initialize_pca()
{
/**********************************************************************/
  /*****************  LCD Initialization Module  ************************/
  /**********************************************************************/
  LcDelay(1000);
  LcDisplay(0xA000, 0x38);  //function set 8-bits
  LcDelay(5);
  LcDisplay(0xA000, 0x0C);  //display on
  LcDelay(5);
  LcDisplay(0xA000, 0x01);  // display clear
  LcDelay(50);
  LcDisplay(0xA000, 0x06);  // auto-increment pointer no shift
  LcDelay(1);


  CMOD = 0x00;
  CCAPM0 = 0x49;
  IEN0 = IEN0 | 0xC0;
  
  CR = 1;
}