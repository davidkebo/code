#include <89c51rd2.h>
#include <stdio.h>
#include <string.h>



/**********************************************************************/
 /*****************                             ************************/
 /*****************      LCD Delay module       ************************/
 /*****************                             ************************/
 /**********************************************************************/
 
 void LcDelay(unsigned int DelayTime)
 {
    unsigned int TimeTic;
    unsigned char Tock;
 
    for (TimeTic=0;TimeTic < DelayTime;TimeTic++)
    {
       for(Tock=0;Tock<40;Tock++);
    }
 }

/**********************************************************************/
 /*****************                             ************************/
 /*****************      LCD Driver module      ************************/
 /*****************                             ************************/
 /**********************************************************************/

 void LcDisplay ( unsigned int LcAddress, unsigned char LcData)

 {   
    unsigned char xdata *Lcd;
    
    Lcd = LcAddress;
    *Lcd = LcData;
 }


  /**********************************************************************/
  /*****************                             ************************/
  /*****************        Display Module       ************************/
  /*****************                             ************************/
  /**********************************************************************/

 
void Display_Text(unsigned char line_number,  unsigned char starting_position, unsigned char text_message[])
{
   
   unsigned char index, length;
   LcDelay(1);
   switch (line_number)
   {
     case 1:
       LcDisplay(0XA000, 0X80 + starting_position);
     break;
          
     case 2:
       LcDisplay(0XA000, 0XC0 + starting_position);
     break;

     case 3:
       LcDisplay(0XA000, 0X94 + starting_position);
     break;
     
     case 4:
       LcDisplay(0XA000, 0XD4 + starting_position);
     break;
   }  // end switch         
   
   length = strlen (text_message);
   
   for(index = 0; (index < length) && (index < 20 - starting_position); index++)
   {
     LcDelay(1);
     LcDisplay(0XB000, text_message[index]);
     LcDelay(1);
     
   }
     
}  // end Display_Text

void Display_Number(unsigned char line_number,  unsigned char starting_position, unsigned long int number)
{
   
   unsigned char index;
   unsigned long int j; //needs to be long int
   LcDelay(1);
   switch (line_number)
   {
     case 1:
       LcDisplay(0XA000, 0X80 + starting_position);
     break;
          
     case 2:
       LcDisplay(0XA000, 0XC0 + starting_position);
     break;

     case 3:
       LcDisplay(0XA000, 0X94 + starting_position);
     break;
     
     case 4:
       LcDisplay(0XA000, 0XD4 + starting_position);
     break;
   }  // end switch         
   
    j = 1000000000; //added 
    for (index = 0; index < 10; index++)
    {
      LcDelay(1);
      LcDisplay(0xB000,(unsigned char)((number % (10*j))/(j)) | 0X30);
      j = j/10;
      LcDelay(1);
    }
     
}  // end Display_Text

