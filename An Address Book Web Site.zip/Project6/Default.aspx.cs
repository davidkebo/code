/* EE 356 PROJECT 6 : TEAMX (David Houngninou, Anant Patel, and Mark Randall.)
   December 10, 2007
 */
using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.Common;
using System.Data.OleDb;
using System.IO;

public partial class _Default : System.Web.UI.Page
{
    // declarations section for database access
    string dataprovider;          // to store type of database we are using
    string sql;                 // sql string used as command
    string connectionstring;
    DbProviderFactory dbFactory;
    DbConnection dbConnection;
    DbCommand dbCommand;
    DbDataAdapter dbAdapter;
    DataSet dataSet;
    // end declarations section for database access

    protected void Page_Load(object sender, EventArgs e)
    {
        dataprovider = "System.Data.OleDb";           // for MS Access database

        connectionstring = string.Format("Provider={0};Data Source={1}",
                "Microsoft.Jet.OLEDB.4.0",
                @"|DataDirectory|\AddressBook.mdb");   // used VS Wizard to connect & store in app.config

        dbFactory = DbProviderFactories.GetFactory(dataprovider);
        dbConnection = dbFactory.CreateConnection();
        dbCommand = dbFactory.CreateCommand();
        dbAdapter = dbFactory.CreateDataAdapter();
        dataSet = new DataSet();
        // now link objects together
        dbCommand.Connection = dbConnection;
        dbAdapter.SelectCommand = dbCommand;

        // create sql command to fill dataset
        sql = "Select * From NameTable Order by LastName Asc, FirstName Asc;";

        dbConnection.ConnectionString = connectionstring;
        dbCommand.CommandText = sql;
        dbConnection.Open();
        dbAdapter.Fill(dataSet);
        dbConnection.Close();
    }

    // Drop-down list to find an entry by searching criteria
    protected void DropDownList1_SelectedIndexChanged1(object sender, EventArgs e)
    {
        EntriesList.Text = ""; // Empty the list of found entries
        Message.Text = "Instruction: First type in the field(s), then select the required action";
        string command = "";
        command = Convert.ToString(this.DropDownList1.SelectedValue);  // Get the command entered by the user

        if (command == "Find by ID") // If the search is made by ID #
        {
            int searched = -1;
            if (ID.Text != "") // If the ID field is not empty
            {
                try
                {
                    searched = Convert.ToInt32(ID.Text); // Get the selected criteria
                }
                catch (Exception ex) // Make sure the ID entered is an integer
                {
                    Message.Text = "Error: The ID field can take only an integer";
                }
                string[] FoundEntries = new string[60];  // Array of strings representing the entries found
                int EntryNumber = 0; // Index of entries found
                foreach (DataRow row in dataSet.Tables["Table"].Rows)   // "Table" is generic name
                {
                    if (row["ID"].Equals(searched)) // If the corresponding entry is found
                    {
                        // For each entry found, concatenate all its information in a single string 
                        FoundEntries[EntryNumber] = row["ID"].ToString() + " " + row["LastName"].ToString() + " "
                        + row["FirstName"].ToString() + " " + row["Email"].ToString();
                        EntryNumber++;
                    }
                    else
                        Message.Text = "No corresponding entries found";
                }
                for (int i = 0; i < EntryNumber; i++)
                {
                    EntriesList.Text += FoundEntries[i] + "\n"; // Output the List of Found entries in the designated text box
                    Message.Text = EntryNumber + " corresponding entry(ies) found";
                }
            }
            else
                Message.Text = " No ID# was typed in";
        }

        if (command == "Find by last name") // If the search is made by last name
        {
            if (LastName.Text != "") // If the Last Name field is not empty
            {
                String searched = LastName.Text; // Get the selected criteria
                string[] FoundEntries = new string[60]; // Array of strings representing the entries found
                int EntryNumber = 0; // Index of entries found
                foreach (DataRow row in dataSet.Tables["Table"].Rows)   // "Table" is generic name
                {
                    if (row["LastName"].Equals(searched)) // If the corresponding entry is found
                    {
                        // For each entry found, concatenate all its information in a single string 
                        FoundEntries[EntryNumber] = row["ID"].ToString() + " " + row["LastName"].ToString() + " "
                        + row["FirstName"].ToString() + " " + row["Email"].ToString();
                        EntryNumber++;
                    }
                    else
                        Message.Text = "No corresponding entries found";
                }
                for (int i = 0; i < EntryNumber; i++)
                {
                    EntriesList.Text += FoundEntries[i] + "\n"; // Output the List of Found entries in the designated text box
                    Message.Text = EntryNumber + " corresponding entry(ies) found";
                }
            }
            else
                Message.Text = " No Last Name was typed in";
        }

        if (command == "Find by first name") // If the search is made by first name 
        {
            if (FirstName.Text != "") // If the First Name field is not empty
            {
                String searched = FirstName.Text; // Get the selected criteria
                string[] FoundEntries = new string[60]; // Array of strings representing the entries found
                int EntryNumber = 0; // Index of entries found
                foreach (DataRow row in dataSet.Tables["Table"].Rows)   // "Table" is generic name
                {
                    if (row["FirstName"].Equals(searched))  // If the corresponding entry is found
                    {
                        // For each entry found, concatenate all its information in a single string 
                        FoundEntries[EntryNumber] = row["ID"].ToString() + " " + row["LastName"].ToString() + " "
                        + row["FirstName"].ToString() + " " + row["Email"].ToString();
                        EntryNumber++;
                    }
                    else
                        Message.Text = "No corresponding entries found";
                }
                for (int i = 0; i < EntryNumber; i++)
                {
                    EntriesList.Text += FoundEntries[i] + "\n"; // Output the List of Found entries in the designated text box
                    Message.Text = EntryNumber + " corresponding entry(ies) found";
                }
            }
            else
                Message.Text = " No First Name was typed in";
        }

        if (command == "Find by email") // If the search is made by email address
        {
            if (Email.Text != "") // If the Email field is not empty
            {
                String searched = Email.Text; // Get the selected criteria
                string[] FoundEntries = new string[60]; // Array of strings representing the entries found
                int EntryNumber = 0; // Index of entries found
                foreach (DataRow row in dataSet.Tables["Table"].Rows)   // "Table" is generic name
                {
                    if (row["Email"].Equals(searched)) // If the corresponding entry is found
                    {
                        // For each entry found, concatenate all its information in a single string 
                        FoundEntries[EntryNumber] = row["ID"].ToString() + " " + row["LastName"].ToString() + " "
                        + row["FirstName"].ToString() + " " + row["Email"].ToString();
                        EntryNumber++;
                    }
                    else
                        Message.Text = "No corresponding entries found";
                }
                for (int i = 0; i < EntryNumber; i++)
                {
                    EntriesList.Text += FoundEntries[i] + "\n"; // Output the List of Found entries in the designated text box
                    Message.Text = EntryNumber + " corresponding entry(ies) found";
                }
            }
            else
                Message.Text = " No email address was typed in";
        }
        EmptyFields(); // Empty the entries fields
        DropDownList1.ClearSelection(); // Clear the Drop down List
    } // End DropDownList1_SelectedIndexChanged1


    protected void UpdateEntry_Click1(object sender, EventArgs e) // Update an entry in the database
    {
        Message.Text = "Instruction: First type in the field(s), then select the required action";
        if (CheckFilled()) // Check if all the required fields are filled
        {
            try
            {
                if (AlreadyExist(ID.Text)) // Make sure the entry exists in the database
                {
                    this.Validate();
                    dataSet.AcceptChanges();
                    using (dbConnection = dbFactory.CreateConnection())
                    {
                        dbCommand = dbFactory.CreateCommand();
                        dbCommand.Connection = dbConnection;
                        string sql = string.Format("Update NameTable Set LastName = '{0}',FirstName = '{1}', Email= '{2}' Where ID = {3};",
                            LastName.Text, FirstName.Text, Email.Text, ID.Text); // Update an entry referring to its ID#
                        dbConnection.ConnectionString = connectionstring;
                        dbCommand.CommandText = sql;
                        dbConnection.Open();
                        int result = dbCommand.ExecuteNonQuery();  // return # records modified
                        if (result != 1)
                            throw new System.ApplicationException("Query ran, but failed");
                        else
                        {
                            Message.Text = "The entry with ID " + ID.Text + " has been successfully updated";
                            EmptyFields(); // Empty the entries fields
                            EntriesList.Text = "";// Clears the list of entries
                        }

                    } // end using
                }
                else
                    Message.Text = "Error: The entry you are trying to Update is not in the database";
            }
            catch (Exception ex) // Make sure the ID entered is an integer
            {
                Message.Text = "Error: The ID field can take only an integer";
            }
        }
        else
            Message.Text = "Error : Please type in all the required information";
    } // End UpdateEntry_Click

    protected void AddEntry_Click(object sender, EventArgs e) // Add an entry to the database
    {
        Message.Text = "Instruction: First type in the field(s), then select the required action";
        if (CheckFilled()) //Check if all the required fields are filled    
        {
            try
            {
                if (AlreadyExist(ID.Text) == false)// Make sure the entry is not already in the database
                {
                    this.Validate();
                    dataSet.AcceptChanges();
                    using (dbConnection = dbFactory.CreateConnection())
                    {
                        dbCommand = dbFactory.CreateCommand();
                        dbCommand.Connection = dbConnection;
                        // Insert a new entry in the database
                        string sql = string.Format("Insert Into NameTable (ID,LastName,FirstName,Email) Values ({0}, '{1}', '{2}', '{3}');",
                            ID.Text, LastName.Text, FirstName.Text, Email.Text);
                        dbConnection.ConnectionString = connectionstring;
                        dbCommand.CommandText = sql;
                        dbConnection.Open();
                        int result = dbCommand.ExecuteNonQuery();  // return # records modified
                        if (result != 1)
                            throw new System.ApplicationException("Query ran, but failed");
                        else
                        {
                            Message.Text = "The entry with ID " + ID.Text + " has been successfully added";
                            EmptyFields(); // Empty the entries fields
                            EntriesList.Text = ""; // Clears the list of entries
                        }
                    } // end using
                }
                else
                    Message.Text = "Error: The entry you are trying to Add is already in the database, or this ID is already assigned";
            }
            catch (Exception ex) // Make sure the ID entered is an integer
            {
                Message.Text = "Error: The ID field can take only an integer";
            }
        }
        else
            Message.Text = "Error: Please type in all the required information";
    } // End AddEntry_Click


    // Drop-down list to remove an entry by criteria
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        Message.Text = "Instruction: First type in the field(s), then select the required action";
        EntriesList.Text = ""; // Empty the list of found entries
        string command = "";
        // Get the command entered by the user
        command = Convert.ToString(this.DropDownList2.SelectedValue);

        if (command == "Remove by ID") // If removing is made by ID #
        {
            if (ID.Text != "") // If the ID field is not empty
            {
                try
                {
                    if (AlreadyExist(ID.Text)) // Make sure the entry exists in the database                   
                    {
                        this.Validate();
                        dataSet.AcceptChanges();
                        using (dbConnection = dbFactory.CreateConnection())
                        {
                            dbCommand = dbFactory.CreateCommand();
                            dbCommand.Connection = dbConnection;
                            string sql = string.Format("Delete From NameTable Where ID = {0};", ID.Text); // Delete entry referring to the ID
                            dbConnection.ConnectionString = connectionstring;
                            dbCommand.CommandText = sql;
                            dbConnection.Open();
                            int result = dbCommand.ExecuteNonQuery();  // return # records modified
                            if (result != 1)
                                throw new System.ApplicationException("Query ran, but failed");
                            else
                            {
                                Message.Text = "The entry with ID " + ID.Text + " has been successfully Removed";
                                EmptyFields(); // Empty the entries fields
                                EntriesList.Text = ""; // Clears the list of entries
                            }
                        } // end using
                    }
                    else
                        Message.Text = "Error: The entry you are trying to Remove is not in the database";
                }
                catch (Exception ex) // Make sure the ID entered is an integer
                {
                    Message.Text = "Error: The ID field can take only an integer";
                }
            }
            else
                Message.Text = " Error: No ID# was typed in";
        }

        if (command == "Remove by email") // If removing is made by email address
        {
            if (Email.Text != "") // If the Email field is not empty
            {
                if (AlreadyExistAddress(Email.Text) == false) // Make sure the entry exists in the database
                    Message.Text = "Error: The entry you are trying to Remove is not in the database";
                else
                {
                    this.Validate();
                    dataSet.AcceptChanges();
                    using (dbConnection = dbFactory.CreateConnection())
                    {
                        dbCommand = dbFactory.CreateCommand();
                        dbCommand.Connection = dbConnection;
                        string sql = string.Format("Delete From NameTable Where Email = '{0}';", Email.Text);
                        dbConnection.ConnectionString = connectionstring;
                        dbCommand.CommandText = sql;
                        dbConnection.Open();
                        int result = dbCommand.ExecuteNonQuery();  // return # records modified
                        if (result != 1)
                            throw new System.ApplicationException("Query ran, but failed");
                        else
                        {
                            Message.Text = "The entry with an email address " + Email.Text + " has been successfully Removed ";
                            EntriesList.Text = ""; // Delete entry referring to the email address
                        }
                    } // end using
                }
            }
            else
                Message.Text = " Error: No email address was typed in";
        }


        if (command == "Remove by First & Last Name") // If removing is made by  First and Last name
        {
            if (LastName.Text != "" && FirstName.Text != "") // If the First and Last Name fields are not empty
            {
                if (AlreadyExistName(FirstName.Text, LastName.Text) == false) // Make sure the entry exists in the database
                    Message.Text = "Error: The entry you are trying to Remove is not in the database";
                else
                {
                    this.Validate();
                    dataSet.AcceptChanges();
                    using (dbConnection = dbFactory.CreateConnection())
                    {
                        dbCommand = dbFactory.CreateCommand();
                        dbCommand.Connection = dbConnection;
                        string sql = string.Format("Delete From NameTable Where LastName = '{0}' And FirstName = '{1}';",
                            LastName.Text, FirstName.Text); // Delete entry referring to the first and last name
                        dbConnection.ConnectionString = connectionstring;
                        dbCommand.CommandText = sql;
                        dbConnection.Open();
                        int result = dbCommand.ExecuteNonQuery();  // return # records modified
                        if (result != 1)
                            throw new System.ApplicationException("Query ran, but failed");
                        else
                        {
                            Message.Text = FirstName.Text + " " + LastName.Text + " has been successfully Removed from the database";
                            EntriesList.Text = "";
                        }
                    } // end using
                }
            }
            else
                Message.Text = " Error: Both the first name and the last name need to be typed in";
        }
        EmptyFields(); // Empty the entries fields
        DropDownList2.ClearSelection(); // Clear the Drop down List
    } // End DropDownList2_SelectedIndexChanged


    bool AlreadyExist(string anID)
    {
        bool check = false;
        foreach (DataRow row in dataSet.Tables["Table"].Rows)
        {
            if (row["ID"].Equals(Convert.ToInt32(anID))) // If a user with that ID is detected
                check = true;
        }
        return check;
    } // End AlreadyExist

    bool AlreadyExistAddress(string anAddress)
    {
        bool check = false;
        foreach (DataRow row in dataSet.Tables["Table"].Rows)
        {
            if (row["Email"].Equals(anAddress)) // If a user with that Email address is detected
                check = true;
        }
        return check;
    } // End AlreadyExistAddress

    bool AlreadyExistName(string aFirstName, string aLastName)
    {
        bool check = false;
        foreach (DataRow row in dataSet.Tables["Table"].Rows)
        {
            if ((row["FirstName"].Equals(aFirstName)) && (row["LastName"].Equals(aLastName)))// If a user with that Name is detected
                check = true;
        }
        return check;
    } // End AlreadyExistName

    bool CheckFilled()
    {
        if ((ID.Text == "") || (LastName.Text == "") || (FirstName.Text == "") || (Email.Text == ""))
            return false; // One of the required field is empty
        else
            return true;
    } // End CheckFilled

    protected void ClearList_Click(object sender, EventArgs e)
    {
        Message.Text = "Instruction: First type in the field(s), then select the required action";
        EntriesList.Text = "";
    } // End ClearList_Click

    protected void ClearFields_Click(object sender, EventArgs e)
    {
        Message.Text = "Instruction: First type in the field(s), then select the required action";
        EmptyFields();
    } // End ClearFields_Click 

    void EmptyFields()
    {
        ID.Text = "";
        LastName.Text = "";
        FirstName.Text = "";
        Email.Text = "";
    } // End EmptyFields

}  // End public partial class _Default 
