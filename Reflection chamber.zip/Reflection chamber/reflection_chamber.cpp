/* File:reflection_chamber.cpp
   This simulation trcaes the path of a single tiny pinball as it bounces 
   of various walls and contains three convex pillars.
   ----------------------------------------------------------------
   Class: CS 355			 Instructor: Dr. Morse
   Assignment: Case Study 4.4		 Date assigned: September 16, 2008 
   Programmer: David Houngninou		 Date completed: October 02, 2008 */

#include <GL/glut.h>
#include <iostream>
#include <fstream>
#include <stdio.h>
#include <cstdlib>
#include <cmath>

#define screenHeight 700
#define screenWidth 700

using namespace std;

int numberOfPolygons = 0, click = 1;
bool userAbort = false;
char filename [80]; // Name of the input file

void myInit() // Initialize various values in the graphics pipeline
{
  glClearColor(1.0, 1.0, 1.0, 1.0);      // choose background color (White)
  glColor3f(1.0,0.0,0.0);   // set the drawing color (Red)
  glPointSize(2.0);                   // set points size
  glMatrixMode(GL_PROJECTION);        // load matrix mode
  glLoadIdentity();                   // load identity matrix
  gluOrtho2D(0.0, 700.0, 0.0, 700.0); // defines a 2D orthographic projection
  glViewport (0,0,700, 700);
}

struct vectorL // Structure that holds a vector
{
  double x,y;
};

struct GLintPoint // Structure that holds a points with integer coordinates
{
  GLint x,y;
};

struct segment // Structure that holds a line segment
{
  GLintPoint startingPoint;
  GLintPoint endPoint;
  vectorL directionVector; // Direction vector: End point - Starting point
  vectorL normalVector; // Normal vector	
};
segment hitWall; // A wall that is hit by an incident ray
segment ray, incidentRay; 
vectorL unitNormalVector, unitIncidentVector; // Normalized vectors
double normalMagnitude = 0, rayMagnitude = 0; // Magnitudes

struct pillar // Structure that holds the list of bounding lines of each polygon
{
  int numberOfSides;
  segment* segmentList;
  GLintPoint* points;
  float colorParam1, colorParam2, colorParam3;
};

pillar* polygonsList; //Dynamic Array containing all the pillars

void drawPolyline( pillar polygon ) // Draws a polygon
{
  glColor3f(polygon.colorParam1,polygon.colorParam2,polygon.colorParam3);//Set the drawing color
  glBegin(GL_POLYGON); //Polygon
  glPolygonMode( GL_FRONT, GL_FILL ); //Fill the polygon with color
  
  for(int i = 0; i < polygon.numberOfSides; i++) // Draw the vertices
    glVertex2i(polygon.points[i].x, polygon.points[i].y);
  
  glEnd(); glFlush();
}

void drawDot( GLint x, GLint y) // Draws a dot on the screen 
{	
  glColor3f(0.0,0.0,0.0); // Drawing color (Black)  
  glPointSize(1.0);      // set points size
  glBegin(GL_POINTS);
  glVertex2i(x,y); // Draw the points
  glEnd();
}

void drawPath(GLintPoint start, GLintPoint end) // Draws a path from start to end point 
{	
  glColor3f(0.0,0.0,1.0); // Drawing color (Blue)  
  glBegin(GL_LINES);
  glVertex2i(start.x, start.y);
  glVertex2i(end.x, end.y);
  glEnd();
}

double dotProduct(vectorL vect1, vectorL vect2) // Calculates the dot product of two vectors
{
  return ((vect1.x * vect2.x)+(vect1.y * vect2.y));
}

// Find the intersection of a ray and a segment
int findHitPoint(segment& raySegment, pillar polygonList[])
{ 
  double numeratorU, denominatorU, numeratorT, denominatorT; // used to find hit time
  double timeU = 0.0, timeT = 0.0, hitTime = 0.0, smallestHitTime = -10; 
  vectorL tempVector;
  
  for(int i = 0; i < numberOfPolygons; i++) // Go through each polygon
    {
      for(int j = 0; j < polygonList[i].numberOfSides; j++) // Go through each polygon's vertice
	{	  
	  tempVector.x = raySegment.startingPoint.x - polygonList[i].segmentList[j].startingPoint.x; 
	  tempVector.y = raySegment.startingPoint.y - polygonList[i].segmentList[j].startingPoint.y;
	  
	  numeratorU =  - dotProduct(polygonList[i].segmentList[j].normalVector, tempVector);	  
	  denominatorU = dotProduct(polygonList[i].segmentList[j].normalVector, raySegment.directionVector);
	  
	  numeratorT= dotProduct(raySegment.normalVector, tempVector);	  
	  denominatorT = dotProduct(raySegment.normalVector, polygonList[i].segmentList[j].directionVector);
	  
	  if (denominatorU != 0.0) // If the ray and the vertice are not parallel 
	    {
	      //Calculate time u 
	      timeU = numeratorU / denominatorU;
	      //Calculate time t 
	      timeT = numeratorT / denominatorT; 
	      
	      // Intersection with a segment
	      if ((timeU >=0)&&(timeT >=0)&&(timeT <= 1))
		{
		  // If the ray is entering
		  if (dotProduct (polygonList[i].segmentList[j].normalVector, raySegment.directionVector)< 0.0)
		    { 	  
		      hitTime = timeU; 
		      
		      if ((hitTime <= smallestHitTime)||(smallestHitTime == -10))// Get the smallest hit time
			{
			  smallestHitTime = hitTime;
			  // Get the first hit wall
			  hitWall.normalVector.x = polygonList[i].segmentList[j].normalVector.x;
			  hitWall.normalVector.y = polygonList[i].segmentList[j].normalVector.y;
			}
		    }
		}
	    }
	}
    }
  // Calculate the ray's end point
  raySegment.endPoint.x  = raySegment.startingPoint.x + (raySegment.directionVector.x * smallestHitTime);
  raySegment.endPoint.y  = raySegment.startingPoint.y + (raySegment.directionVector.y * smallestHitTime);
}

// Read the list of pillars from an external file 
void getPillars ()
{
  ifstream file ( filename , ifstream::in ); // File
  
  int vertices = 0; // Number of vertices
  bool end = false;
  
  if(!file) // Check for file validity
    cout << "\nError While opening the pillars list file\n" << endl;
  else
    cout << "Pillars list file successfully opened" << endl;
  
  file >> numberOfPolygons;// Numbers of Polygons (chamber + pillars)
  polygonsList = new pillar[numberOfPolygons]; // Dynamic array of polygons
  
  while ((!file.eof()) && (end == false)) // Scan the file
    {
      for (int i=0; i< numberOfPolygons; i++) // For each polygon defined in the file
	{ 
	  file >> vertices; // Number of vertices for each polygon
	  
	  polygonsList[i].numberOfSides = vertices; // Number of sides for the polygon
	  polygonsList[i].segmentList = new segment[vertices]; // List of vertices for each polygon
	  polygonsList[i].points  = new GLintPoint[vertices]; // Array of vertices
	  
	  // Get the color parameters of each polygon
	  file >> polygonsList[i].colorParam1 >> polygonsList[i].colorParam2 >>  polygonsList[i].colorParam3;
	  
	  for (int j=0; j<vertices; j++)// Get the points for each vertices 
	    file >> polygonsList[i].points[j].x >> polygonsList[i].points[j].y; // x and y for the point
	  
	  for (int j=0; j<vertices; j++)// Define all the segments' start and end points
	    {
	      if(j == (vertices - 1)) // We are back to the first point
		{
		  polygonsList[i].segmentList[j].startingPoint =  polygonsList[i].points[j];
		  polygonsList[i].segmentList[j].endPoint =  polygonsList[i].points[0];
		} 
	      else // The next point becomes the starting point for the vertice
		{
		  polygonsList[i].segmentList[j].startingPoint =  polygonsList[i].points[j];
		  polygonsList[i].segmentList[j].endPoint =  polygonsList[i].points[j+1];
		} 
	    }
	  
	  for (int j=0; j<vertices; j++) // Define the normal and direction vectors for each segment
	    {
	      polygonsList[i].segmentList[j].directionVector.x = polygonsList[i].segmentList[j].endPoint.x - polygonsList[i].segmentList[j].startingPoint.x;
	      polygonsList[i].segmentList[j].directionVector.y = polygonsList[i].segmentList[j].endPoint.y - polygonsList[i].segmentList[j].startingPoint.y;
	      
	      if (i==0)// Chamber polygon: Normal vectors point inside 
		{
		  polygonsList[i].segmentList[j].normalVector.x = - polygonsList[i].segmentList[j].directionVector.y;
		  polygonsList[i].segmentList[j].normalVector.y = polygonsList[i].segmentList[j].directionVector.x;
		}
	      else // Pillar polygon: Normal vectors point outside  
		{
		  polygonsList[i].segmentList[j].normalVector.x = polygonsList[i].segmentList[j].directionVector.y;
		  polygonsList[i].segmentList[j].normalVector.y = - polygonsList[i].segmentList[j].directionVector.x;
		}
	    }
	}
      end = true; // end of the data in the file
    }
}

void display_chamber()// Chamber & pillars display function
{
  myInit(); // GL initialization routine
  glClear(GL_COLOR_BUFFER_BIT);    // clear the screen
  
  getPillars ();// Get Data from the file
  
  // Draw pillars
  for (int i=0; i<numberOfPolygons; i++)
    drawPolyline(polygonsList[i]);
  
  glEnd(); glFlush();    
}

void reset() // Reset the chamber
{
  click = 1;
  numberOfPolygons = 0;
  userAbort = false;
  display_chamber(); // Reset Display 
}

void myMouse( int button, int state, int x, int y ) // Mouse click action
{ 
  if ( button == GLUT_LEFT_BUTTON && state == GLUT_DOWN )
    {
      if (click == 1) // First click to make the starting point
	{
	  ray.startingPoint.x = x;
	  ray.startingPoint.y = screenHeight-y;
	  drawDot(ray.startingPoint.x, ray.startingPoint.y); // Draws a dot on the screen
	}
      else if (click == 2) // Second click to make the direction
	{ 
	  ray.endPoint.x = x;
	  ray.endPoint.y = screenHeight-y;
	  drawDot(ray.endPoint.x, ray.endPoint.y); // Draws a dot on the screen
	  
	  // Starting ray's direction and normal vector
	  ray.directionVector.x = ray.endPoint.x - ray.startingPoint.x; 
          ray.directionVector.y = ray.endPoint.y - ray.startingPoint.y;  
	  ray.normalVector.x = - ray.directionVector.y; 
	  ray.normalVector.y = ray.directionVector.x; 
	  
	  while (userAbort == false) // Keep tracing until the user presses a key
	    {
	      usleep(1000000); // Delay
	      glFlush();
	      
	      findHitPoint(ray, polygonsList);// Find the first intersection
	      
	      // Draw the pinball path
	      drawPath(ray.startingPoint, ray.endPoint);
	      
	      // The previous ray becomes the incident ray
	      incidentRay.directionVector.x = ray.endPoint.x - ray.startingPoint.x; 
	      incidentRay.directionVector.y = ray.endPoint.y - ray.startingPoint.y;
	      
	      // Calculate the unit normal vector to the vertice hit
	      normalMagnitude = sqrt (pow(hitWall.normalVector.x,2)+ pow(hitWall.normalVector.y,2)); 
	      unitNormalVector.x = hitWall.normalVector.x / normalMagnitude;
	      unitNormalVector.y =  hitWall.normalVector.y / normalMagnitude;
	      
	      // Calculate the unit direction vector of the incident ray
	      rayMagnitude = sqrt (pow(incidentRay.directionVector.x,2)+ pow(incidentRay.directionVector.y,2)); 
	      unitIncidentVector.x =  incidentRay.directionVector.x / rayMagnitude;
	      unitIncidentVector.y =  incidentRay.directionVector.y / rayMagnitude;
	      
	      // New reflected ray's direction and normal vector 
	      ray.directionVector.x = unitIncidentVector.x - ( 2 * dotProduct(unitIncidentVector, unitNormalVector) * unitNormalVector.x );
	      ray.directionVector.y = unitIncidentVector.y - ( 2 * dotProduct(unitIncidentVector, unitNormalVector) * unitNormalVector.y );
	      
	      ray.normalVector.x = - ray.directionVector.y; 
	      ray.normalVector.y = ray.directionVector.x; 
	      
	      // Start the new reflected ray	      
	      ray.startingPoint = ray.endPoint;
	    }
	}
      click ++; // Increment the number of click
    }
}

void myKeyboard ( unsigned char key, int mouseX, int mouseY ) // Keyboard action
{
  switch( key ) // Switch on the user's input
    {
    case 'r':
      reset();  // Reset
      userAbort = true;
      break;
    case 'c':
      userAbort = true;	
      exit ( -1 ); // Close the window
    default :
      break;
    }  
}

int main(int argc, char ** argv) // Main 
{
  // Get the file name from user input
  printf("\nPlease enter the points file name: ");
  scanf("%s", filename); 
  
  // Windowing (GLUT) setup
  glutInit(&argc, argv);
  glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB); // Set Display mode
  glutInitWindowSize(screenHeight,screenWidth); // Set the window size
  glutInitWindowPosition(100,150); // Set the window position
  glutCreateWindow("Reflections in a chamber"); // Open the screen
  
  glutMouseFunc( myMouse ); // Register the mouse action 
  glutKeyboardFunc( myKeyboard ); // Register the keyboard action 
  glutDisplayFunc(display_chamber); // Register callback functions
  
  myInit(); // GL initialization routine
  glutMainLoop();// Display Picture and wait and handle callbacks  
  
  return 0; // should never get here
} 

