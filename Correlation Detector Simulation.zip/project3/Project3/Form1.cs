/*  Team Y:
Chris Campbell
David Houngninou
Mark Randall    */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;


namespace project3
{
    public partial class Form1 : Form
    {
        Pen penRed = new Pen(Color.Red);		// define red pen
        Pen penBlue = new Pen(Color.Blue);		// define blue pen
        Pen penBlack = new Pen(Color.Black);	// define black pen
        Pen penPink = new Pen(Color.HotPink);	// define pink pen
        int cx;		// integer variables to hold dimensions of client area
        int cy;		// in pixels
        int duration = 200; // Initial value for the number of cycles
        int inputamp = 100; // Initial value for the simulated transmitted pulse amplitude
        int noiseamp = 300; // Initial value for the noise amplitude
        int inputperiod = 20; // Initial value for the simulated transmitted pulse frequency
        int sigmav = 1;
        bool normal = true, gaussian = false; // Defines the type of noise noise model
        PointF[] ipt = new PointF[1000];			// array of points
        PointF[] npt = new PointF[1000];            // array of points
        static public PointF[] noise = new PointF[1000]; 
        int delay = 200;
        int[] noiseAmplitude = new int[1000];
        int step = 0;
        bool set = false;



        public Form1()
        {
            InitializeComponent();
        }


        // Panels size and size change handling
        protected override void OnResize(EventArgs e)
        {
            panel1.Location = new System.Drawing.Point((int)(this.ClientSize.Width * .273), (int)(this.ClientSize.Height * .038));
            panel2.Location = new System.Drawing.Point((int)(this.ClientSize.Width * .273), (int)(this.ClientSize.Height * .357));
            panel3.Location = new System.Drawing.Point((int)(this.ClientSize.Width * .273), (int)(this.ClientSize.Height * .655));
            this.Invalidate();	// force repaint of client area on size change
        }



        // Paints the panel containing the simulated transmitted pulse.
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

            Graphics grfx = e.Graphics;		// get graphics context
            panel1.Width = (int)(this.ClientSize.Width * .7);  // Defines the Width
            panel1.Height = (int)(this.ClientSize.Height * .25); // Defines the Height
            cx = this.panel1.Size.Width;
            cy = this.panel1.Size.Height;
            // move origin to center of client area
            grfx.TranslateTransform(0, (float)cy / 2);
            // define brush and color for text
            SolidBrush txtBrush = new SolidBrush(Color.Crimson);
            // Scale coordinates to convenient units & invert y
            grfx.ScaleTransform((float)cx / 1000, -(float)cy / 1000);
            grfx.DrawLine(penBlack, 0, 0, 1000, 0);		// x-axis
            grfx.DrawLine(penBlack, 0, 500, 0, -500);		// y-axis
            for (int i = 0; i < duration; i++)
            {
                ipt[i].X = (i);
                ipt[i].Y = inputamp * (float)(Math.Sin((2 * Math.PI * ipt[i].X) / inputperiod));// Equation of the transmitted pulse
            }
            for (int i = duration; i < 1000; i++)
            {
                ipt[i].X = i;
                ipt[i].Y = 0;
            }

            grfx.DrawLines(penRed, ipt);					// draw the curve through the points
        }


        // Paints the panel containing the pulse with added noise.
        private void panel2_Paint(object sender, PaintEventArgs e)
        {

            Graphics grfx = e.Graphics;		// get graphics context
            panel2.Width = (int)(this.ClientSize.Width * .7); // Defines the Width
            panel2.Height = (int)(this.ClientSize.Height * .25); // Defines the Height
            cx = this.panel2.Size.Width;
            cy = this.panel2.Size.Height;
            // move origin to center of client area
            grfx.TranslateTransform(0, (float)cy / 2);
            // define brush and color for text
            SolidBrush txtBrush = new SolidBrush(Color.Crimson);
            // Scale coordinates to convenient units & invert y
            grfx.ScaleTransform((float)cx / 1000, -(float)cy / 1000);
            grfx.DrawLine(penBlack, 0, 0, 1000, 0);		            // x-axis
            grfx.DrawLine(penBlack, 0, 500, 0, -500);		        // y-axis
            // calculate noise
            int i = 0;
            if (set != true)
            {
                Random rangen = new Random();
                
                if (normal)// Uniform noise model
                {
                    for (int n = 0; n < 1000; n++)
                    {
                        npt[n].X = (n);
                        noise[n].Y = (2 * Convert.ToSingle(rangen.NextDouble()) - 1);

                    }
                }
                if (gaussian) // Gaussian noise model
                {

                    double x1 = 0, x2 = 0, y1 = 0, y2 = 0, z1 = 0, z2 = 0;
                    for (int n = 0; n < 1000; n += 2)
                    {
                    x1 = Convert.ToSingle(rangen.NextDouble());
                    x2 = Convert.ToSingle(rangen.NextDouble());
                    y1 = (Math.Sqrt((-2) * Math.Log(x1))) * (Math.Cos(2 * Math.PI * x2));
                    y2 = (Math.Sqrt((-2) * Math.Log(x1))) * (Math.Sin(2 * Math.PI * x2));
                    z1 = y1 * (double)sigmav;
                    z2 = y2 * (double)sigmav;
                        npt[n].X = (n);
                        npt[n].Y = (float)z1;
                        npt[n + 1].Y = (float)z2;
                        noise[n].Y = npt[n].Y;
                        noise[n + 1].Y = npt[n + 1].Y;
                    }
                }
                set = true;

            }
            for (int n = 0; n < 1000; n++)
            {
                npt[n].X = (n);
                npt[n].Y = noiseamp * noise[n].Y;
                if (n >= delay && i < duration)
                {
                    npt[n].Y += ipt[i].Y;
                    i++;
                }
            }

            grfx.DrawLines(penPink, npt);					// draw the curve through the points

        }

        // Paints the panel containing the time correlation of the transmitted and received signals.
        private void panel3_Paint(object sender, PaintEventArgs e)
        {
            float temp = 0;
            int s = 0;
            Graphics grfx = e.Graphics;		// get graphics context
            panel3.Width = (int)(this.ClientSize.Width * .7); // Defines the Width
            panel3.Height = (int)(this.ClientSize.Height * .25); // Defines the Height
            cx = this.panel2.Size.Width;
            cy = this.panel2.Size.Height;
            // move origin to center of client area
            grfx.TranslateTransform(0, (float)cy / 2);
            // define brush and color for text
            SolidBrush txtBrush = new SolidBrush(Color.Crimson);
            // Scale coordinates to convenient units & invert y
            grfx.ScaleTransform((float)cx / 1000, -(float)cy / 1000);
            grfx.DrawLine(penBlack, 0, 0, 1000, 0);		            // x-axis
            grfx.DrawLine(penBlack, 0, 500, 0, -500);		        // y-axis
            // calculate noise
            PointF[] opt = new PointF[1000];			// array of points

            for (int k = 0; k <= 999; k++)
            {
                opt[k].X = k;
                for (int m = 0; m <= (999 - k); m++)
                {
                    temp += ((npt[k + m].Y) * (ipt[m].Y));
                }
                if (temp >= s)
                {
                    s = (int)temp;

                }
                if (temp <= -s)
                    s = (int)(-temp);
                opt[k].Y = temp;
            }
            s = s - 1;
            for (int k = 0; k < 999; k++)
            {
                opt[k].Y = (opt[k].Y / s) * 500;//(int)temp1 )* 500;
            }

            grfx.DrawLines(penRed, opt);					// draw the curve through the points
        }

        // Increases or decreases the number of cycles of the simulated transmitted pulse
        // Refreshes the panels containing each plot
        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            duration = (int)numericUpDown1.Value;
            numericUpDown5.Maximum = 1000 - duration;
            panel1.Refresh();
            panel2.Refresh();
            panel3.Refresh();

        }

        // Increases or decreases the amplitude of the simulated transmitted pulse
        // Refreshes the panels containing each plot
        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            inputamp = (int)numericUpDown2.Value;
            panel1.Refresh();
            panel2.Refresh();
            panel3.Refresh();
        }

        // Increases or decreases the frequency of the simulated transmitted pulse
        // Refreshes the panels containing each plot
        private void numericUpDown3_ValueChanged(object sender, EventArgs e)
        {
            inputperiod = (int)numericUpDown3.Value;
            panel1.Refresh();
            panel2.Refresh();
            panel3.Refresh();
        }

        // Increases or decreases the noise amplitude of the added noise pulse
        // Refreshes the panels containing each plot
        private void numericUpDown4_ValueChanged(object sender, EventArgs e)
        {
            noiseamp = (int)numericUpDown4.Value;
            panel1.Refresh();
            panel2.Refresh();
            panel3.Refresh();
            noiseAmplitude[step] = noiseamp;
            step++;
        }

        // Increases or decreases the input delay of the added noise pulse
        // Refreshes the panels containing each plot
        private void numericUpDown5_ValueChanged_1(object sender, EventArgs e)
        {
            numericUpDown5.Maximum = 1000 - duration;
            delay = (int)numericUpDown5.Value;
            panel1.Refresh();
            panel2.Refresh();
            panel3.Refresh();
        }

        // Defines the amount of standard deviation for the added Gaussian noise pulse
        // Refreshes the panels containing each plot
        private void sigma_ValueChanged(object sender, EventArgs e)
        {
            set = false;
            sigmav = (int)sigma.Value;
            panel1.Refresh();
            panel2.Refresh();
            panel3.Refresh();

        }

        // ComboBox for the user to choose between a Uniform or Gaussian noise distribution
        // Refreshes the panels containing each plot
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Gaussian")
            {
                set = false;
                sigma.Visible = true;
                slabel.Visible = true;
                gaussian = true;
                normal = false;
                panel1.Refresh();
                panel2.Refresh();
                panel3.Refresh();

            }
            else
            {
                set = false;
                sigma.Visible = false;
                slabel.Visible = false;
                gaussian = false;
                normal = true;
                panel1.Refresh();
                panel2.Refresh();
                panel3.Refresh();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Invalidate();	// force repaint of client area on size change
        }

        // Displays the histogram of the noise samples in an independent window
        private void button1_Click(object sender, EventArgs e)
        {
            Histogram histogramForm = new Histogram();
            histogramForm.Show();
        }

    }
}