using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace project3
{
    public partial class Histogram : Form
    {
        public Histogram()
        {
            InitializeComponent();
        }

        Pen penRed = new Pen(Color.Red);		// define red pen
        Pen penBlue = new Pen(Color.Blue);		// define blue pen
        Pen penBlack = new Pen(Color.Black);	// define black pen
        Pen penPink = new Pen(Color.HotPink);	// define pink pen

        SolidBrush brushblue = new SolidBrush(Color.Blue);

        int cx;		// integer variables to hold dimensions of client area
        int cy;		// in pixel

        // Paints the panel containing the histogram of the noise samples to examine the noise sample distribution. 
        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            Graphics grfx = e.Graphics;		// get graphics context
            cx = this.panel1.Size.Width;
            cy = this.panel1.Size.Height;
            // move origin to center of client area
            grfx.TranslateTransform(0, cy);
            // define brush and color for text
            SolidBrush txtBrush = new SolidBrush(Color.Blue);
            // Scale coordinates to convenient units & invert y
            grfx.ScaleTransform((float)cx / 1000, -(float)cy / 1000);
            grfx.DrawLine(penBlue, 0, 0, 1000, 0);		// x-axis
            grfx.DrawLine(penBlue, 0, 0, 0, 1000);		// y-axis

            float max = 0;
            float min = 0;
            float width = 0;
            for (int i = 0; i < 1000; i++)
            {
                if (Form1.noise[i].Y < min) // Stores the smallest noise value in min
                    min = Form1.noise[i].Y;
                else if (Form1.noise[i].Y > max) // Stores the largest noise value in max
                    max = Form1.noise[i].Y;
            }
            width = max - min;

            float sectionw = width / 10; // Splits the width into that 10 distinct sections
            int[] section = new int[10];
            for (int t = 0; t < 10; t++)
            {
                section[t] = 0;
            }

            for (int i = 0; i < 10; i++)
            {
                for (int t = 0; t < 1000; t++)
                {
                    if ((Form1.noise[t].Y >= min) && (Form1.noise[t].Y < min + sectionw)) // Finds the range corresponding to each noise value
                        section[i] += 1; // Increase the amplitude of the section, for each value falling in that range
                }
                min += sectionw;
            }
            for (int t = 0; t < 10; t++)
            {
                grfx.FillRectangle(brushblue, t * 100, 0, 100, section[t]); // Fills the histogram bands in blue

            }

        }

        private void Histogram_Load(object sender, EventArgs e)
        {
            this.Invalidate();	// force repaint of client area on size change
        }
        // Panels size and size change handling
        protected override void OnResize(EventArgs e)
        {
            this.Invalidate();	// force repaint of client area on size change
        }

    }

}
