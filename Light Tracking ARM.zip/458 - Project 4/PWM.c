#include<LPC213x.h>
#include<math.h>
#include <stdio.h>  

extern int ADConvert(void);
extern unsigned int val;

int main()
  {
   unsigned int t;
   unsigned int brightangle;
   unsigned int dimangle;
   unsigned int brightvoltage;
   unsigned int dimvoltage;
   unsigned int currangle;
   unsigned int currvoltage;
   int i;

   PINSEL0 |= 0x00020005; // Change GPIO P0.8 to PWM4 and enable RxD1 and TxD0
   IODIR0 |= 0x00000100;  // Set Direction of PWM4 Pin to be output
   VPBDIV =  0x00000000;  //Set up peripheral clock for 15MHz
   PWMPR = 0x00000004;    // Set Pre Scale to 0	 //divide by four
   PWMPCR = 0x00001000; // Enable PWM4 Output (bit12)

   PWMMR0 = 30000; // Makes the Period 10ms
   PWMMR4 = 24000;
   PWMMCR = 0x00000002; // Reset PWMMTC when Matched with PWMMR0
   PWMLER = 0x7F; // Latch in all PWMMMR's
   PWMTCR = 0x02; // Reset PWMMTC, (bit1)
   PWMTCR = 0x09; // Counter Enable, PWM Mode Enabled(bit0, bit3)

   U0LCR = 0x83;                   /* 8 bits, no Parity, 1 Stop bit            */
   U0DLL = 97;                     /* 9600 Baud Rate @ 15MHz VPB Clock         */
   U0LCR = 0x03;                   /* DLAB = 0                                 */
  
   printf ("Welcome to the ARM Servo Project\n");       /* the 'printf' function call               */
 
   brightangle = 999;
   dimangle = 999;
   brightvoltage = 00;
   dimvoltage = 999;
   currvoltage = 00;
   currangle = 00;

   printf ("Current Angle: %u \n", currangle); 
   printf ("Bright Voltage: %u \n", brightvoltage);
   printf ("Bright Angle: %u \n", brightangle);
   printf ("Dim Voltage: %u \n", dimvoltage);
   printf ("Dim Angle: %u \n", dimangle); 


  //My 180 degree angles has my high time going from 29000 to 24000
  
   while(1)
     {
    //Forward Loop
    for (i = 24000; i <= 29040; i+=28)
	{
	//Rotate the Servo
     PWMMR4 = i;
     PWMLER = 0x00000010;  //update the latch enable register
    
	 //Get the voltage
	 currvoltage = ADConvert();

	 for (t=0;t<100000;t++);

	 //Calculate the Angle
	 currangle++;


	//Set the parameters based on voltage	  
	if (currvoltage > brightvoltage)
	{
	 brightvoltage = currvoltage;
	 brightangle = currangle;
	}

	if (currvoltage < dimvoltage)
	{
	 dimvoltage = currvoltage;
	 dimangle = currangle;
	}
	}  

	for (t=0;t<1000000;t++);


	//Backward Loop
	 for (i = 29040; i >= 24000; i-=28)
	{
	//Rotate the Servo
	PWMMR4 = i;
	PWMLER = 0x00000010;  //update the latch enable register
	
	//Get the Voltage
 	currvoltage = ADConvert();
	 
    for (t=0;t<100000;t++);

	//Calculate the Angle
	currangle--;
	
	//Set the parameters based on voltage  
	if (currvoltage > brightvoltage)
	{
	 brightvoltage = currvoltage;
	 brightangle = currangle;
	}

	if (currvoltage < dimvoltage)
	{
	 dimvoltage = currvoltage;
	 dimangle = currangle;
	}


	}

   printf ("\n\nCurrent Angle: %u \n", currangle); 
   printf ("Bright Voltage: %u \n", brightvoltage);
   printf ("Bright Angle: %u \n", brightangle);
   printf ("Dim Voltage: %u \n", dimvoltage);
   printf ("Dim Angle: %u \n", dimangle);   
}
}

