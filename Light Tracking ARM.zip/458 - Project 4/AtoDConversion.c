
#include <LPC213X.H>
 
int ADConvert(void)
  {unsigned int val;

   //VPBDIV = 0x02;          //Set the Pclk to 30 Mhz
   PINSEL1 = 0x10000000;
   AD0CR  = 0x00200608; //Setup A/D:10-bit AIN0 @ 4.28MHz software controlled 
   AD0CR  |= 0x01000000;   // Start A/D Conversion 
   //PINSEL1 = 0x00480000;   // P0.25 set to DA Out, P0.27 set to input AD0.0
  
   val = AD0DR;                     // Read A/D Data Register         
      while ((val & 0x80000000) == 0)  //Wait for the conversion to complete
	     val = AD0DR; 
		 val = val & 0x0000FFFF;
		 val = val/64;               
		return val;
	  AD0CR |= 0x01000000;             //Restart A/D Converter
  }


