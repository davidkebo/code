/* File:ex3-2-2.cpp
   Practice exercice: 3.2.2 Whirling swirls
   ----------------------------------------------------------------
   Class: CS 375			 Instructor: Dr. Morse
   Assignment: Practice exercice 3.2.2   Date assigned: September 16, 2008 
   Programmer: David Houngninou		 Date completed: September 18, 2008 */

#include <GL/glut.h>
#include <iostream>
#include <fstream>
#include <stdio.h>
#include <cstdlib>
#include <cmath>
using namespace std;

// Set Window function
void setWindow (GLdouble left, GLdouble right, GLdouble bottom, GLdouble top)
{
  glMatrixMode (GL_PROJECTION);
  glLoadIdentity ();
  gluOrtho2D (left, right, bottom, top);
}

// SetViewport function
void setViewport (GLint left, GLint right, GLint bottom, GLint top)
{
  glViewport (left, bottom, right - left, top - bottom);
}

void hexSwirl() // Creates  whirling hexagons
{
  double increment = 5.0/100;         //the radius increment
  double radius = 5.0/100.0;          //the radius to be used
  double angle;                       //the angle of rotation
  double angleIncrement = 2*3.14159265/6.0; //the angle increment
  
  //Hexagon swirl
  for (int j = 0; j <= 100; j++)
    {
      //Angle of rotation
      angle = j* (3.14159265/180.0);
      
      //One Hexagon
      glBegin (GL_LINE_STRIP);
      for (int k=0; k <= 6; k++)
	{
	  angle += angleIncrement;
	  glVertex2d(radius * cos(angle), radius *sin(angle));	  
	}
      glEnd();
      
      //Radius of the next hexagon
      radius += increment;
    }
  glutSwapBuffers();  
  glFlush();
}

// Creates the tiled display
void myDisplay(void)
{
  // Clear the screen
  glClear (GL_COLOR_BUFFER_BIT);
  setWindow (-0.6, 0.6, -0.6, 0.6); // The portion of the swirl to draw
  
  for (int i =0; i<5; i++) // Make a pattern of 5 by 4 copies
    for (int j = 0; j<4; j++)
      {
	int L = 80; // the amount to translate each viewport
	if (i%2 == 0) // Regular window 
	  {
	    if (j%2 == 0)
	      setWindow (-0.6, 0.6, -0.6, 0.6);
	    else
	      setWindow (-0.6, 0.6, 0.6, -0.6);
	  }
	
	else // Window up side down
	  {
	    if (j%2 == 0)
	      setWindow (-0.6, 0.6, 0.6, -0.6);
	    else
	      setWindow (-0.6, 0.6, -0.6, 0.6);
	  }
	
	setViewport (i*L, L+i * L, j*L, L+j * L); // Next viewport 
	hexSwirl (); // Create  whirling hexagons
	usleep(100000); // Delay
      }  
}

// Structure that holds a point with integer coordinates
struct GLintPoint{
  GLint x,y;
};

// Initialize various values in the graphics pipeline
void myInit()
{
  glClearColor (1.0, 1.0, 1.0, 1.0);  //Set background color to white	
  glColor3f (1.0, 0.0, 0.0);      //Set foreground color to red
  glPointSize (3.0);         //Setpoint size
  glViewport (0.0, 0.0, 500.0, 500.0); //set viewport to be the entire window
  glMatrixMode (GL_PROJECTION);
  glLoadIdentity();
  gluOrtho2D(-5.0, 5.0, -5.0, 5.0);
  glMatrixMode (GL_MODELVIEW);  
}

// Mouse click action to created the tiled display
void myMouse( int button, int state, int x, int y )
{
  if ( button == GLUT_LEFT_BUTTON && state == GLUT_DOWN )
    myDisplay();      // Creates the tiled display
}

int main(int argc, char ** argv) // Main 
{
  // Windowing (GLUT) setup
  glutInit(&argc, argv);
  glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB); // Set Display mode
  glutInitWindowSize(500,500); // Set the window size
  glutInitWindowPosition(100,150); // Set the window position
  glutCreateWindow("Whirling swirls *** CLICK TO VIEW TILED DISPLAY ***"); // Open the screen
  
  glutMouseFunc(myMouse); // Register the mouse action 
  glutDisplayFunc(hexSwirl); // Register callback functions
  
  myInit(); // GL initialization routine
  glClear (GL_COLOR_BUFFER_BIT);
  glutMainLoop();// Display Picture and wait and handle callbacks 
  return 0; // should never get here
} 

