

#include <GL/glut.h>
#include <iostream>
#include <fstream>

using namespace std;

// Structure that holds a point with integer coordinates
//
struct GLintPoint{
    GLint x,y;
};

// random function
//
int random (int m){
    return rand() %m;
}

// drawDot - draws a dot on the screen given a integer
// x,y pixel coordinates
//
void drawDot( GLint x, GLint y){
    glBegin(GL_POINTS);
        glVertex2i(x,y);
    glEnd();
}

// myInit - initialize various values in the graphics pipeline
//
void myInit(){
    glClearColor(1.0,1.0,1.0,0.0);      // choose background color
    glColor3f(0.0f, 0.0f, 0.0f);        // set the drawing color
    glPointSize(2.0);                   // set point size
    glMatrixMode(GL_PROJECTION);        // load matrix mode
    glLoadIdentity();                   // load identity matrix
    gluOrtho2D(0.0, 800.0, 0.0, 600.0); // defines a 2D orthographic projection
}

// siepinski_render -- display function
//
void sierpinski_render(){

    glClear(GL_COLOR_BUFFER_BIT);    // clear the screen

    // defines the vertices of the triangle
    //
    GLintPoint T[3] = {{10,10},{600,10},{300,600}}; 

    // choose one vertex from the triangle randomly
    // and draw that point
    //
    int index = random(3);
    GLintPoint point = T[index];
    drawDot(point.x, point.y);

    // take random points from the vertices and 
    // draw dots from mid distance from them
    //
    for (int i=0; i < 10000; i++){
        index = random(3);
        point.x = (point.x + T[index].x)/2;
        point.y = (point.y + T[index].y)/2;
        drawDot(point.x,point.y);
    }
    glFlush();  
}

// main
int main(int argc, char ** argv){

    // Windowing (GLUT) setup
    //
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);
    glutInitWindowSize(800,600);
    glutInitWindowPosition(100,150);
    glutCreateWindow("The Sierpinski Window");

    // Register callback functions
    //
    glutDisplayFunc(sierpinski_render);

    // GL initialization routine
    //
    myInit();

    // Display Picture and wait and handle callbacks
    //
    glutMainLoop();

    return 0; // should never get here
}
