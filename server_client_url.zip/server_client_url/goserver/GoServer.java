import java.net.*;
import java.io.*;
import java.util.*;

/*
 * The worker thread connects to a url and counts
 * the number of characters from that url.
 */
class WorkerThread extends Thread {
	String input_url, inputLine;
	int charCount;

	// return the number of characters from a url
	public int getCharacters() {
		return charCount;
	}

	// return a url
	public String getUrl() {
		return input_url;
	}

	// constructor
	WorkerThread(String url) {
		this.input_url = url;
	}

	public void run() {
		try {
			// create a url object
			URL myURL = new URL(input_url);
			URLConnection myURLConnection = myURL.openConnection();
			myURLConnection.connect();

			BufferedReader in = new BufferedReader(new InputStreamReader(
					myURLConnection.getInputStream()));

			System.out.println("Processing: " + input_url + " ...");

			// count characters from the url
			while ((inputLine = in.readLine()) != null)
				charCount += inputLine.length();
			in.close();

		} catch (MalformedURLException e) { // new URL() failed
			System.err.println("Cannot connect to this URL, try again");
		} catch (IOException e) { // openConnection() failed
			System.err.println("Connection failure");
		}
	}
}

/*
 * The manager thread receives a socket from the server for each client
 * connection and spawns worker threads for client urls.
 */
class ManagerThread extends Thread {
	ServerSocket serverSocket = null;
	Socket clientSocket = null;
	String input_url, response;
	BufferedReader in = null;

	// constructor
	ManagerThread(Socket clientSocket) {
		this.clientSocket = clientSocket;
	}

	public void run() {
		try {
			in = new BufferedReader(new InputStreamReader(
					clientSocket.getInputStream()));

			// spawns a new worker thread for each url
			while ((input_url = in.readLine()) != null) {
				WorkerThread urlThread = new WorkerThread(input_url);
				urlThread.start();
				// Wait for the worker thread to complete
				urlThread.join();
				PrintWriter out = new PrintWriter(
						clientSocket.getOutputStream(), true);
				// make the result string
				response = urlThread.getUrl() + " " + urlThread.getCharacters()
						+ " characters";
				// send the result back to client
				out.println(response);
				System.out.println("Result for: " + input_url
						+ " sent to client");
			}
		} catch (Exception e) {
			System.err.println(e);
		}
	}
}

/*
 * The server accepts connections from multiple clients and spawns a manager
 * thread for each client
 */
public class GoServer {

	public static void main(String[] args) throws IOException {
		ServerSocket serverSocket = null;
		Socket clientSocket = null;

		try {
			serverSocket = new ServerSocket(6013);
			System.out.println("Connected ...");
		} catch (Exception e) {
			System.err.println(e);
		}

		// Listen for connections
		while (true) {
			// wait for new client connections
			clientSocket = serverSocket.accept();
			// Create a manager thread
			ManagerThread managerThread = new ManagerThread(clientSocket);
			// Run the manger thread
			managerThread.start();
		}
	}
}