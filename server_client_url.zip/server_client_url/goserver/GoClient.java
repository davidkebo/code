import java.net.*;
import java.io.*;
import java.util.Arrays;

public class GoClient {
	public static void main(String[] args) throws IOException {

	   	Socket echoSocket = null;
		PrintWriter out = null;
		BufferedReader in = null;
		String[] url_array = new String[60]; // Storage array for the urls
		String userInput, response;
		int url_count = 0;

		try {
			// make connection to server socket
			echoSocket = new Socket("127.0.0.1", 6013);
			out = new PrintWriter(echoSocket.getOutputStream(), true);
			in = new BufferedReader(new InputStreamReader(
					echoSocket.getInputStream()));
		} catch (IOException ioe) {
			System.err.println(ioe);
			System.exit(-1);
		}

		// standard input reader
		BufferedReader stdIn = new BufferedReader(new InputStreamReader(
				System.in));

		System.out.println("Enter URL or go: ");

		// read from standard input until user types "go"
		while ((userInput = stdIn.readLine()) != null) {

			if (!userInput.toLowerCase().equals("go")) {
				url_array[url_count] = userInput;
				url_count++;
			}
			// if user hits "go" from standard input
			else if (userInput.toLowerCase().equals("go")) {
				// Send the set of collected URLs to the server
				for (int i = 0; i < url_count; i++) {
					out.println(url_array[i]);
				}
				// Now listen for the server response
				for (int i = 0; i < url_count; i++) {
					response = in.readLine();
					System.out.println(response);
				}
				url_count = 0;
			}
			System.out.println("Enter a URL or go: ");
		}

		out.close();
		in.close();
		stdIn.close();
		echoSocket.close();
	}
}