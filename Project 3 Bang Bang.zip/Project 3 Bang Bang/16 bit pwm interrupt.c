#include<at89c51xd2.h>
#define pwm_period 10000*2
extern unsigned int pwm_bit_high_time;
sbit pwm_bit = 0x93;
void pwm_interrupt() interrupt 6 using 1
{
  unsigned int PCA_time;
  
  PCA_time = ((unsigned int)CCAP0H << 8) + (unsigned int)CCAP0L;  // Read the capture register
  
  pwm_bit = ~pwm_bit;	// change the state
  if(pwm_bit)
  {
    CCAP0L = (unsigned char)(pwm_bit_high_time + PCA_time);	  // Reload capture register with the current PCA time
    CCAP0H = (unsigned char)((pwm_bit_high_time + PCA_time) >> 8);
  }
  else
  {
    CCAP0L = (unsigned char)(pwm_period - pwm_bit_high_time + PCA_time);
    CCAP0H = (unsigned char)((pwm_period - pwm_bit_high_time + PCA_time) >> 8);
  }
  CCF0 = 0;
  
}