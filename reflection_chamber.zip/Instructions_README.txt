File:reflection_chamber.cpp
This simulation trcaes the path of a single tiny pinball as it bounces 
of various walls and contains three convex pillars.
----------------------------------------------------------------
Class: CS 355			 Instructor: Dr. Morse
Assignment: Case Study 4.4	 Date assigned: September 16, 2008 
Programmer: David Houngninou     Date completed: October 02, 2008 


The program takes a file of points as input and makes the reflection chamber.

Step 1: Type the filename at user input 
	(4 points files are provided: pillars1.txt, pillars2.txt, pillars3.txt, pillars4.txt)

Step 2: Click at a starting point in the chamber

Step 3: Click at an end point to define a direction

Notes:
* Press 'Ctrl-C' to close the window

