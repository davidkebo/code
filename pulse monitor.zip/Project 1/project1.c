extern void Display_Text(unsigned char, unsigned char, unsigned char message[]);
extern void Display_Number(unsigned char, unsigned char, unsigned long int);
extern void initialize (void);

unsigned long int frequency =0 ;
unsigned long int period = 0;
unsigned long int pulse_high_time = 0;
unsigned long int dutyCycle = 0;


void main ()  //Begin main
{
	initialize();

	while (1)
	{
		// DISPLAY PULSE PERIOD	
		Display_Text(1, 0, "PuS:\0");
		period = period /2;
		Display_Number(1, 6, period);

		// DISPLAY THE PULSE HIGH TIME
		Display_Text(2, 0, "H.T:\0");
		pulse_high_time = pulse_high_time/2;	
		Display_Number(2, 5, pulse_high_time);//  Filters the frequency measurement using a lowpass filter
		//  and displays the filtered frequency measurement.

		// DISPLAY PULSE FREQUENCY
		frequency = 2000000 / period;
		//frequency = filter(frequency);
		Display_Text(3, 0, "F(Hz):\0");	
		Display_Number(3, 8, frequency);//  Filters the frequency measurement using a lowpass filter
		//  and displays the filtered frequency measurement.

	// DISPLAY DUTY CYCLE
		dutyCycle = ((pulse_high_time *100)/ period) ;// place 100 8 in numerator
		Display_Text(4, 0, "DTY(%):\0");	
		Display_Number(4, 8, dutyCycle);//  Filters the frequency measurement using a lowpass filter
		//  and displays the filtered frequency measurement.

	}                         
}  //End main

