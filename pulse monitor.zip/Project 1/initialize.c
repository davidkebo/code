#include <at89c51xd2.h>
#include <stdio.h>
#include <string.h>

extern void LcDelay(unsigned int);
extern void LcDisplay ( unsigned int, unsigned char);
/*
    Partial code to initialize the PCA.  You will need to modify the code for rising and falling edge capture
    and you will also need to add initialization for the display.
*/

void Initialize()
{
   /**********************************************************************/
  /*****************  LCD Initialization Module  ************************/
  /**********************************************************************/
  LcDelay(1000);
  LcDisplay(0xA000, 0x38);  //function set 8-bits
  LcDelay(5);
  LcDisplay(0xA000, 0x0C);  //display on
  LcDelay(5);
  LcDisplay(0xA000, 0x01);  // display clear
  LcDelay(50);
  LcDisplay(0xA000, 0x06);  // auto-increment pointer no shift
  LcDelay(1);

 /**********************************************************************/
  /*****************  PCA Initialize		     ************************/
  /**********************************************************************/ 
  CMOD   = 0X01;         // put PCA in osc divide by 6 mode (clock period = 1/2 us with a 12MHz xtal) 
                         // and enable pca interrupt for overflow counting
  CCAPM4 = 0X31;         // put module 3 in risin and falling edge capture mode and enable interrrupt
  CCON   = 0X40;         // enable PCA clock source (PCA starts counting) 
  IEN0 = IEN0 | 0xC0;    // or in pca interrupts
   
}