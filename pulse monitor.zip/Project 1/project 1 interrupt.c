/*
    The interrupt code below will measure the time between falling edge to falling edge
    and rising edge to falling edge of pulses input on P1.6.
    The external variables pulse_high_time and period are global variables known
    to the main code. 
*/

#include<at89c51xd2.h>
extern unsigned long int pulse_high_time;
extern unsigned long int period;
sbit  input_bit = 0x97;
sbit check = 0xb5;

void PWMInterrupt(void) interrupt 6 using 2

{
   static unsigned int currentread;
   static unsigned int rising_edge_time;
   static unsigned int lastread;
   static unsigned char PCAoverflow;
   static unsigned char rising_edge_overflow;
   
   if (CF ==1)
   {
      CF = 0;
      PCAoverflow++;
   }
   else  // must be  a capture
   {
   check = ~check;
      currentread = (((unsigned int)CCAP4H)<<8) + CCAP4L;
      CCF4 = 0;
      
      if (input_bit)  // check for rising edge
      {
        rising_edge_time = currentread;
        rising_edge_overflow = PCAoverflow;
      }
      else  // must be falling edge
      {
        if (currentread < lastread)  //measure period
        {	
	  	    period = 65536*(unsigned long int)(PCAoverflow-1)+(unsigned long int)(currentread - lastread);
 	      }
	      else
	      {
          period = 65536*(unsigned long int)PCAoverflow+(unsigned long int)(currentread - lastread);
        }

        if (currentread < rising_edge_time)  //measure high time
        {	
	  	    pulse_high_time = 65536*(unsigned long int)(PCAoverflow-rising_edge_overflow-1)+(unsigned long int)(currentread - rising_edge_time);
 	      }
	      else
	      {
          pulse_high_time = 65536*(unsigned long int)(PCAoverflow-rising_edge_overflow)+(unsigned long int)(currentread - rising_edge_time);
        }

        lastread = currentread;
	      PCAoverflow=0;
        rising_edge_overflow = 0;
      }
           
   }
}
