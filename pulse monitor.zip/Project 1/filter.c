#include <at89c51xd2.h>
#define beta 15  //filter constant increase beta to move the cutoff frequency towards dc
unsigned long int filter (unsigned long int input)
{
  static unsigned long int output;
  output = (beta*output+input)/(beta+1);
  return (output);		//filter using average value filter
}
