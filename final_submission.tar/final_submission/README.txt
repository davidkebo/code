/* Filename: README.txt
Class: CSE 521S Wireless Sensor Networks
Team Members: Chirombe, Houngninou,  Lee
Assignment: Class Project
Date: Fall 2010 */

The project includes 3 Folders in the source_code folder.

Folder 1 contains the code for the Basestation:
The basestation is the mote that is physically connected to the server computer and receives command via serial from the server.
It forwards the user input to the control node.
 
Folder 2 contains the code for the Node:
The node is the mote connected to the servo. It receives a message form the servo an translates it into an action (open/close)

Folder 3 contains the code for the Monitor:
The monitor is the sensing node at the bottom the windows, that detect a shadow from the closing window. It sends a message to the control node to stop the servo.
*The Monitor mote must be equipped with a photo sensor.

For testing this project all 3 TelosB motes must be programmed with the code basestation, Node and Monitor code respectively.

