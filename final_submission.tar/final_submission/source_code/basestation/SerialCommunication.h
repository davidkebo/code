#ifndef SERIAL_COMMUNICATION_H
#define SERIAL_COMMUNICATION_H

typedef nx_struct serial_communication_msg {
  nx_uint16_t value;
  nx_uint16_t nodeid;
  nx_uint16_t photoReading;
} serial_communication_msg_t;

enum {
  AM_SERIAL_COMMUNICATION_MSG = 0x89,
};

#endif
