/* Filename: SerialCommunication.java
Class: CSE 521S Wireless Sensor Networks
Team Members: Chirombe, Houngninou,  Lee
Assignment: Class Project
Date: Fall 2010 */

import java.io.IOException;
import java.io.*;
import net.tinyos.message.*;
import net.tinyos.packet.*;
import net.tinyos.util.*;
import java.sql.*;
import java.util.Calendar;

public class SerialCommunication implements MessageListener {

    private MoteIF moteIF;
    static BufferedWriter GateLog;
    Calendar calendar = Calendar.getInstance(); // For time record

    public SerialCommunication(MoteIF moteIF) {
        this.moteIF = moteIF;
        this.moteIF.registerListener(new SerialCommunicationMsg(), this);
    }

    public void sendPackets() {
        int direction = 0;
        SerialCommunicationMsg payload = new SerialCommunicationMsg();

        try {
            while (true) {
                do {
                    System.out.println("Please enter servo rotation, (1: CLOSE, 2: OPEN): ");
                    try {
                        BufferedReader userinput = new BufferedReader(new InputStreamReader(System.in));
                        direction = Integer.parseInt(userinput.readLine());
                    }
                    catch (Exception e)  {
                        System.out.println("Input is incorrect, try again");
                        direction = 0;
                    }
                } while ((direction!=1)&&(direction!=2));

                payload.set_value(direction);
                moteIF.send(0, payload);

                try {
                    Thread.sleep(1000);
                }
                catch (InterruptedException exception) {}
            }
        }
        catch (IOException exception) {
            System.err.println("Exception thrown when sending packets. Exiting.");
            System.err.println(exception);
        }
    }

    public void messageReceived(int to, Message message) {
        SerialCommunicationMsg msg = (SerialCommunicationMsg)message;
        System.out.println("Received packet from Basestation: " + msg.get_value());

        // Get current time
        java.util.Date now = Calendar.getInstance().getTime();
        java.sql.Timestamp currentTimestamp = new java.sql.Timestamp(now.getTime());

        try {
            if (msg.get_value() == 1)
                GateLog.write("Gate closed at: " +currentTimestamp+ "\n");
            else if (msg.get_value() == 2)
                GateLog.write("Gate opened at: " +currentTimestamp+ "\n");
            GateLog.flush();
        } catch (IOException e) {
            System.err.println(e);
        }
    }

    private static void usage() {
        System.err.println("usage: SerialCommunication [-comm <source>]");
    }

    public static void main(String[] args) throws Exception {

        GateLog = new BufferedWriter(new FileWriter ("GateLog.dat"));
        GateLog.write ("Note: This file contains a Timestamp record of the gate operations \n\n");

        String source = null;
        if (args.length == 2) {
            if (!args[0].equals("-comm")) {
                usage();
                System.exit(1);
            }
            source = args[1];
        }
        else if (args.length != 0) {
            usage();
            System.exit(1);
        }

        PhoenixSource phoenix;

        if (source == null) {
            phoenix = BuildSource.makePhoenix(PrintStreamMessenger.err);
        }
        else {
            phoenix = BuildSource.makePhoenix(source, PrintStreamMessenger.err);
        }

        MoteIF mif = new MoteIF(phoenix);
        SerialCommunication serial = new SerialCommunication(mif);
        serial.sendPackets();

        GateLog.close();
    }

}
