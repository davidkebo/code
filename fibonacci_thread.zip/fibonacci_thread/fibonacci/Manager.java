import java.net.*;
import java.math.BigInteger;
import java.io.*;
import java.util.*;

/*
 * The worker thread fills an array passed by the manager with the first 1000 
 * fibonacci number
 */
class FiboThreadWorker extends Thread {

	Manager manager; // Manager object
	BigInteger[] fibo_numbers = new BigInteger[1000];

	// constructor
	FiboThreadWorker(BigInteger[] fibo_numbers, Manager manager) {
		this.fibo_numbers = fibo_numbers;
		this.manager = manager;
	}

	public void run() {
		fibo_numbers[0] = BigInteger.ZERO; // 0
		fibo_numbers[1] = BigInteger.ONE; // 1
		for (int i = 2; i < 1000; i++) {
			fibo_numbers[i] = fibo_numbers[i - 1].add(fibo_numbers[i - 2]);
		}

		// Notify the manager after completion of task
		synchronized (manager) {
			manager.notify();
		}
	}
}

/*
 * The class manager launches a FiboThreadWorker that computes the first 1000
 * fibonacci numbers
 */
public class Manager {
	public static void main(String[] args) {
		BigInteger[] fibo_numbers = new BigInteger[1000]; // Storage array for
															// the Fibonaccis
		Manager manager = new Manager(); // Manager object

		// Create a worker thread
		FiboThreadWorker worker = new FiboThreadWorker(fibo_numbers, manager);

		// Run the worker thread
		worker.start();
		// Wait for the worker to complete its task
		try {
			synchronized (worker) {
				worker.wait();
			}
		} catch (Exception e) {
			System.err.println(e);
		}

		// Print the numbers separated by commas
		for (int i = 0; i < 1000; i++)
			System.out.println(fibo_numbers[i] + ",");

	}
}