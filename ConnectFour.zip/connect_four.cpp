/* File:connect_four.cpp 
   Curses-based, Connect Four game
   ----------------------------------------------------------------
   Class: CS 375			 Instructor: Dr. Richardson
   Assignment:  Project 3		 Date assigned: September 23, 2008 
   Programmer: David Houngninou		 Date completed: October 07, 2008  */

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <curses.h>
#include <time.h>
#include <gdbm.h>
#include <string>
#include <cstdlib>
#include <cstring>
#include <stdio.h>
#include <string.h>
#include <iostream>

// coordinate handling
#define boardwidth 7
#define boarddepth 7
#define PYBASE 3
#define PXBASE 3
#define PROMPTLINE 21	// prompt line
#define HELPBASE 17	// help area 
#define HXBASE 0

// Datastructures
char board_side[] = " X  X  X  X", game_board[7][7];
char noWinner[] = "No winner yet", winner1[] = "***  Player 1 Won, Press 'R' to Restart ***", winner2[] = "*** Player 2 Won, Press 'R' to Restart ***";
int game_over = 0, coordinateX = 3, coordinateY = 2; // Initialize cursor position 
int game_grid [7][7], players[10], scores[10];  
int numberOfRows = 7, numberOfColumns = 7, winner=0, currentPlayer = 1, player1Score = 0, player2Score = 0; 

// Functions
void init_game_board ();// Reset the game grid
int aRandom (int m);// random function
void prompt(int n, NCURSES_CONST char *f, const char *s);//Print message at the prompt line 
int checkwin (int player, int row, int dropColumn); // Check if there is a winner
void dropToken (int currPlayer, int dropColumn); // Drop a token in a column
void switchPlayer (); // Switch between player 1 and 2
void gameDisplay (); // Display the game board
void initgame1(); // Human vs. Computer mode
void initgame2(); // Human vs. Human mode
void display_manual (); // Display manual
void display_score (); // Diplay Game score
void welcome_screen (); // Display welcome screen
void writeData (int currPlayer, int currScore); // Write scores to database
void readData (); // Read scores from database

// Structs
struct player { int number; int score; }; // player struct containing the player number and his score
struct keystr { int id;}; // key struct

using namespace std;

int main(int argc, char *argv[])
{    
  init_game_board (); // Initialize the game board
  initscr();
  keypad(stdscr, TRUE);// Enable non-ASCII to keycode translation
  writeData (1, 0); // Intialize scores
  writeData (2, 0);
  welcome_screen(); 
  endwin();
}

void init_game_board () // Initialize the game grid and variables
{ 
  int i, j;
  currentPlayer = 1; // Player 1 starts first
  game_over = 0;
  winner = 0;
  coordinateX = 3; coordinateY = 2; // Initialize coordinates
  
  for (i=0; i<numberOfRows; i++) // Initialize the game grid
    for ( j=0; j<numberOfColumns; j++)
      game_grid [i][j] = 0;
  
  for (i=0; i<numberOfRows; i++)
    for ( j=0; j<numberOfColumns; j++)
      game_board [i][j] = '.';  
}

int aRandom (int m)// random function
{ 
  return rand() %m; 
}

void prompt(int n, NCURSES_CONST char *f, const char *s)//Print message at the prompt line 
{
  move(PROMPTLINE + n, 0);
  clrtoeol();
  printw(f, s);
  refresh();
}

int checkwin (int player, int row, int dropColumn)// Check if a player has won
{ 
  int x = row, y = dropColumn;
  int southTokens=0, eastTokens=0, westTokens=0, southEastTokens=0, southWestTokens=0;
  int northEastTokens=0, northWestTokens=0, leftDiagonal, rightDiagonal, horizontal;
  int southAdv=0, eastAdv=0, westAdv=0, sEastAdv=0, sWestAdv=0, nEastAdv=0, nWestAdv=0;
  
  while ((x >= 0)&&(southAdv == 0)) // Check south
    {
      if (game_grid [x][y] == player)
	{ southTokens ++; x--; }
      else
	southAdv = 1; // Opponent block
    }
  
  x = row, y = dropColumn;
  while ((y < numberOfColumns)&&(eastAdv == 0)) // Check East
    {
      if (game_grid [x][y] == player)
	{ eastTokens ++; y++; }
      else
	eastAdv = 1; // Opponent block
    }
  
  x = row, y = dropColumn;
  while ((y >= 0)&&(westAdv == 0)) // Check West
    {
      if (game_grid [x][y] == player)
	{ westTokens ++; y--; }
      else
	westAdv = 1; // Opponent block
    }
  
  x = row, y = dropColumn;
  while ((x >= 0) && (y < numberOfColumns)&&(sEastAdv == 0))// Check South East
    {
      if (game_grid [x][y] == player)
	{ southEastTokens ++; x--;  y++; }
      else
	sEastAdv = 1; // Opponent block
    }
  
  x = row, y = dropColumn;
  while ((x >= 0) && (y >= 0) && (sWestAdv == 0)) // Check South West
    {
      if (game_grid [x][y] == player)
	{ southWestTokens ++; x--; y--; }
      else
	sWestAdv = 1; // Opponent block
    }
  
  x = row, y = dropColumn;
  while ((x < numberOfRows) &&(y < numberOfColumns) && (nEastAdv == 0)) // Check North East
    {
      if (game_grid [x][y] == player)
	{ northEastTokens ++; x++; y++; }
      else
	nEastAdv = 1; // Opponent block
    }
  
  x = row, y = dropColumn;
  while ((x < numberOfRows) && (y >= 0) && (nWestAdv == 0)) // Check North West
    {
      if (game_grid [x][y] == player)
	{ northWestTokens ++; x++; y--; }
      else
	nWestAdv = 1; // Opponent block
    }
  
  leftDiagonal =  northWestTokens + southEastTokens - 1;
  rightDiagonal = northEastTokens + southWestTokens - 1;
  horizontal = westTokens + eastTokens - 1;
  
  if ((southTokens==4)||(eastTokens==4)||(westTokens==4)||(southEastTokens==4)||(southWestTokens==4)||(northEastTokens==4)||(northWestTokens==4)||(leftDiagonal >=4)||(rightDiagonal >=4)||(horizontal >=4))
    return player;
  else 
    return 0;
}

void dropToken (int currPlayer, int dropColumn) // Drop a token in a column
{
  int row = 0, tokenPlaced = 0;
  
  while (tokenPlaced == 0)// Check where to drop the token
    {
      if (game_grid[row][dropColumn] == 0) // Empty spot
	{
	  game_grid[row][dropColumn] = currPlayer;
	  
	  if (currPlayer == 1)
	    game_board[row][dropColumn] = 'X';
	  else if (currPlayer == 2)
	    game_board[row][dropColumn] = '0';
	  
	  tokenPlaced = 1;
	}
      else
	row ++;
    } 
  winner = checkwin (currPlayer, row, dropColumn); // Check for a winner
}

void switchPlayer ()// Switch between player 1 and 2
{
  if (currentPlayer == 1)	  
    currentPlayer = 2;
  else if (currentPlayer == 2)
    currentPlayer = 1;
}

void gameDisplay () // Display the game board
{
  clear();
  int i, j;
  
#ifdef A_COLOR
  if (has_colors())
    attron(COLOR_PAIR(COLOR_GREEN));
#endif 
  mvaddstr(0, 25, "CURSES-BASED CONNECT FOUR");
  move(PROMPTLINE + 2, 0); 
  mvaddstr(PXBASE - 2, PYBASE - 3, "Game Board");
#ifdef A_COLOR
  attrset(0);
#endif 
  mvaddstr(PYBASE - 1, PXBASE - 3, board_side);  
  
  // Draw the Initial game board
  for (i = 0; i < boarddepth; i++) 
    {
      mvaddch(PYBASE + i, PXBASE - 3, (chtype) ('X'));
      addch(' ');
      
#ifdef A_COLOR
      if (has_colors())
	attron(COLOR_PAIR(COLOR_RED));
#endif 
      for (j = 0; j < boardwidth; j++) // Draw the game board
	{
	  mvaddch(PXBASE + i, PYBASE -1 + j, (chtype) (game_board [6-i][j]));
	}
#ifdef A_COLOR
      attrset(0);
#endif 
      mvaddch(PYBASE + i, PXBASE +  boardwidth, (chtype) ('X'));
    }
  mvaddstr(PYBASE + boarddepth, PXBASE - 3, board_side);
  
  mvaddstr(11, HXBASE+20, "    Press 'R' to reset the game    ");
  mvaddstr(12, HXBASE+20, "    Press 'W' to go back to the welcome screen    ");
  mvaddstr(13, HXBASE+20, "    Press 'I' to view instructions     ");
  mvaddstr(14, HXBASE+20, "    Press 'C' to view scores     ");
  
#ifdef A_COLOR
  if (has_colors())
    attron(COLOR_PAIR(COLOR_CYAN)); 
#endif 
  mvaddstr(4, HXBASE+20, " ***** Optional Control keys ***** ");
  mvaddstr(5, HXBASE+20, "                |                  ");
  mvaddstr(6, HXBASE+20, "            f - + - g              ");
  mvaddstr(7, HXBASE+20, "                |                  ");
  mvaddstr(8, HXBASE+20, "                v                  ");
#ifdef A_COLOR
  attrset(0);
#endif 
  
#ifdef A_COLOR
  if (has_colors())
    attron(COLOR_PAIR(COLOR_YELLOW));
#endif     
  mvprintw(HELPBASE + 1, HXBASE, "The left and right keyboard cursor keys allow the user to select a column");
  mvprintw(HELPBASE + 2, HXBASE, "The down cursor key causes the token to be dropped.");
#ifdef A_COLOR
  attrset(0); 
#endif 
  
  if (winner==1)
  {
    mvaddstr(HELPBASE -1, HXBASE, winner1);
    player1Score ++;
    writeData (winner, player1Score);  // Write scores to the database
    writeData (2, player2Score);
  }
  else if (winner==2)
  {
    mvaddstr(HELPBASE -1, HXBASE, winner2);
    player2Score ++;
    writeData (winner, player2Score); // Write scores to the database
    writeData (1, player1Score);
  }
  else 
    {
      if (currentPlayer == 1)
	prompt(0, "Player 1's turn...", "");
      else if (currentPlayer == 2)
	prompt(0, "Player 2's turn...", "");
      mvaddstr(HELPBASE -1, HXBASE, noWinner);
    }
}

void initgame1 () // Human vs. Computer mode
{
  coordinateX = 3, coordinateY = 2; // Initialize cursor position 
  game_over = 0;
  
  while (game_over == 0)
    {
      int c;      
      gameDisplay(); // Display the game board and instructions
      move(coordinateX, coordinateY); // Placed the cursor at a desired location
      
      if (winner == 0)// No winner yet
	{
	  if (currentPlayer == 1)// Human's turn
	    {
	      switch (c = getch()) 
		{ 
		case 'g': case 'G': case KEY_RIGHT:// Go right
		  if (coordinateY < 8)
		    coordinateY ++;
		  break;
		case 'f': case 'F': case KEY_LEFT:// Go left
		  if (coordinateY > 2 )
		    coordinateY --;
		  break;
		case 'v': case 'V': case KEY_DOWN: // Drop token
		  dropToken (currentPlayer, coordinateY-2);
		  switchPlayer ();
		  break;
		case 'r': case 'R':// Reset Game
		  init_game_board (); 
		  break;
		case 'w': case 'W':// Bring welcome screen
		  welcome_screen (); 
		  break;
		case 'i': case 'I':// Show manual
		  display_manual (); 
		  break;
	        case 'c': case 'C':// Show scores
		  display_score (); 
		  break;
		default:
		  initgame1 ();
		}
	    } 
	  
	  else if (currentPlayer == 2) // Computer's turn
	    {
	      coordinateY = aRandom(7)+2; // Computer drops token 
	      dropToken (currentPlayer, coordinateY-2);
	      switchPlayer (); 
	    }
	}
      
      else // Game over
	{
	  switch (c = getch())
	    { 
	    case 'r': case 'R':// Reset Game
	      init_game_board ();
	      break;
	    case 'w': case 'W':// Bring welcome screen
	      welcome_screen (); 
	      break;
	    case 'i': case 'I':// Show manual
	      display_manual (); 
	      break;
	    case 'c': case 'C':// Show scores
	      display_score (); 
	      break;
	    default:
	      initgame1 (); 
	    }
	}
    }
} // End initgame1 ()

void initgame2 () // Human vs. Human mode
{ 
  coordinateX = 3, coordinateY = 2; // Initialize cursor position 
  game_over = 0;
  
  while (game_over == 0)
    {
      int c;     
      gameDisplay();
      move(coordinateX, coordinateY); // Placed the cursor at a desired location
      
      if (winner == 0)
	{
	  switch (c = getch())
	    { 
	    case 'g': case 'G': case KEY_RIGHT:// Go right
	      if (coordinateY < 8)
		coordinateY ++;
	      break;
	    case 'f': case 'F': case KEY_LEFT:// Go left
	      if (coordinateY > 2 )
		coordinateY --;
	      break;
	    case 'v': case 'V': case KEY_DOWN: // Drop token
	      dropToken (currentPlayer, coordinateY-2);
	      switchPlayer ();
	      break;
	    case 'r': case 'R':// Reset Game
	      init_game_board (); 
	      break;
	    case 'w': case 'W':// Bring welcome screen
	      welcome_screen (); 
	      break;
	    case 'i': case 'I':// Show manual
	      display_manual (); 
	      break;
	    case 'c': case 'C':// Show scores
	      display_score (); 
	      break;
	    default:
	      initgame2 (); 
	    }
	} 
      
      else // Game over
	{
	  switch (c = getch())
	    { 
	    case 'r': case 'R':// Reset Game
	      init_game_board ();
	      break;
	    case 'w': case 'W':// Bring welcome screen
	      welcome_screen (); 
	      break;
	    case 'i': case 'I':// Show manual
	      display_manual (); 
	      break;
	    case 'c': case 'C':// Show scores
	      display_score (); 
	      break;
	    default:
	      initgame2 (); 
	    }
	}	
    }
} // End initgame2 ();

void display_manual () // User manual
{
  char c;
  int POSITION =2;
  clear();
  
#ifdef A_COLOR
  if (has_colors())
    attron(COLOR_PAIR(COLOR_CYAN));
#endif
  mvaddstr(0, 0, "CURSES-BASED CONNECT FOUR: USER MANUAL");
  move(PROMPTLINE + 2, 0);
  
  mvprintw(POSITION, HXBASE, "************  Playing Four-in-a-Row ************");
  mvprintw(POSITION + 2, HXBASE, "The game board consists of seven columns and six rows. ");
  mvprintw(POSITION + 4, HXBASE, "Each move consists of dropping a token in one of the columns.");
  mvprintw(POSITION + 5, HXBASE, "The token lands on the topmost empty row of the chosen column.");
  mvprintw(POSITION + 6, HXBASE, "To play with the keyboard, move the token in the top row ");
  mvprintw(POSITION + 7, HXBASE, "with the left and right arrow keys, and drop it with the down arrow key.");
  mvprintw(POSITION + 8, HXBASE, "Your token will drop into the topmost empty row of that column.");
  mvprintw(POSITION + 10, HXBASE, "Keys options:");
  mvprintw(POSITION + 11, HXBASE, "Please press 'A' for human vs. computer game");
  mvprintw(POSITION + 12, HXBASE, "Please press 'B' for human vs. human game");
  mvprintw(POSITION + 13, HXBASE, "Press 'W' to go back to the welcome screen");
  prompt(0, "Please press key to start...", "");
  
#ifdef A_COLOR
  attrset(0); 
#endif 
  
  switch (c = getch()) {
  case 'a': case 'A': // HUman vs. Computer
    initgame1(); 
    break;
  case 'b': case 'B': // Human vs. Human 
    initgame2(); 
    break;
  case 'w': case 'W':// Bring welcome screen
    welcome_screen (); 
    break;
  default:
    display_manual();
  } 
}

void display_score () // Game score
{
  char c;
  int POSITION =2;
  readData (); // Read the scores from the database
  clear();
  
#ifdef A_COLOR
  if (has_colors())
    attron(COLOR_PAIR(COLOR_YELLOW));
#endif
  mvaddstr(0, 0, "CURSES-BASED CONNECT FOUR: SCORE PAGE");
 move(PROMPTLINE , 0);
 
 mvprintw(POSITION, HXBASE, "************ Four-in-a-Row players 1&2 score ************");
 mvprintw(POSITION + 2, HXBASE, "This page contains player 1 and player 2 scores ");
 mvprintw(POSITION + 4, HXBASE, "Keys options:");
 mvprintw(POSITION + 6, HXBASE, "Please press 'A' for human vs. computer game");
 mvprintw(POSITION + 7, HXBASE, "Please press 'B' for human vs. human game");
 mvprintw(POSITION + 8, HXBASE, "Press 'W' to go back to the welcome screen");
 prompt(0, "Results: ", "");
 
 mvaddstr(HELPBASE -1, HXBASE + 20, "******  Scores:  ******");
 
 printf ("****  Player #%d score: %d , Player #%d score: %d  ****", players[1],scores[1],players[0],scores[0]);
 
#ifdef A_COLOR
 attrset(0); 
#endif 
 
 switch (c = getch()) {
 case 'a': case 'A':
   initgame1(); 
   break;
 case 'b': case 'B':
   initgame2(); 
   break;
 case 'w': case 'W':// Bring welcome screen
   welcome_screen (); 
   break;
 default:
   display_score();
 } 
}


void welcome_screen () //Welcome screen
{
#ifdef A_COLOR
  start_color();
  init_pair(COLOR_BLACK, COLOR_BLACK, COLOR_BLACK);
  init_pair(COLOR_GREEN, COLOR_GREEN, COLOR_BLACK);
  init_pair(COLOR_RED, COLOR_RED, COLOR_BLACK);
  init_pair(COLOR_CYAN, COLOR_CYAN, COLOR_BLACK);
  init_pair(COLOR_WHITE, COLOR_WHITE, COLOR_BLACK);
  init_pair(COLOR_MAGENTA, COLOR_MAGENTA, COLOR_BLACK);
  init_pair(COLOR_BLUE, COLOR_BLUE, COLOR_BLACK);
  init_pair(COLOR_YELLOW, COLOR_YELLOW, COLOR_BLACK);
#endif 
  
  char c;
  int POSITION =2;
  clear();
  mvaddstr(0, 0, "CURSES-BASED CONNECT FOUR: WELCOME SCREEN");
  move(PROMPTLINE + 2, 0);
  
  mvprintw(POSITION, HXBASE, "****** Welcome to the Curses-Based Connect Four ****** ");
  mvprintw(POSITION + 2, HXBASE, "The object of the game is to build a line of four of your tokens");
  mvprintw(POSITION + 3, HXBASE, "while trying to stop your opponent (human or computer) building a line ");
  mvprintw(POSITION + 4, HXBASE, "of his or her own. A line can be horizontal, vertical or diagonal.");
  mvprintw(POSITION + 6, HXBASE, "Please press 'A' for human vs. computer game");
  mvprintw(POSITION + 7, HXBASE, "Please press 'B' for human vs. human game");
  mvprintw(POSITION + 8, HXBASE, "Please press 'I' to view more instructions on the Game");
  
#ifdef A_COLOR
  if (has_colors())
    attron(COLOR_PAIR(COLOR_CYAN));
#endif 
  mvaddstr(POSITION + 10, HXBASE+0, " 		      ~~~~~~~~~~~~~~~~~~~~~~~ 					");
  mvaddstr(POSITION + 11, HXBASE+0, " _	_   ___   _  | (_)(_)(_)(_)(_)(_)(_) |  ___   ___   ______    ___   	");
  mvaddstr(POSITION + 12, HXBASE+0, "| |   | | | _ | | |  | (_)(_)(_)(_)(_)(_)(_) | |  _| | _ | |  _|_  | | _ |  	");
  mvaddstr(POSITION + 13, HXBASE+0, "| |_|_| | |___| | |_ | (_)(_)(_)(_)(_)(_)(_) | | |_  ||_|| | | | | | |___|	");
  mvaddstr(POSITION + 14, HXBASE+0, "|_ | |_ | |____ |___|| (_)(_)(_)(_)(_)(_)(_) | |___| |___| |_| | |_| |____  	");
  mvaddstr(POSITION + 15, HXBASE+0, " 		     | (_)(_)(_)(_)(_)(_)(_) |					");
  mvaddstr(POSITION + 16, HXBASE+0, " 		     | (_)(_)(_)(_)(_)(_)(_) |					");
  mvaddstr(POSITION + 17, HXBASE+0, " 		     | (_)(_)(_)(_)(_)(_)(_) |					");
  mvaddstr(POSITION + 18, HXBASE+0, " 		      ~~~~~~~~~~~~~~~~~~~~~~~					");
#ifdef A_COLOR
  attrset(0);
#endif    
  
  prompt(0, "Press key to start...", "");
  
  switch (c = getch())
    {
    case 'a': case 'A':
      initgame1(); 
      break;
    case 'b': case 'B':
      initgame2(); 
      break;
    case 'i': case 'I':
      display_manual();
      break;
    default:
      welcome_screen ();
    }
}

void writeData (int currPlayer, int currScore) // Write scores to the database
{
  GDBM_FILE dbf;
  struct keystr keydata;
  struct player aPlayer;
  datum key, content, datain;  

  key.dptr = (char *)(&keydata);
  key.dsize = sizeof(keydata);
  
  char *homeDirectory; 
  char filePath [90];
  homeDirectory = getenv ("HOME"); // Home directory
  strcpy(filePath, homeDirectory);
  strcat (filePath,"/.cfour"); // Database file
  dbf = gdbm_open(filePath, 0, GDBM_WRCREAT, 0644, 0);	// Open data base file

  aPlayer.number = currPlayer;
  aPlayer.score = currScore;
  content.dptr = (char *)(&aPlayer);
  content.dsize = sizeof(aPlayer);
  keydata.id = aPlayer.number;
  gdbm_store(dbf, key, content, GDBM_REPLACE); // Save the content to the database
  
  gdbm_close(dbf); 
}

void readData () // Read scores from the database
{
  GDBM_FILE dbf;
  datum key, datain;
  struct keystr keydata;
  struct player aPlayer;
  int i = 0;
  
  char *homeDirectory; 
  char filePath [90];
  homeDirectory = getenv ("HOME"); // Home directory
  strcpy(filePath, homeDirectory);
  strcat (filePath,"/.cfour"); // Database file
  dbf = gdbm_open(filePath, 0, GDBM_WRCREAT, 0644, 0);	// Open data base file
  
  key = gdbm_firstkey(dbf);// get the key to the first record in the db
   while (key.dptr != NULL)  // dptr is NULL if all keys have been retrieved
     {
       keydata = *(struct keystr *)key.dptr;  
       datain = gdbm_fetch(dbf, key);  // fetch data corresponding to this key    
       aPlayer = *((struct player *)(datain.dptr)); // copy the data into the aPlayer variable
       free(datain.dptr);    // free mem allocated by gdbm
       players[i] = aPlayer.number;
       scores[i] = aPlayer.score;
       
       key = gdbm_nextkey(dbf, key);// get the key of the next record and repeat
       i++;
     }
 gdbm_close(dbf); 
}



