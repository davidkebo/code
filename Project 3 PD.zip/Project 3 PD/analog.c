 /**********************************************************************/
 /*****************                             ************************/
 /*****************      Analog to Digital      ************************/
 /*****************            Module           ************************/
 /*****************                             ************************/
 /**********************************************************************/

sbit NotDone = 0x92;
#define ADC_Address 0X7000
unsigned char Analog_Data(unsigned char channum)
{
  unsigned char xdata *ADC;
  ADC = ADC_Address;
  *ADC = channum | 0x08;  //hook up at requested channel num and convert
   
  while (NotDone);  // wait until done

  return *ADC;
}
