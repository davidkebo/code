/* PD & BANG BANG LINE TRACKING PROJECT
------------------------------------------------------------------
Class: EE454                     Instructor: Professor Mitchell
Programming project 3	           
Programmers: David Houngninou, Teresa Stocker      Date completed: April 15, 2008 */

/*****************************************
******************************************
*			  PD PART					  * 	
******************************************
******************************************/
#include<at89c51xd2.h>
# define on 0
# define off 1
# define left 0
# define right 1
extern unsigned char Analog_Data(unsigned char);
extern void Display_Text(unsigned char, unsigned char, unsigned char message[]);
extern void Display_Number(unsigned char, unsigned char, unsigned long int);
extern void Motor (bit,char);
extern void Delay (unsigned int);
extern void initialize_pca();
sbit input_bit1 = P1^5;	  // PIN P1.5
sbit input_bit2 = P1^7;	  // PIN P1.7
sbit leftMotor_Enable = 0x91;
sbit rightMotor_Enable = 0x90;
unsigned int leftSensor = 0;   // Output of the sensor 1
unsigned int rightSensor = 0;	// Output of the sensor 2
char k1 = 5, k2 = 5, s1 =60;
int positionError = 0, lastError = 0, derivativeError = 0, speed = 0;

// FUNCTIONS PROTOTYPES
void PD();

void main()
{
	initialize_pca();
	Motor (left,0);
	Motor (right,0);
	Display_Text(1, 0, "MOTORS STOPPED\0");
	rightMotor_Enable = on;
	leftMotor_Enable = on;

	Delay (1000);

	Display_Text(1, 0, "PD MODE\0");
	PD();
}

void PD ()
{
	unsigned int counter = 0;
	while (1)
	{
		counter ++;
		if (counter == 5) // Wait for approximately 10 ms
		{
			leftSensor = Analog_Data(0);
			rightSensor = Analog_Data(1);

			lastError = positionError;

			positionError = rightSensor - leftSensor;
			derivativeError = 10 * (lastError - positionError);	 // Derivative
			speed = (k1 * positionError - k2*derivativeError) / 50;

			Motor (left, (int)s1 - speed);
			Motor (right, (int)s1 + speed);
			counter = 0;
		}
	}  
}  


