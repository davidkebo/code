#include<at89c51xd2.h>
#include <stdio.h>
#include <string.h>

extern void LcDelay(unsigned int);
extern void LcDisplay ( unsigned int, unsigned char);

void initialize_pca()
{
	/**********************************************************************/
	/*****************  LCD Initialization Module  ************************/
	/**********************************************************************/
	LcDelay(1000);
	LcDisplay(0xA000, 0x38);  //function set 8-bits
	LcDelay(5);
	LcDisplay(0xA000, 0x0C);  //display on
	LcDelay(5);
	LcDisplay(0xA000, 0x01);  // display clear
	LcDelay(50);
	LcDisplay(0xA000, 0x06);  // auto-increment pointer no shift
	LcDelay(1);


	CMOD = 0x02;
	CCAPM0 = 0x42;
	CCAPM1 = 0X42;
	IEN0 = IEN0 | 0xC0;
	CCON = 0X40;

	CR = 1;
}

// Delay Routine
void Delay (unsigned int DelayTime)
{
	unsigned int TimeTic;
	unsigned int Tock;
	for (TimeTic = 0; TimeTic< DelayTime; TimeTic++)
	{
		for (Tock = 0; Tock<1000; Tock ++);
	}
} // End Delay

// Motor speed routine
void Motor (bit motor, char speed)
{
	if (speed >96)
		speed = 96;
	if (speed <-96)
		speed = -96;
	if (motor)
		CCAP1H = speed + 128; // Set speed 1
	else
		CCAP0H = speed + 128;
}// end motor